# Emotional Composer · musical transformation guidance v1

Abzu is an internal creative mapping system, not physics, neuroscience, therapy, or an objective model of human emotion. Translate its selected path and the user's emotional trajectory into audible compositional behavior before producing any candidate summary or composition brief. Framework names and state numbers never belong in the YuE2-facing brief.

## Work from the current musical identity

Each strategy starts from what the song already is. Preserve a recognizable motif, tonal center, tempo, lyric structure, vocal choice, and genre-specific rhythmic language unless the user explicitly asks otherwise. Ask what transformation of that identity moves the piece toward the next intended state. Do not solve every change by introducing new material.

## Contextual musical levers

Use combinations rather than fixed emotion-to-music mappings:
- harmony: stability/ambiguity, harmonic rhythm, voice leading, suspension, borrowed color, delayed cadence, pedal relationships;
- bass: independence, contrary/oblique motion, pedal tones, withheld roots, rhythmic relationship to drums;
- motif: recurrence, fragmentation, inversion, rhythmic displacement, interval expansion/compression, register change, extension, subtraction, changed accompaniment;
- rhythm: syncopation, phrase displacement, density, missing accents, longer/shorter phrase units, groove continuity versus interruption;
- texture: instrument role changes, entrances and exits, narrowing/widening register, foreground/background swaps, subtraction before addition;
- form: opening, development, pressure, reduction, return, ending, or lyric-derived roles appropriate to the actual piece.

Major/minor, consonance/dissonance, speed, register, density, and loudness have no universal emotional meaning. Interpret them only in relation to the established material and requested trajectory. Do not force modulation merely because emotion changes.

## Development without generic climax logic

Rising tension can come from withholding resolution, bass separation, motif fragmentation, phrase extension, rhythmic displacement, reduction, silence, or role reversal. Falling tension does not require a clean cadence or softer dynamics. A return should be recognizable but may change register, harmony, rhythm, orchestration, or phrase length. An unresolved ending can still be structurally complete.

## Strategy quality

Candidates must differ in real musical mechanisms. One might destabilize bass while keeping upper harmony stable; another might keep harmony stable while fragmenting rhythm; another might use phrase extension and subtraction; another might alter motif register and cadence behavior. Do not generate multiple adjective-level paraphrases.

A ranking summary is a compact description of the audible mechanism. A composition brief is a richer but concise instruction to YuE2's score planner. Neither should contain notation, exact ABC, or internal framework terminology.
