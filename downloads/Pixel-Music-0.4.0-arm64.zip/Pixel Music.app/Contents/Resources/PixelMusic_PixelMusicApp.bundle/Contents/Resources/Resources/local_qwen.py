"""Shared Pixel Music local-Qwen lifecycle. Standard library only; loopback only."""
import contextlib, json, os, pathlib, shutil, signal, socket, subprocess, threading, time, urllib.request

SUPPORT = pathlib.Path.home()/'Library/Application Support'

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        raise ValueError('Local runtime redirects are not allowed.')

def request_json(url, body=None, timeout=5):
    if not url.startswith('http://127.0.0.1:'):
        raise ValueError('Pixel Music local Qwen only permits loopback endpoints.')
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    data=None if body is None else json.dumps(body).encode()
    req=urllib.request.Request(url,data=data,headers={'Content-Type':'application/json'})
    with opener.open(req,timeout=timeout) as res:
        payload=res.read(200001)
        if len(payload)>200000:
            raise ValueError('Local response exceeded the size limit.')
        return json.loads(payload)

def runtime():
    target=SUPPORT/'Pixel Music/Refine/runtime/mlx-serve'
    exe=target/'bin/mlx-serve'
    if not exe.is_file():
        sources=[
            SUPPORT/'ALi-Imagine/local-engines/prompt-assist-mlx/runtime/mlx-serve',
            SUPPORT/'Sirius/runtimes/mlx-serve'
        ]
        source=next((p for p in sources if (p/'bin/mlx-serve').is_file()),None)
        if not source:
            raise ValueError('Install the local Prompt Assist runtime in ALi Imagine once, then retry. Pixel Music will keep its own copy.')
        target.parent.mkdir(parents=True,exist_ok=True)
        staging=target.with_name('install-'+str(os.getpid()))
        try:
            shutil.copytree(source,staging,symlinks=False)
            check=subprocess.run([str(staging/'bin/mlx-serve'),'--version'],capture_output=True,text=True,timeout=20)
            if check.returncode or '26.8.9' not in check.stdout+check.stderr:
                raise ValueError('The local runtime must be mlx-serve 26.8.9.')
            staging.rename(target)
        finally:
            if staging.exists(): shutil.rmtree(staging)
    return exe

def check_model(path, require_vision=False):
    p=pathlib.Path(path).expanduser().resolve()
    config_path=p/'config.json'
    if not config_path.is_file():
        raise ValueError('Choose the same local Qwen text model used by Refine.')
    config=json.loads(config_path.read_text())
    allowed={
        'Qwen3_5ForConditionalGeneration','Qwen3_5MoeForConditionalGeneration',
        'Qwen3ForCausalLM','Qwen3MoeForCausalLM','Qwen2ForCausalLM',
        'Qwen2_5_VLForConditionalGeneration','Qwen3VLForConditionalGeneration'
    }
    if not any(a in allowed for a in config.get('architectures',[])):
        raise ValueError('Choose a Qwen text model, not a speech model.')
    index=p/'model.safetensors.index.json'
    weight_map=json.loads(index.read_text())['weight_map'] if index.exists() else {}
    if require_vision:
        architectures=config.get('architectures',[])
        vision_architectures={'Qwen2_5_VLForConditionalGeneration','Qwen3VLForConditionalGeneration'}
        qwen35=('Qwen3_5ForConditionalGeneration' in architectures or
                'Qwen3_5MoeForConditionalGeneration' in architectures)
        # Some complete Qwen exports omit this optional flag. Require indexed
        # vision tensors in that case; an explicit text-only flag still wins.
        vision_export=(config.get('language_model_only') is False or
                       ('language_model_only' not in config and
                        any(k.startswith('vision_tower.') for k in weight_map)))
        has_vision=(any(a in vision_architectures for a in architectures) or
                    (qwen35 and vision_export and
                     isinstance(config.get('vision_config'),dict) and
                     type(config.get('image_token_id')) is int))
        if not has_vision:
            raise ValueError('Choose a local Qwen vision-capable model for image inspiration.')
    files=set(weight_map.values()) if index.exists() else {'model.safetensors'}
    if not files or any('/' in f or '\\' in f or not (p/f).is_file() or (p/f).resolve().parent!=p or (p/f).stat().st_size==0 for f in files):
        raise ValueError('The Qwen model is incomplete.')
    return p

class LocalQwenSession:
    def __init__(self, model, log_path, require_vision=False):
        self.model=check_model(model,require_vision=require_vision)
        self.exe=runtime()
        self.log_path=pathlib.Path(log_path)
        self.child=None
        self.log=None
        self.endpoint=None
        self.model_id=None
        self.calls=0
        self._parent=os.getppid()

    def start(self):
        try:
            with socket.socket() as sock:
                sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]
            self.endpoint='http://127.0.0.1:'+str(port)
            self.log_path.parent.mkdir(parents=True,exist_ok=True)
            self.log=self.log_path.open('w')
            self.child=subprocess.Popen(
                [str(self.exe),'--model',str(self.model),'--serve','--host','127.0.0.1','--port',str(port)],
                stdin=subprocess.DEVNULL,stdout=self.log,stderr=self.log,start_new_session=True)
            threading.Thread(target=self._watch_parent,daemon=True).start()
            deadline=time.monotonic()+240
            while time.monotonic()<deadline:
                if self.child.poll() is not None:
                    raise ValueError('Qwen could not start. See the local runtime log.')
                try:
                    models=request_json(self.endpoint+'/v1/models').get('data',[])
                    if models:
                        self.model_id=models[0]['id']
                        return self
                except Exception:
                    time.sleep(.5)
            raise ValueError('Qwen took too long to load.')
        except BaseException:
            self.close()
            raise

    def _watch_parent(self):
        while self.child and self.child.poll() is None:
            time.sleep(1)
            if os.getppid()!=self._parent:
                try: os.kill(os.getpid(),signal.SIGTERM)
                except ProcessLookupError: pass
                return

    def ask(self, messages, temperature=.5, max_tokens=3200, seed=None):
        if self.child is None or self.child.poll() is not None or not self.model_id:
            raise ValueError('Local Qwen is not running.')
        self.calls+=1
        payload={
            'model':self.model_id,'messages':messages,'stream':False,'max_tokens':max_tokens,
            'temperature':temperature,'top_p':.9,'enable_thinking':False,
            'chat_template_kwargs':{'enable_thinking':False}
        }
        if seed is not None: payload['seed']=int(seed)
        response=request_json(self.endpoint+'/v1/chat/completions',payload,timeout=300)
        choice=response['choices'][0]
        if choice.get('finish_reason')=='length':
            raise ValueError('The local Qwen response was cut short. Reduce the request or candidate count.')
        return choice['message']['content']

    def close(self):
        child=self.child
        self.child=None
        if child and child.poll() is None:
            try:
                os.killpg(child.pid,signal.SIGTERM); child.wait(timeout=8)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGKILL); child.wait()
            except ProcessLookupError:
                pass
        if self.log:
            self.log.close(); self.log=None

    def __enter__(self):
        return self.start()

    def __exit__(self, exc_type, exc, tb):
        self.close()

@contextlib.contextmanager
def qwen_session(model, log_path):
    session=LocalQwenSession(model,log_path)
    try:
        yield session.start()
    finally:
        session.close()

def install_signal_cleanup(session):
    def cancelled(*_):
        session.close()
        raise SystemExit(130)
    signal.signal(signal.SIGTERM,cancelled)
    signal.signal(signal.SIGINT,cancelled)
