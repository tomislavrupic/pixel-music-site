"""Safe status test: never submits generation or installs components."""
import asyncio
import json
from pixel_music_adapter import connect, call

async def main():
    async with connect() as session:
        tools = await session.list_tools()
        assert 'pixel_music_status' in {t.name for t in tools.tools}
        print(json.dumps(await call(session, 'pixel_music_status'), indent=2))

if __name__ == '__main__':
    asyncio.run(main())
