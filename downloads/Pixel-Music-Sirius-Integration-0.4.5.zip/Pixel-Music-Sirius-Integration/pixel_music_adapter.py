"""Reference stdio MCP client. Requires the official Python `mcp` package."""
import json
from pathlib import Path
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from contextlib import asynccontextmanager

@asynccontextmanager
async def connect(config_path=None):
    config_path = Path(config_path or Path(__file__).with_name('mcp-client.json'))
    entry = json.loads(config_path.read_text())['mcpServers']['pixel-music']
    params = StdioServerParameters(command=entry['command'], args=entry.get('args', []))
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            yield session

async def call(session, tool, arguments=None):
    result = await session.call_tool(tool, arguments=arguments or {})
    envelope = result.structuredContent
    if envelope is None:
        envelope = json.loads(next(c.text for c in result.content if c.type == 'text'))
    if result.isError or envelope.get('error'):
        error = envelope.get('error') or {'code': 'MCP_ERROR', 'message': 'Tool failed'}
        raise RuntimeError(f"{error['code']}: {error['message']}")
    return envelope['result']
