#!/usr/bin/env python3
"""Pixel Music adapter for the pinned community YuE2 MLX port. No inference at import."""
import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
import re
import secrets
import uuid
from pathlib import Path
import shutil
import sys
import time

REPOSITORY = 'ahmadw/YuE2-3B-MLX'
REVISION = 'fe0a9050fd658257b486b880422d8872ee1f81e3'
_style_spec = importlib.util.spec_from_file_location('pixel_music_style_adapter', Path(__file__).with_name('style_adapter.py'))
style_adapter = importlib.util.module_from_spec(_style_spec)
_previous_bytecode_setting = sys.dont_write_bytecode
try:
    sys.dont_write_bytecode = True
    _style_spec.loader.exec_module(style_adapter)
finally:
    sys.dont_write_bytecode = _previous_bytecode_setting
_conditioning_spec = importlib.util.spec_from_file_location('pixel_music_conditioning', Path(__file__).with_name('music_conditioning.py'))
music_conditioning = importlib.util.module_from_spec(_conditioning_spec)
_previous_bytecode_setting = sys.dont_write_bytecode
try:
    sys.dont_write_bytecode = True
    _conditioning_spec.loader.exec_module(music_conditioning)
finally:
    sys.dont_write_bytecode = _previous_bytecode_setting


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def reserve_output(out):
    if out.exists() or out.is_symlink():
        raise FileExistsError('A master already exists at this output path.')
    artifacts = out.with_suffix('.yue2')
    artifacts.mkdir(parents=False, exist_ok=False)
    return artifacts


def verify_latent(path, expected):
    if Path(path).is_symlink() or not Path(path).is_file() or sha256(path) != expected:
        raise ValueError('The saved source latent is missing or its checksum changed.')


def semantic_budget(options, duration, model_max):
    return min(model_max, 9000) if options.get('autoDuration') is True else duration * 25


_FRAMEWORK = re.compile(r'\b(?:abzu|rota|huf|d13|observer|state\s*\d+)\b', re.I)


def validate_composition_brief(options):
    brief = options.get('compositionBrief')
    if brief is None:
        return None
    if not isinstance(brief, str) or not brief.strip() or len(brief) > 3000:
        raise ValueError('Emotional Composer compositionBrief must be 1–3000 characters.')
    match = _FRAMEWORK.search(brief)
    if match:
        raise ValueError('Emotional Composer compositionBrief contains internal framework language: ' + match.group(0))
    return brief.strip()


def _valid_sha(value):
    return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdefABCDEF' for c in value)


def verify_composer_reference(options):
    brief = validate_composition_brief(options)
    ref = options.get('emotionalComposer')
    if ref is None:
        return None
    required = {'schemaVersion','planID','selectedCandidateID','manifestPath','manifestSHA256','songSnapshotSHA256','initialScoreSHA256'}
    if not isinstance(ref, dict) or set(ref) != required or ref.get('schemaVersion') != 1:
        raise ValueError('Emotional Composer reference is invalid.')
    if not all(_valid_sha(ref.get(k)) for k in ('manifestSHA256','songSnapshotSHA256','initialScoreSHA256')):
        raise ValueError('Emotional Composer reference checksum is invalid.')
    if not isinstance(ref.get('manifestPath'), str) or not ref['manifestPath'].startswith('/'):
        raise ValueError('Emotional Composer manifest path is invalid.')
    path = Path(ref['manifestPath'])
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 4_000_000 or sha256(path) != ref['manifestSHA256']:
        raise ValueError('Emotional Composer manifest is missing or changed.')
    data = json.loads(path.read_text())
    if (data.get('schemaVersion') != 1 or data.get('composer') != 'abzu-emotional-composer'
        or data.get('id') != ref.get('planID')
        or data.get('decision', {}).get('selectedCandidateID') != ref.get('selectedCandidateID')
        or data.get('selectedCompositionBrief') != brief
        or data.get('yue2', {}).get('initialScoreSHA256') != ref.get('initialScoreSHA256')):
        raise ValueError('Emotional Composer manifest does not match this recipe.')
    if options.get('planning') == 'off' or not options.get('abc','').strip():
        raise ValueError('Emotional Composer requires an accepted ABC score and YuE2 planning mode.')
    source_path = options.get('sourceScorePath')
    source_hash = options.get('sourceScoreSHA256')
    if bool(source_path) != bool(source_hash):
        raise ValueError('Emotional Composer source score provenance is incomplete.')
    if source_path:
        score = Path(source_path)
        supplied_hash = hashlib.sha256(options['abc'].encode('utf-8')).hexdigest()
        if (not _valid_sha(source_hash) or score.is_symlink() or not score.is_file()
            or sha256(score) != source_hash or supplied_hash != source_hash):
            raise ValueError('Emotional Composer supplied ABC differs from its source score.')
    return data


def read_composer_score_inputs(options, manifest, request, audition_context=None):
    if manifest is None or manifest.get('scoreInputsVersion') is None:
        return None
    if manifest['scoreInputsVersion'] != 1:
        raise ValueError('Emotional Composer score inputs version is unsupported.')
    source = Path(options['emotionalComposer']['manifestPath']).parent/'score-inputs.json'
    if source.is_symlink() or not source.is_file() or not 0 < source.stat().st_size <= 4_000_000:
        raise ValueError('Captured score inputs are missing or unsafe.')
    contents = source.read_bytes()
    try:
        data = json.loads(contents)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError('Captured score inputs are invalid.') from error
    if (not isinstance(data, dict) or data.get('schemaVersion') != 3
        or data.get('provider') != 'yue2-mlx' or data.get('modelID') not in (REPOSITORY, 'goldhub/YuE2-RS-Finetunes')
        or not isinstance(data.get('yue2'), dict)):
        raise ValueError('Captured score inputs are invalid.')
    song = manifest.get('songSnapshot')
    decision = manifest.get('decision')
    same_project = data.get('projectID') == request.get('projectID')
    if not same_project and audition_context is not None:
        try:
            same_project = (uuid.UUID(data['projectID']) == uuid.UUID(audition_context['sourceProjectID'])
                            and uuid.UUID(request['projectID']) == uuid.UUID(audition_context['projectID']))
        except (KeyError, TypeError, ValueError, AttributeError):
            same_project = False
    if (not isinstance(song, dict) or not isinstance(decision, dict)
        or not isinstance(data.get('rootNote'), str) or not isinstance(data.get('scale'), str)
        or any(data.get(recipe_key, default) != song.get(song_key, default)
               for recipe_key, song_key, default in (
                   ('caption', 'caption', None), ('negativePrompt', 'negativePrompt', ''),
                   ('lyrics', 'lyrics', None), ('vocalChoice', 'vocalChoice', None),
                   ('tempoBPM', 'tempo', None), ('presetContext', 'presetContext', None)))
        or data['yue2'].get('planning') != song.get('planning')
        or song_key(data['rootNote'], data['scale']) != song.get('key')
        or type(data.get('seed')) is not int or data['seed'] != decision.get('seed')
        or not same_project
        or data.get('rootNote') != request.get('rootNote')
        or data.get('scale') != request.get('scale')):
        raise ValueError('Captured score inputs do not match the composer song or project.')
    return contents


def finalize_composer_manifest(artifacts):
    manifest = artifacts/'composer.json'
    score = artifacts/'score.abc'
    if not manifest.is_file():
        return None
    if not score.is_file() or not score.read_text().strip():
        raise ValueError('Emotional Composer render is missing the actual ABC score.')
    data = json.loads(manifest.read_text())
    score_hash = sha256(score)
    data['renderedScoreSHA256'] = score_hash
    initial = data.get('yue2', {}).get('initialScoreSHA256')
    data['acceptedScoreWasEdited'] = bool(initial and score_hash != initial)
    partial = manifest.with_suffix('.json.partial')
    partial.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    os.replace(partial, manifest)
    return score_hash


def validate_options(options, duration):
    style_adapter.validate_options(options)
    imported_application_mode(options, False)
    validate_composition_brief(options)
    mode = options.get('planning', 'full')
    if mode not in ('full', 'melody', 'off') or (mode == 'off' and options.get('abc', '').strip()):
        raise ValueError('ABC input requires melody/full planning.')
    for name, low, high, default in [('guidance', .1, 10, 1), ('steps', 1, 128, 32),
            ('temperature', 0, 2, 1), ('topP', .01, 1, .95), ('topK', 1, 184704, 100),
            ('repetitionPenalty', 1, 2, 1.2), ('penaltyWindow', 1, 1000, 50)]:
        value = options.get(name, default)
        if not isinstance(value, (int, float)) or not math.isfinite(value) or not low <= value <= high:
            raise ValueError('Invalid YuE2 setting: ' + name)
    if not 10 <= duration <= 360:
        raise ValueError('Duration cap must be 10–360 seconds.')


def verify_install(root):
    # Load the bundled verifier before adding any model folder to sys.path.
    spec = importlib.util.spec_from_file_location('pixel_yue2_backbones', Path(__file__).with_name('yue2_backbones.py'))
    module = importlib.util.module_from_spec(spec)
    # Dependencies are the bundled external format helpers, loaded from this folder.
    resource_root = str(Path(__file__).resolve().parent)
    sys.path.insert(0, resource_root)
    try:
        spec.loader.exec_module(module)
        return module.verify_package(root)
    finally:
        sys.path.remove(resource_root)


def validate_backbone_request(request, lock):
    supported = {REPOSITORY, 'goldhub/YuE2-RS-Finetunes'}
    if (request.get('provider') != 'yue2-mlx' or request.get('modelID') not in supported
            or request['modelID'] != lock.get('repository')):
        raise ValueError('Recipe model identity does not match the installed checkpoint.')
    options = request.get('yue2', {})
    if request['modelID'] != REPOSITORY and (options.get('trainedStylePath') is not None or options.get('importedSound') is not None):
        raise ValueError('Trained styles and LoRA sounds require Original YuE2 BF16.')


def should_apply_trained_style(options, plan_only=False):
    """Approved artist adapters never participate in symbolic score invention."""
    return not plan_only and not options.get('decodeLatentsPath')


_bundled_imported_modules = None


def preload_imported_sound_bridge():
    """Load bundled validators by exact filename before adding model import paths."""
    global _bundled_imported_modules
    if _bundled_imported_modules is None:
        modules={}
        for suffix in ('format','import','apply','store'):
            name='external_yue2_'+suffix
            path=Path(__file__).resolve().with_name(name+'.py')
            module=sys.modules.get(name)
            if module is None or getattr(module,'__file__',None)!=str(path):
                module_spec=importlib.util.spec_from_file_location(name,path)
                module=importlib.util.module_from_spec(module_spec)
                # Sibling imports and dataclasses must see this exact bundled module.
                previous=sys.modules.get(name)
                sys.modules[name]=module
                try:
                    module_spec.loader.exec_module(module)
                except BaseException:
                    if previous is None: sys.modules.pop(name,None)
                    else: sys.modules[name]=previous
                    raise
            modules[name]=module
        _bundled_imported_modules=modules
    return _bundled_imported_modules


def imported_sound_adapter():
    return preload_imported_sound_bridge()['external_yue2_apply']


def imported_sound_store():
    return preload_imported_sound_bridge()['external_yue2_store']


def read_audition_context(stream, request, model_root, output):
    """Read the app's one-job stdin authorization; no recipe JSON flag can opt in."""
    imported_sound_adapter()  # Expose sibling, bundled validation resources.
    from external_yue2_format import strict_json, open_regular
    raw = stream.read(16_385)
    if not raw or len(raw) > 16_384:
        raise ValueError('Invalid comparison authorization size.')
    try:
        context = strict_json(raw)
    except (ValueError, UnicodeError) as error:
        raise ValueError('Invalid comparison authorization JSON.') from error
    expected = {'schemaVersion', 'purpose', 'role', 'reviewID', 'jobID',
                'projectID', 'sourceProjectID', 'packageID', 'versionID', 'descriptor',
                'baseBinding', 'modelPath', 'previewOutputPath'}
    if (not isinstance(context, dict) or set(context) != expected
            or type(context['schemaVersion']) is not int or context['schemaVersion'] != 1
            or context['purpose'] != 'importedSoundAudition'
            or context['role'] not in ('baseline', 'adapted')):
        raise ValueError('Invalid comparison authorization fields.')
    try:
        for key in ('reviewID', 'jobID', 'projectID', 'sourceProjectID', 'packageID', 'versionID'):
            uuid.UUID(context[key])
        if (uuid.UUID(context['jobID']) != uuid.UUID(request['id'])
                or uuid.UUID(context['projectID']) != uuid.UUID(request['projectID'])
                or uuid.UUID(context['sourceProjectID']) == uuid.UUID(context['projectID'])):
            raise ValueError()
    except (KeyError, ValueError, TypeError, AttributeError):
        raise ValueError('Comparison authorization does not match this job.') from None
    def exact_path(value, expected_path):
        return (isinstance(value, str) and value.startswith('/') and '\0' not in value
                and '..' not in Path(value).parts
                and os.path.normpath(value) == os.path.normpath(str(expected_path)))
    if (not exact_path(context['modelPath'], Path(model_root).absolute())
            or not exact_path(context['previewOutputPath'], Path(output).absolute())):
        raise ValueError('Comparison authorization does not match this output or model.')
    imported_sound_adapter().validate_reference(context['descriptor'])
    imported_sound_adapter().validate_reference(context['baseBinding'])
    lock_path = Path(model_root).absolute()/'.pixel-music-model-lock.json'
    if not exact_path(context['baseBinding']['path'], lock_path):
        raise ValueError('Comparison authorization has a different base binding.')
    try:
        # macOS temporary paths may begin with /var -> /private/var. Resolve
        # the trusted model directory, never the lock leaf, before no-follow IO.
        safe_lock_path = lock_path.parent.resolve() / lock_path.name
        with open_regular(safe_lock_path, 256 * 1024) as source:
            if hashlib.sha256(source.read()).hexdigest() != context['baseBinding']['sha256'].lower():
                raise ValueError('Comparison base binding changed.')
    except OSError as error:
        raise ValueError('Comparison base binding is unavailable.') from error
    sound = request.get('yue2', {}).get('importedSound')
    if context['role'] == 'adapted':
        if not isinstance(sound, dict):
            raise ValueError('Comparison adapted job has no selected sound.')
        imported_sound_adapter().validate_selection(sound)
        if (not imported_sound_adapter().effective_scales(sound)
                or uuid.UUID(context['packageID']) != uuid.UUID(sound['packageID'])
                or uuid.UUID(context['versionID']) != uuid.UUID(sound['versionID'])
                or context['descriptor'] != sound['descriptor']):
            raise ValueError('Comparison authorization does not match the selected sound.')
    elif sound is not None or any(request.get('yue2', {}).get(key) is not None
                                  for key in ('trainedStylePath', 'trainedStyleSHA256', 'styleInfluence')):
        raise ValueError('Comparison baseline must use the original model.')
    return context


def imported_application_mode(options, plan_only=False):
    """Validate the selection before classifying any bypass or active request."""
    if options.get('importedSound') is None:
        return 'not_selected'
    status = imported_sound_adapter().render_policy(options, plan_only)['status']
    return {'base_planning': 'planning_bypass',
            'latent_decode': 'latent_redecode_bypass',
            'requires_base_score': 'active',
            'requires_verified_binding': 'active'}.get(status, status)


def resolve_active_imported_sound(options, model_root, audition_context=None, expected_store=None):
    """A normal render must receive authorization and applied evidence from the public bridge."""
    selection = options['importedSound']
    adapter = imported_sound_adapter()
    adapter.validate_selection(selection)
    if selection.get('approval') is None and audition_context is None:
        raise ValueError('Imported sound normal render requires a listening approval reference.')
    resolve = getattr(imported_sound_store(), 'resolve', None)
    if not callable(resolve):
        raise RuntimeError('Imported sound cannot render: missing external_yue2_store.resolve API.')
    verified = resolve(selection, model_root, audition_context=audition_context, expected_store=expected_store)
    if not isinstance(verified, dict) or not {'base', 'references', 'provenance'} <= set(verified):
        raise ValueError('Imported sound resolver returned no verified base, adapter references and provenance.')
    base, references, provenance = (verified[key] for key in ('base', 'references', 'provenance'))
    required = {'packageID', 'versionID', 'descriptor', 'approval',
                'normalized', 'source', 'converter', 'licenseStatus'}
    if (not isinstance(base, dict) or not isinstance(references, list) or not references
            or not isinstance(provenance, dict) or not required <= set(provenance)
            or uuid.UUID(provenance['packageID']) != uuid.UUID(selection['packageID'])
            or uuid.UUID(provenance['versionID']) != uuid.UUID(selection['versionID'])
            or provenance['descriptor'] != selection['descriptor']
            or provenance['approval'] != selection.get('approval')):
        raise ValueError('Imported sound resolver returned incomplete or mismatched authorization.')
    return verified


def apply_active_imported_sound(model, options, model_root, audition_context=None, *,
                                expected_store=None, verified=None):
    """Apply authorized weights only after symbolic planning with the original base."""
    selection=options['importedSound']
    if verified is None:
        verified=resolve_active_imported_sound(options,model_root,audition_context,expected_store)
    base,references,provenance=(verified[key] for key in ('base','references','provenance'))
    result = imported_sound_adapter().apply_bound_adapters(model, base, references, selection['amount'])
    if (not isinstance(result, dict) or not isinstance(result.get('updates'), list)
            or not result['updates'] or result.get('base') != base):
        raise ValueError('Imported sound application did not confirm model weight updates.')
    applied = {'applied': True, 'updatedTargets': result['updates'],
               'normalized': provenance['normalized'], 'source': provenance['source'],
               'base': base, 'converter': provenance['converter'],
               'license': provenance['licenseStatus'], 'approval': provenance['approval'],
               'descriptor': provenance['descriptor']}
    json.dumps(applied, allow_nan=False)
    return applied


def imported_sound_report(options, reason, applied=None):
    sound = options.get('importedSound')
    if sound is None:
        return None
    report = {'selection': sound, 'applied': applied is not None,
              'reason': reason, 'effectiveScales': (
                  imported_sound_adapter().effective_scales(sound) if applied is not None else {}),
              'sourceOutputID': options.get('sourceOutputID')}
    if applied is not None:
        report['application'] = applied
    return report


def source_imported_sound(latent_path):
    """Read the source output's recorded sound identity, never its adapter files."""
    bundle = Path(latent_path).parent
    sidecar = bundle/'imported-sound.json'
    if not sidecar.exists() and not sidecar.is_symlink():
        return None
    result = bundle/'result.json'
    if (sidecar.is_symlink() or result.is_symlink() or not sidecar.is_file()
            or not result.is_file() or sidecar.stat().st_size > 256 * 1024):
        raise ValueError('Source imported-sound provenance is unsafe.')
    expected = json.loads(result.read_text()).get('files', {}).get(sidecar.name)
    if not _valid_sha(expected) or sha256(sidecar) != expected:
        raise ValueError('Source imported-sound provenance changed.')
    data = json.loads(sidecar.read_text())
    for _ in range(32):
        if not isinstance(data, dict) or not isinstance(data.get('sourceSound'), dict):
            break
        data = data['sourceSound']
    else:
        raise ValueError('Source imported-sound provenance has excessive lineage depth.')
    if (not isinstance(data, dict) or type(data.get('applied')) is not bool
            or (data.get('selection') is not None and not isinstance(data['selection'], dict))):
        raise ValueError('Source imported-sound provenance is invalid.')
    return {key: value for key, value in data.items() if key != 'sourceSound'}


def song_key(root_note, scale_name):
    root_names = {'cSharp':'C-sharp', 'dSharp':'D-sharp', 'fSharp':'F-sharp', 'gSharp':'G-sharp', 'aSharp':'A-sharp'}
    root = root_names.get(root_note, root_note.upper())
    scale = re.sub(r'(?<!^)(?=[A-Z])', ' ', scale_name).lower()
    return f'{root} {scale}'


def conditioned_style(request):
    caption = request['caption'].strip()
    avoid = request.get('negativePrompt', '').strip()
    if avoid:
        caption += '\nAvoid: ' + avoid
    vocal = request.get('vocalChoice', 'prompted')
    if vocal not in ('male', 'female', 'prompted'):
        raise ValueError('Unknown vocal choice')
    if vocal != 'prompted' and request.get('lyrics', '').strip().lower() != '[instrumental]':
        caption += '\n' + vocal.capitalize() + ' lead vocals. This vocal choice takes precedence over conflicting voice descriptions.'
    brief = validate_composition_brief(request.get('yue2', {}))
    if brief:
        caption += '\nComposition:\n' + brief
    context = music_conditioning.build_conditioning_context(request)
    if context is not None:
        priority = ('Conditioning priority: explicit intention > trajectory > project controls and accepted composition '
                    '> Style > Voice > Taste. Taste is conditional; preset avoid lists are preferences, '
                    'not hard exclusions. Preserve explicit vocal choice, lyrics, tempo, key and ABC.')
        summary = music_conditioning.render_conditioning(context, 2400 - len(priority) - 1)
        if summary:
            caption += '\n' + priority + '\n' + summary
    return caption + f"\nTempo: {request['tempoBPM']} BPM. Key: {song_key(request['rootNote'], request['scale'])}."


def score_header_diagnostics(score, request):
    """Compare only unambiguous ABC header notation, never inferred audio properties."""
    headers = {}
    for line in score.splitlines():
        match = re.match(r'^\s*([A-Za-z]):\s*(.*?)\s*$', line)
        if match:
            field, value = match.groups()
            if field in ('K', 'Q') and field not in headers:
                headers[field] = value.split('%', 1)[0].strip()
            if field == 'K':
                break
        elif line.strip() and not line.lstrip().startswith('%'):
            break
    mismatches, warnings = [], []
    key = re.fullmatch(r'([A-Ga-g])([#♯b♭]?)(.*)', headers.get('K', ''))
    modes = {'': 'major', 'maj': 'major', 'major': 'major',
             'm': 'naturalMinor', 'min': 'naturalMinor', 'minor': 'naturalMinor',
             'aeo': 'naturalMinor', 'aeolian': 'naturalMinor', 'naturalminor': 'naturalMinor',
             'dor': 'dorian', 'dorian': 'dorian', 'phr': 'phrygian', 'phrygian': 'phrygian',
             'lyd': 'lydian', 'lydian': 'lydian', 'mix': 'mixolydian', 'mixolydian': 'mixolydian',
             'loc': 'locrian', 'locrian': 'locrian'}
    if key and key.group(3).strip().lower().replace(' ', '') in modes:
        note, accidental, mode_text = key.groups()
        pitches = {'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11}
        actual_pitch = (pitches[note.upper()] + (1 if accidental in ('#', '♯') else -1 if accidental in ('b', '♭') else 0)) % 12
        requested_note = request['rootNote']
        requested_key = re.fullmatch(r'([a-g])(?:Sharp)?', requested_note)
        if requested_key:
            expected_pitch = (pitches[requested_key.group(1).upper()] + (1 if requested_note.endswith('Sharp') else 0)) % 12
            actual_mode = modes[mode_text.strip().lower().replace(' ', '')]
            expected_mode = request['scale']
            # A K field cannot establish pentatonic notes or minor-scale alterations.
            known_mode = expected_mode not in ('harmonicMinor', 'melodicMinor', 'majorPentatonic', 'minorPentatonic')
            if not known_mode:
                warnings.append('Score header key mode check unavailable for this requested scale.')
            if actual_pitch != expected_pitch or (known_mode and actual_mode != expected_mode):
                actual_label = note.upper() + accidental.replace('♯', '#').replace('♭', 'b') + (' minor' if actual_mode == 'naturalMinor' else ' ' + actual_mode)
                expected_label = requested_note[0].upper() + ('#' if requested_note.endswith('Sharp') else '') + ' ' + re.sub(r'(?<!^)(?=[A-Z])', ' ', expected_mode).lower()
                mismatches.append(f'Score header key is {actual_label}; requested key is {expected_label}. ABC conditioning does not guarantee rendered audio key.')
        else:
            warnings.append('Score header key check unavailable for this requested key.')
    else:
        warnings.append('Score header key check unavailable: missing or unrecognized K field.')
    tempo = re.fullmatch(r'(\d+)\s*/\s*(\d+)\s*=\s*(\d+(?:\.\d+)?)', headers.get('Q', ''))
    if tempo and tempo.group(1) == '1' and tempo.group(2) == '4':
        quarter_bpm = float(tempo.group(3))
        if abs(quarter_bpm - request['tempoBPM']) > 0.01:
            mismatches.append(f'Score header tempo is {quarter_bpm:g} quarter-note BPM; requested tempo is {request["tempoBPM"]} BPM. ABC conditioning does not guarantee rendered audio tempo.')
    else:
        warnings.append('Score header tempo check unavailable: missing Q field or beat unit is not an explicit quarter note.')
    return mismatches, warnings


def exact_abc_key(request):
    roots = {'cSharp': 'C#', 'dSharp': 'D#', 'fSharp': 'F#',
             'gSharp': 'G#', 'aSharp': 'A#'}
    modes = {'major': '', 'naturalMinor': 'm', 'dorian': 'dor',
             'phrygian': 'phr', 'lydian': 'lyd', 'mixolydian': 'mix',
             'locrian': 'loc'}
    root = request['rootNote']
    if request['scale'] not in modes or not re.fullmatch(r'[a-g](?:Sharp)?', root):
        return None
    return roots.get(root, root.upper()) + modes[request['scale']]


def corrective_planning_style(request, style):
    tonic = {'cSharp': 'C#', 'dSharp': 'D#', 'fSharp': 'F#',
             'gSharp': 'G#', 'aSharp': 'A#'}.get(request['rootNote'], request['rootNote'].upper())
    key = exact_abc_key(request)
    notation = f'K:{key}' if key else None
    key_instruction = (f'Write the ABC key header exactly as {notation}. ' if notation else
                       f'Use {tonic} as the requested tonic in the ABC key header. ')
    return (style + '\nCorrect the previous ABC score while keeping the same composition, '
            'lyrics, and musical strategy. ' + key_instruction +
            f'Write the ABC quarter-note tempo header exactly as Q:1/4={request["tempoBPM"]}. '
            f'Make {tonic} the tonal center of both melody and harmony throughout the score. '
            'Generate the actual notes and chords to match; do not just change header text.')


def planning_abc_key(request):
    """Constrain the tonic even when a key signature cannot express the scale.

    Harmonic/melodic minor use the minor signature and note-level alterations.
    Diagnostics must still report that the requested scale is not verified.
    """
    key = exact_abc_key(request)
    if key is not None:
        return key
    signature_modes = {'harmonicMinor': 'naturalMinor', 'melodicMinor': 'naturalMinor',
                       'minorPentatonic': 'naturalMinor', 'majorPentatonic': 'major'}
    mode = signature_modes.get(request['scale'])
    return exact_abc_key(dict(request, scale=mode)) if mode else None


def fresh_planning_seed(original):
    while True:
        seed = secrets.randbelow(2**32 - 1) + 1
        if seed != original:
            return seed


def score_bar_limit(request):
    if request['yue2'].get('autoDuration') is True:
        return None
    target_bars = math.ceil(request['durationSeconds'] * request['tempoBPM'] / 240)
    return max(64, target_bars * 6)


def repeated_score_cycle(score):
    if score.count('|') < 200:
        return False
    complete = score if score.endswith('\n') else score.rsplit('\n', 1)[0]
    lines = [line.strip() for line in complete.splitlines()
             if line.strip() and not line.lstrip().startswith('%')]
    for size in range(1, 13):
        if len(lines) < size * 3:
            continue
        cycle = lines[-size:]
        if sum(line.count('|') for line in cycle) < 4:
            continue
        if all(lines[-size * (repeat + 1):-size * repeat] == cycle for repeat in range(1, 3)):
            return True
    return False


class ScoreLengthGuard:
    def __init__(self, tokenizer, bar_limit, progress):
        self.tokenizer = tokenizer
        self.bar_limit = bar_limit
        self.progress = progress
        self.ids = []
        self.stop_reason = None
        self.repetition_detected = False
        self.bar_estimate_exceeded = False

    def __call__(self, phase, token):
        self.ids.append(token)
        self.progress(phase, token)
        if len(self.ids) % 64 == 0:
            score = self.tokenizer.decode(self.ids)
            if self.bar_limit is not None and score.count('|') > self.bar_limit:
                # ABC bar markers span voices and compressed rests; they are
                # not elapsed audio duration. The model's end token and bounded
                # token budget decide score completion. Semantic tokens cap audio.
                self.bar_estimate_exceeded = True
            if repeated_score_cycle(score):
                # Recurring passages across multiple voices are not evidence of
                # non-termination. Let the model finish within its token budget.
                self.repetition_detected = True


def retry_score_prefill(request, previous_score):
    """Constrain a new score using the model's complete ABC header layout.

    A bare X/Q/K prefix leaves out meter, units and voice declarations. On real
    failed seeds this produced malformed declarations and looping continuations.
    Keep valid meter/units from the first header, but never reuse its music.
    """
    key = planning_abc_key(request)
    if not key:
        return None
    fields = {'M': '4/4', 'L': '1/16'}
    for line in previous_score.splitlines():
        if re.match(r'^\s*K:', line):
            break
        match = re.fullmatch(r'\s*([ML]):\s*([^%]*?)(?:\s*%.*)?', line)
        if match:
            name, value = match[1], match[2].strip()
            if re.fullmatch(r'[1-9]\d*/[1-9]\d*', value) or (name == 'M' and value in ('C', 'C|')):
                fields[name] = value
    lines = ['X:1', 'T:', f'M:{fields["M"]}', f'L:{fields["L"]}',
             f'Q:1/4={request["tempoBPM"]}',
             'V: Vocal clef=treble name="Vocal Melody" snm="Vocal"']
    if request['yue2']['planning'] == 'full':
        lines.append('V: Ins clef=treble name="Ins Melody" snm="Inst."')
    return '\n'.join(lines + [f'K:{key}', ''])


def conflicting_retry_headers(score, prefill):
    if not prefill:
        return []
    if not score.startswith(prefill):
        return ['Constrained ABC prefill was not preserved in the generated score.']
    expected = dict(re.findall(r'^([QK]):\s*(.*?)\s*$', prefill, re.MULTILINE))
    conflicts = []
    for line in score[len(prefill):].splitlines():
        code = line.split('%', 1)[0]
        fields = []
        header = re.match(r'^\s*([KQ]):\s*(.*?)\s*$', code)
        if header:
            fields.append(header)
        fields.extend(re.finditer(r'\[([KQ]):\s*([^\]\r\n]*)\]', code))
        for field in fields:
            if field.group(2).strip() != expected[field.group(1)]:
                conflicts.append(f'Generated score overrides constrained {field.group(1)} header with {field.group(2).strip()}.')
    return conflicts


def score_length_instruction(request, strict=False):
    if request['yue2'].get('autoDuration') is True:
        # Recovery guidance, not a duration cap: accept only a genuinely finished
        # score, and leave the first natural-duration attempt unconstrained.
        return ('The previous score exhausted its notation budget. Write a compact, complete '
                'arrangement of about 32 bars per voice: a short intro, one main section, '
                'and a clear ending. End all score voices at the same point. Do not restart the '
                'arrangement or extend the ending.'
                if strict else '')
    bars = math.ceil(request['durationSeconds'] * request['tempoBPM'] / 240)
    instruction = (f'For this {request["durationSeconds"]}-second song at {request["tempoBPM"]} BPM, '
                   f'write about {bars} bars per voice, then finish the ABC score. ')
    if strict:
        instruction += 'The previous score grew too long. Do not repeat whole sections or extend the ending.'
    return instruction


def plan_score(request, pipe, artifacts, log, generate_tokens, token_prefix):
    options = request['yue2']
    base_style = conditioned_style(request)
    bar_limit = score_bar_limit(request)
    attempts = []
    retry_reason = None
    for number in (1, 2):
        if retry_reason == 'headers':
            style = corrective_planning_style(request, base_style)
        else:
            style = base_style
        guidance = score_length_instruction(request, strict=retry_reason == 'length')
        if guidance:
            style += '\n' + guidance
        seed = request['seed'] if number == 1 else fresh_planning_seed(request['seed'])
        prefill = retry_score_prefill(request, score) if number == 2 else None
        prefill_ids = pipe.tokenizer.encode(prefill) if prefill else []
        prefix = token_prefix(pipe.tokenizer, style, request['lyrics'].strip(), options['planning'])
        prefix += prefill_ids
        guard = ScoreLengthGuard(pipe.tokenizer, bar_limit, pipe._progress('abc'))
        log('[plan] generating ABC score')
        suffix_ids, truncated = generate_tokens(pipe.model, prefix, pipe.abc_sampling,
            seed, 'abc', on_token=guard)
        ids = prefill_ids + suffix_ids
        score = pipe.tokenizer.decode(ids)
        score_file = f'score-attempt-{number}.abc'
        (artifacts/score_file).write_text(score)
        mismatches, unavailable = score_header_diagnostics(score, request) if score.strip() and not truncated else ([], [])
        mismatches.extend(conflicting_retry_headers(score, prefill))
        attempt = {'attempt': number, 'seed': seed, 'style': style, 'scoreFile': score_file,
                   'prefill': prefill, 'prefillTokenCount': len(prefill_ids),
                   'generatedTokenCount': len(suffix_ids),
                   'notationTokenBudget': getattr(pipe.abc_sampling, 'max_tokens', None),
                   'barMarkerLimit': bar_limit, 'barMarkers': score.count('|'),
                   'stoppedEarly': False, 'stopReason': guard.stop_reason,
                   'barEstimateExceeded': guard.bar_estimate_exceeded,
                   'repetitionDetected': guard.repetition_detected,
                   'mismatches': mismatches, 'warnings': unavailable, 'accepted': False}
        attempts.append(attempt)
        if truncated:
            attempt['error'] = 'YuE2 did not finish the ABC score within its notation token budget.'
        elif not score.strip():
            attempt['error'] = 'Planning returned an empty score.'
        elif not mismatches:
            attempt['accepted'] = True
        (artifacts/'planning-attempts.json').write_text(json.dumps(attempts, indent=2, ensure_ascii=False))
        if attempt['accepted']:
            (artifacts/'score.abc').write_text(score)
            return score, ids, attempts, unavailable, []
        if number == 1 and truncated:
            retry_reason = 'length'
            log('YUE2_PLAN_RETRY ABC score kept growing; trying a shorter plan with a fresh seed.')
            continue
        if attempt.get('error'):
            if truncated:
                duration = (f'the {request["durationSeconds"]}-second request'
                            if bar_limit is not None else 'the requested song')
                raise ValueError(f'YuE2 did not finish the ABC score for {duration} after two attempts. '
                                 'The generated notation ran too long; the lyrics are not too long. '
                                 'The score exhausted its notation token budget before the end token.')
            raise ValueError(attempt['error'])
        if number == 1:
            retry_reason = 'headers'
            log('YUE2_PLAN_RETRY Correcting score header mismatch with a fresh planning seed.')
    (artifacts/'score.abc').write_text(score)
    return score, ids, attempts, unavailable, mismatches


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--request-json', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--plan-only', action='store_true')
    parser.add_argument('--audition-context-stdin', action='store_true')
    parser.add_argument('--imported-sound-store', type=Path,
                        help='App-managed imported-sound root; never read from recipe JSON.')
    args = parser.parse_args()
    request = json.loads(args.request_json)
    options = request['yue2']
    audition_context = (read_audition_context(sys.stdin.buffer, request, args.model, args.out)
                        if args.audition_context_stdin else None)
    validate_options(options, request['durationSeconds'])
    composer_manifest = verify_composer_reference(options)
    composer_score_inputs = read_composer_score_inputs(options, composer_manifest, request, audition_context)
    if request['provider'] != 'yue2-mlx' or request['modelID'] not in (REPOSITORY, 'goldhub/YuE2-RS-Finetunes'):
        raise ValueError('Recipe is not a YuE2 recipe.')
    out = args.out.absolute()
    artifacts = reserve_output(out)
    started = time.monotonic()
    (artifacts/'request.json').write_text(json.dumps(request, indent=2, ensure_ascii=False))
    if composer_manifest is not None:
        (artifacts/'composer.json').write_text(json.dumps(composer_manifest, indent=2, ensure_ascii=False))
    if composer_score_inputs is not None:
        (artifacts/'score-inputs.json').write_bytes(composer_score_inputs)
    print('PIXEL_MUSIC_PROGRESS=0.04 YuE2 loading and verifying BF16', flush=True)
    lock, hashes = verify_install(args.model)
    validate_backbone_request(request, lock)
    imported_mode = imported_application_mode(options, args.plan_only)
    verified_imported = None
    if audition_context is not None:
        if args.plan_only or options.get('decodeLatentsPath'):
            raise ValueError('Comparison requires a newly rendered audio preview.')
        if (audition_context['role']=='adapted' and options['planning']!='off'
                and not options.get('abc','').strip()):
            raise ValueError('Adapted comparison requires the captured baseline ABC score.')
        imported_sound_store().validate_audition(audition_context,args.model,
                                               expected_store=args.imported_sound_store)
    if imported_mode == 'active':
        verified_imported = resolve_active_imported_sound(options,args.model,audition_context,
                                                         args.imported_sound_store)
    # Off/bypass selections can still need reporting after the model path is added.
    if options.get('importedSound') is not None or audition_context is not None:
        preload_imported_sound_bridge()
    if audition_context is not None:
        (artifacts/'review-context.json').write_text(json.dumps(audition_context,indent=2,ensure_ascii=False))
    trained_style = style_adapter.verify(options, args.model) if should_apply_trained_style(options, args.plan_only) else None
    sys.path.insert(0, str(args.model))
    import mlx.core as mx
    import numpy as np
    from generate import Yue2Pipeline, Sampling, write_wav, generate_tokens, token_prefix
    if not mx.metal.is_available():
        raise RuntimeError('Apple Silicon Metal is required.')
    warnings = []
    def log(message):
        print(message, flush=True)
        if '[plan] ABC hit max_tokens' in message:
            raise ValueError('YuE2 did not finish the ABC score within its notation token budget.')
        if '[semantic] hit max_tokens' in message:
            warnings.append('Length cap reached; the song may end before a natural ending.')
            print('YUE2_TRUNCATED', flush=True)
        if message.startswith('[plan]'):
            print('PIXEL_MUSIC_PROGRESS=0.12 YuE2 conditioning score', flush=True)
        elif message.startswith('[semantic]'):
            print('PIXEL_MUSIC_PROGRESS=0.25 YuE2 generating song tokens', flush=True)
        elif message.startswith('[nar]'):
            print('PIXEL_MUSIC_PROGRESS=0.65 YuE2 generating acoustic latents', flush=True)
        elif message.startswith('[vae]'):
            print('PIXEL_MUSIC_PROGRESS=0.94 YuE2 decoding', flush=True)
    pipe = Yue2Pipeline(args.model/'bf16', log=log)
    if trained_style is not None:
        style_adapter.apply(pipe.model, trained_style)
    if args.plan_only:
        if options['planning'] == 'off':
            raise ValueError('Score planning requires melody or full mode.')
        score, ids, planning_attempts, unavailable, mismatches = plan_score(
            request, pipe, artifacts, log, generate_tokens, token_prefix)
        warnings.extend(mismatches + unavailable)
        for warning in warnings:
            print('YUE2_SCORE_WARNING ' + warning, flush=True)
        (artifacts/'tokens.json').write_text(json.dumps({'abc': ids}))
        sound_report = imported_sound_report(options, imported_mode)
        if sound_report is not None:
            (artifacts/'imported-sound.json').write_text(json.dumps(sound_report, indent=2, ensure_ascii=False))
        (artifacts/'result.json').write_text(json.dumps({'operation': 'plan', 'request': request,
            'repository': lock['repository'], 'revision': lock['revision'], 'precision': 'bf16',
            'adapterSHA256': sha256(__file__), 'modelFiles': hashes, 'modelComponents': lock.get('components', {}),
            'abcSampling': pipe.abc_sampling.__dict__, 'elapsedSeconds': time.monotonic()-started,
            'warnings': warnings, 'planningAttempts': planning_attempts,
            'files': {p.name: sha256(p) for p in artifacts.iterdir() if p.is_file()}}, indent=2))
        if mismatches:
            raise ValueError('Automatically planned score differs from the request after 2 attempts. '
                             f'Diagnostics: {artifacts/"planning-attempts.json"}. ' + ' '.join(mismatches))
        return
    duration = request['durationSeconds']
    budget = semantic_budget(options, duration, pipe.semantic_sampling.max_tokens)
    sampling = Sampling(temperature=options['temperature'], top_p=options['topP'],
                        top_k=options['topK'], repetition_penalty=options['repetitionPenalty'],
                        penalty_window=options['penaltyWindow'], min_tokens=min(pipe.semantic_sampling.min_tokens, budget),
                        max_tokens=budget)
    latent_path = artifacts/'audio.latents.npy'
    sound_report = None
    if options.get('decodeLatentsPath'):
        sound_report = imported_sound_report(options, 'latent_redecode')
        source = Path(options['decodeLatentsPath'])
        verify_latent(source, options['decodeLatentsSHA256'])
        source_sound = source_imported_sound(source)
        if sound_report is None and source_sound is not None:
            sound_report = {'selection': None, 'applied': False,
                            'reason': 'latent_redecode', 'effectiveScales': {},
                            'sourceOutputID': options.get('sourceOutputID')}
        if sound_report is not None:
            sound_report['sourceSound'] = source_sound
        shutil.copyfile(source, latent_path)
        latent = np.load(latent_path, allow_pickle=False)
        if latent.ndim != 2 or latent.shape[1] != 64 or not 1 <= latent.shape[0] <= 9000 or not np.isfinite(latent).all():
            raise ValueError('Source latents have invalid dimensions or values.')
        audio = pipe.decode(mx.array(latent))
        info = {}
        for name in ('score.abc', 'tokens.json'):
            if (source.parent/name).is_file():
                shutil.copyfile(source.parent/name, artifacts/name)
    else:
        style = conditioned_style(request)
        supplied_score = options.get('abc') if options.get('abc', '').strip() else None
        planning_attempts = None
        if options['planning'] != 'off':
            if supplied_score is None:
                supplied_score, planned_ids, planning_attempts, unavailable, mismatches = plan_score(
                    request, pipe, artifacts, log, generate_tokens, token_prefix)
                if mismatches:
                    raise ValueError('Automatically planned score differs from the request after 2 attempts. '
                                     f'Diagnostics: {artifacts/"planning-attempts.json"}. ' + ' '.join(mismatches))
            else:
                mismatches, unavailable = score_header_diagnostics(supplied_score, request)
            warnings.extend(mismatches + unavailable)
            for warning in mismatches + unavailable:
                print('YUE2_SCORE_WARNING ' + warning, flush=True)
        if imported_mode == 'active':
            applied = apply_active_imported_sound(pipe.model, options, args.model, audition_context,
                                                 verified=verified_imported)
            sound_report = imported_sound_report(options, 'applied', applied)
        else:
            sound_report = imported_sound_report(options, imported_mode)
        if options.get('autoDuration', False):
            import generate as backend
            from yue2_finish import generate_finished
            audio, info = generate_finished(pipe, backend, style=style, lyrics=request['lyrics'].strip(),
                cot=options['planning'], abc=supplied_score, seed=request['seed'],
                guidance=options['guidance'], sampling=sampling, steps=options['steps'],
                on_latents=lambda z: np.save(latent_path, np.array(z)), artifacts=artifacts, log=log)
        else:
            audio, info = pipe(style, request['lyrics'].strip(), cot=options['planning'],
                seed=request['seed'], abc=supplied_score,
                cfg_scale=options['guidance'], semantic_sampling=sampling, steps=options['steps'],
                on_latents=lambda z: np.save(latent_path, np.array(z)))
        if supplied_score is not None and info.get('abc') != supplied_score:
            raise ValueError('YuE2 did not report the exact supplied ABC score.')
        if info.get('abc') is not None:
            (artifacts/'score.abc').write_text(info['abc'])
        tokens = {'codec':info['codec'], 'prefix':info['prefix']}
        if planning_attempts is not None:
            tokens['abc'] = planned_ids
        (artifacts/'tokens.json').write_text(json.dumps(tokens))
    finalized_composer_score = finalize_composer_manifest(artifacts)
    if sound_report is not None:
        (artifacts/'imported-sound.json').write_text(json.dumps(sound_report, indent=2, ensure_ascii=False))
    pcm = np.array(audio, dtype=np.float32)
    if pcm.ndim != 2 or pcm.shape[1] != 2 or pcm.shape[0] == 0 or not np.isfinite(pcm).all():
        raise ValueError('YuE2 did not return finite stereo audio.')
    # Write inside the reserved bundle; publish with a link that fails if a master exists.
    staged = artifacts/'render.wav'
    write_wav(staged, audio)
    report = {'repository':lock['repository'], 'revision':lock['revision'], 'precision':'bf16',
        'runtime':{name:importlib.metadata.version(name) for name in ('mlx','numpy','tiktoken')},
        'adapterSHA256':sha256(__file__), 'modelFiles':hashes, 'modelComponents':lock.get('components', {}), 'request':request,
        'ending':info.get('ending'),
        'endingAdapterSHA256':sha256(Path(__file__).with_name('yue2_finish.py')),
        'sampling':sampling.__dict__, 'abcSampling':pipe.abc_sampling.__dict__,
        'elapsedSeconds':time.monotonic()-started, 'durationSeconds':pcm.shape[0]/48000,
        'sampleRate':48000, 'channels':2, 'warnings':warnings,
        'sourceOutputID':options.get('sourceOutputID'),
        'trainedStyle':trained_style, 'trainedStyleApplied':trained_style is not None,
        'importedSound':sound_report,
        'sourceScorePath':options.get('sourceScorePath'), 'sourceScoreSHA256':options.get('sourceScoreSHA256'),
        'planningAttempts': planning_attempts if not options.get('decodeLatentsPath') else None,
        'emotionalComposerApplied':composer_manifest is not None,
        'audioSHA256':sha256(staged),
        'files':{p.name:sha256(p) for p in artifacts.iterdir() if p.is_file() and p != staged}}
    if audition_context is not None:
        context_path=artifacts/'review-context.json'
        report['auditionContext']={'path':str(context_path),'sha256':report['files'][context_path.name]}
    (artifacts/'result.json').write_text(json.dumps(report, indent=2, ensure_ascii=False))
    os.link(staged, out)
    staged.unlink()
    print('PIXEL_MUSIC_PROGRESS=0.98 YuE2 writing WAV and provenance', flush=True)
    if finalized_composer_score is not None and not options.get('decodeLatentsPath'):
        print('YUE2_COMPOSER_APPLIED', flush=True)

if __name__ == '__main__':
    main()
