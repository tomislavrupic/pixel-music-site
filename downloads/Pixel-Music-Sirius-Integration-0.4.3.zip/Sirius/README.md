# Pixel Music MCP integration v1

Requires Pixel Music 0.4.2 or later on Apple Silicon/macOS 14+. Install the app
in /Applications, keep it open, and enable local MCP access in Settings.
Enable control separately for generation, project changes and playback.
No model downloads or inference run on connection. Runtime installation remains
an explicit action inside Pixel Music. There is no TCP listener or cloud relay.

Register the helper from mcp-client.json with your MCP host. Codex users can use
Settings → Codex & Sirius → SET UP CODEX, or merge codex-config.toml into their
configuration. Restart/reconnect the host after registration. Existing conflicting
registrations must be reviewed explicitly; do not replace unrelated configuration.

Sirius: pass the pixel-music entry in mcp-client.json to your session's mcpServers
configuration. This package provides a standard stdio connection, not a persistent
Sirius installer. The adapter is a reference client, not a new execution runtime.
Install its dependency in your own environment: `python -m pip install mcp`.
Run `python smoke_test.py` for a read-only status/handshake test.

Workflow: list projects → choose projectID → generate with a fresh UUID requestID →
poll each returned jobID until completed/failed/cancelled → read output provenance.
Reuse the SAME requestID AND exact arguments only when retrying an uncertain
submission. Changed arguments with a reused requestID are rejected. Deduplication
and job tracking last for the current app process, including access toggles.
After restart, query project outputs before considering another submission.
Disconnecting a client does not cancel generation; cancel_job targets one job.
A completed job is not automatically selected, published or artist-approved.

Tools and input schemas are generated in contract.json. Result envelope:
{schemaVersion:1,id:UUID,result:JSON|null,error:{code,message}|null}.
MCP tool errors set isError; inspect the envelope rather than treating connection
success as successful generation. Read tools: status, projects, outputs, job.
Control tools: open_project, generate, cancel_job, play_output, stop_playback.
Generation uses the selected engine and configured model/runtime paths; YuE2-only
fields are rejected on legacy engines. This first version does not expose training,
style approval/import, arbitrary paths, deletion, uploads or shell execution.
Outputs list the newest 200 nondeleted records and report truncation explicitly.
Never assume duration caps guarantee a natural ending or tempo/key guarantee timing.

Privacy: the helper and app communicate through an owner-checked private Unix
socket. Tool results can include local filenames, prompts and provenance. Your MCP
host controls what it sends to its language model/service; local inference does
not make an external Codex session offline. Model downloads/update checks remain
separate existing app operations. No songs or weights are included in this package.
YuE2 model weights inherit CC BY-NC 4.0; this bridge does not change that license.

If a multi-take submission accepts only some takes, state is partially-queued,
jobIDs names the accepted jobs and submissionError explains the failure. Retrying
the same request returns this outcome without duplicating those jobs.
