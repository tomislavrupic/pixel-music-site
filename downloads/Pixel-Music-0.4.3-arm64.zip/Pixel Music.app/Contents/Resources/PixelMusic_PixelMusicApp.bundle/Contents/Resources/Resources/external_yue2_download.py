"""Pinned data-only downloads; the existing importer still owns publication.

Never executes publisher code, runs inference, approves, or selects a sound.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import ssl
import struct
import tempfile
from urllib.parse import urlparse
from urllib.request import HTTPSHandler, HTTPRedirectHandler, Request, build_opener

from external_yue2_format import (CHUNK_BYTES, MAX_ADAPTER_BYTES, fail,
    inspect_adapter, open_regular, read_json_file, strict_json, tensor_header)
from external_yue2_import import check_cancelled, new_file


def allowed_url(url: str) -> bool:
    parts = urlparse(url)
    host = parts.hostname or ''
    return (parts.scheme == 'https' and parts.port in (None, 443)
            and parts.username is None and parts.password is None
            and (host == 'huggingface.co' or host.endswith('.huggingface.co') or host.endswith('.hf.co')))


class SafeRedirect(HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, url):
        if not allowed_url(url):
            fail('unsafe_url', 'Download redirected outside the approved HTTPS hosts.')
        return super().redirect_request(request, response, code, message, headers, url)


def open_download(url):
    try:
        import certifi
        context = ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        context = ssl.create_default_context()
    opener = build_opener(SafeRedirect(), HTTPSHandler(context=context))
    return opener.open(Request(url, headers={'User-Agent': 'PixelMusic-LoRA/1', 'Accept-Encoding': 'identity'}), timeout=30)


def relative_path(value):
    if (not isinstance(value, str) or not value or '\\' in value or '\0' in value
            or '?' in value or '#' in value or '%' in value
            or PurePosixPath(value).is_absolute() or any(x in ('', '.', '..') for x in value.split('/'))):
        fail('unsafe_path', 'Download paths must be clean relative paths.')
    return value


def download_file(repo, revision, asset, root, *, open_url=open_download, progress=lambda _: None, cancelled=None):
    if not re.fullmatch(r'[\w.-]+/[\w.-]+', repo) or not re.fullmatch(r'[a-f0-9]{40}', revision):
        fail('invalid_catalog', 'Downloads require an exact pinned publisher revision.')
    destination = Path(root)/relative_path(asset['path'])
    source = relative_path(asset['source'])
    size, digest = asset['bytes'], asset['sha256']
    if type(size) is not int or not 0 < size <= MAX_ADAPTER_BYTES or not re.fullmatch(r'[a-f0-9]{64}', digest):
        fail('invalid_catalog', 'Download size and SHA-256 must be pinned.')
    from external_yue2_store import ensure_directory
    check_cancelled(cancelled)
    ensure_directory(destination.parent)
    # Never overwrite a cache/source file or delete an existing file on failure.
    if destination.exists() or destination.is_symlink():
        fail('destination_exists', 'The download destination already exists.')
    created = False
    try:
        with open_url(f'https://huggingface.co/{repo}/resolve/{revision}/{source}') as response:
            if response.status != 200 or not allowed_url(response.geturl()):
                fail('download_failed', 'Publisher did not return a safe, complete file.')
            with new_file(destination) as output:
                created = True
                checksum, count = hashlib.sha256(), 0
                while True:
                    check_cancelled(cancelled)
                    chunk = response.read(CHUNK_BYTES)
                    if not chunk:
                        break
                    count += len(chunk)
                    if count > size:
                        fail('size_mismatch', 'Download exceeded the pinned file size.')
                    output.write(chunk); checksum.update(chunk); progress(count)
                check_cancelled(cancelled)
                if count != size:
                    fail('size_mismatch', 'Download was incomplete; nothing was installed.')
                if checksum.hexdigest() != digest:
                    fail('checksum_mismatch', 'Download checksum did not match; nothing was installed.')
    except BaseException:
        if created:
            destination.unlink(missing_ok=True)
        raise
    return destination


def prepare_distilled(source: Path, folder: Path, *, cancelled=None):
    """Repack verified ordinary NTC A/B factors, not nonlinear particle weights.

    The only change is tensor names/layout. Factors and alpha/r are unchanged.
    Original publisher hash is retained in the generated, immutable config.
    """
    from external_yue2_store import ensure_directory
    with open_regular(source, MAX_ADAPTER_BYTES) as stream:
        header, data_start = tensor_header(stream, source.stat().st_size)
        meta = strict_json(header.get('__metadata__', {}).get('conceptmod', '{}').encode())
        if (meta.get('format') != 'conceptmod-yue2-ar-v1' or meta.get('ordinary_lora') is not True
                or meta.get('model_id') != 'm-a-p/YuE2-3B' or not isinstance(meta.get('targets'), list)):
            fail('unsupported_algorithm', 'Only publisher-described ordinary AR distills can be repacked; not particle adapters.')
        rank, alpha = meta.get('rank'), meta.get('alpha')
        if type(rank) is not int or rank < 1 or type(alpha) not in (int,float) or alpha <= 0:
            fail('invalid_config', 'Distill requires explicit rank and alpha.')
        output_header, pieces, expected, offset = {}, [], {'__metadata__'}, 0
        for target in meta['targets']:
            from external_yue2_format import TARGET
            if not isinstance(target,str) or not TARGET.fullmatch(target) or 'nar_' in target:
                fail('unsupported_tensor', 'Distilled target is not an ordinary AR projection.')
            prefix = 'adapters.' + target.replace('.', '-')
            alpha_key = prefix+'.alpha'; expected.add(alpha_key)
            spec = header.get(alpha_key, {})
            if spec.get('dtype') != 'F32' or spec.get('shape') != []:
                fail('invalid_config', 'Distill alpha must be an explicit F32 scalar.')
            start,end = spec['data_offsets']; stream.seek(data_start+start)
            if end-start != 4 or struct.unpack('<f',stream.read(4))[0] != alpha:
                fail('invalid_config', 'Distill tensor alpha differs from publisher metadata.')
            for old,new in (('.lora_down.weight','.lora_A'),('.lora_up.weight','.lora_B')):
                key = prefix+old; expected.add(key)
                spec = header.get(key)
                if not spec:
                    fail('missing_factor', 'Distill has incomplete factors.')
                start,end = spec['data_offsets']
                output_header[target+new] = dict(dtype=spec['dtype'], shape=spec['shape'],data_offsets=[offset,offset+end-start])
                pieces.append((start,end)); offset += end-start
        if set(header) != expected or not pieces:
            fail('unsupported_tensor', 'Distill contains unrecognized or duplicate target tensors.')
        ensure_directory(folder)
        output_header['__metadata__'] = {'publisher_format':meta['format'], 'conversion':'names-only; factors and alpha/r unchanged'}
        encoded = json.dumps(output_header,separators=(',',':')).encode()
        encoded += b' '*((-len(encoded))%8)
        with new_file(folder/'lora.safetensors') as output:
            output.write(struct.pack('<Q',len(encoded))); output.write(encoded)
            for start,end in pieces:
                stream.seek(data_start+start)
                remaining = end-start
                while remaining:
                    check_cancelled(cancelled)
                    chunk = stream.read(min(CHUNK_BYTES,remaining))
                    if not chunk: fail('source_changed','Publisher weights were truncated during repacking.')
                    output.write(chunk); remaining -= len(chunk)
        from external_yue2_format import digest_file
        config = dict(rank=rank,alpha=alpha,ar=True,include_heads=False,base_model=meta['model_id'],
                      publisher_weights_sha256=digest_file(source),publisher_format=meta['format'])
        with new_file(folder/'adapter_config.json') as output:
            output.write(json.dumps(config,indent=2).encode())
    inspect_adapter(folder)


def catalog():
    return read_json_file(Path(__file__).with_name('external_yue2_catalog.json'), 256*1024)['packs']


def install_pack(pack, store, *, open_url=open_download, progress=lambda _value, _status: None, cancelled=None):
    from external_yue2_store import import_sound
    total = sum(asset['bytes'] for asset in pack['files'])
    completed = 0
    with tempfile.TemporaryDirectory(prefix='pixel-lora-') as temporary:
        root = Path(temporary).resolve()
        for asset in pack['files']:
            status = 'Downloading ' + pack['name']
            progress(completed/total,status)
            download_file(pack['repo'], pack['revision'], asset, root, open_url=open_url,
                cancelled=cancelled, progress=lambda count: progress(min(.94,(completed+count)/total*.94),status))
            completed += asset['bytes']
        if pack.get('conversion') == 'ntc-ordinary-ar':
            prepare_distilled(root/'publisher.safetensors', root/'AR', cancelled=cancelled)
        elif pack.get('conversion') is not None:
            fail('unsupported_algorithm','Catalog specifies an unsupported conversion.')
        check_cancelled(cancelled)
        progress(.95,'Verifying and importing')
        texts = {'card':root/'README.md'} if (root/'README.md').exists() else {}
        result = import_sound(store,[root/relative_path(folder) for folder in pack['folders']],
                              name=pack['name'],text_files=texts,cancelled=cancelled)
        progress(1,'Installed · compare before use')
        return result
