"""Local-only external YuE2 inspection, source normalization, and import CLI.

Normalization here preserves the *source* projection layout. It is not permission
to merge weights into MLX. No production layout is enabled without a reviewed,
pinned source-to-destination mapping. The normalizer adds no model dependency.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import signal
import struct
import sys
from typing import BinaryIO, Callable, Iterator

from external_yue2_format import (AdapterFormatError, CHUNK_BYTES, MAX_ADAPTER_BYTES,
    MAX_CONFIG_BYTES, MAX_HEADER_BYTES, MAX_TENSOR_ENTRIES, absolute_path, digest_file, digest_stream, discover_adapters,
    fail, inspect_adapter, open_directory, open_regular, read_json_file, TARGET,
    scan_finite, tensor_header)

BASE_REPOSITORY = 'ahmadw/YuE2-3B-MLX'
BASE_REVISION = 'fe0a9050fd658257b486b880422d8872ee1f81e3'
NORMALIZED_FORMAT = 'pixel-music-external-yue2-tensors-v1'
NORMALIZER_VERSION = 1
LAYOUT_ID = 'yue2-mlx-linear-identity-v1'
# Pinned local files were independently hashed. convert.py at the pinned MLX
# source revision renames only time_embedder keys; its VAE transpose does not
# touch any of the linear targets accepted below.
BASE_DIGESTS = {
    'bf16/model.safetensors': 'e6012e94aca961eebc2f57ae0c5417b1f40125c33c41e5f3a6ca0b28982361f7',
    'bf16/config.json': 'ad3477bbef890bf98ae196c1e4b44779494a6231c4ab66f32708eabadf265329',
    'yue2_model.py': 'ef5230b3dea7f5b4823c1c1de159228c7199266b30ea68ca79ced4f0c7d0190e',
    'generate.py': '5de06be8d3db45dc72c7cd780ed50e6bbac9453b272992b32a1c81d8e042fc0d',
    'yue2_vae.py': 'f45e397485be682649b36257e9c76b9184fa460f0abedf05ff3bb21c66ab216b',
}


@contextmanager
def new_file(path: Path) -> Iterator[BinaryIO]:
    """Create once; on failure remove only the inode this call created."""
    path = absolute_path(path)
    with open_directory(path.parent) as parent:
        try:
            fd = os.open(path.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                         0o600, dir_fd=parent)
        except FileExistsError:
            fail('destination_exists', f'Will not overwrite {path}.')
        own = os.fstat(fd)
        try:
            with os.fdopen(fd, 'wb') as stream:
                yield stream
                stream.flush()
                os.fsync(stream.fileno())
        except BaseException:
            try:
                named = os.stat(path.name, dir_fd=parent, follow_symlinks=False)
                if (named.st_dev, named.st_ino) == (own.st_dev, own.st_ino):
                    os.unlink(path.name, dir_fd=parent)
            except FileNotFoundError:
                pass
            raise


def check_cancelled(cancelled: Callable[[], bool] | None) -> None:
    if cancelled is not None and cancelled():
        fail('cancelled', 'Import cancelled; no existing sound was changed.')


def cancellable_digest_stream(stream: BinaryIO, cancelled=None) -> str:
    stream.seek(0)
    digest=hashlib.sha256()
    while True:
        check_cancelled(cancelled)
        chunk=stream.read(CHUNK_BYTES)
        if not chunk: break
        digest.update(chunk)
    check_cancelled(cancelled)
    return digest.hexdigest()


def cancellable_digest_file(path: Path, limit: int | None=None, cancelled=None) -> str:
    check_cancelled(cancelled)
    with open_regular(path,limit) as stream:
        return cancellable_digest_stream(stream,cancelled)


def validate_local_base(model_root: Path, *, cancelled=None) -> dict:
    """Bind the exact pinned BF16 backbone and its verified linear layout."""
    check_cancelled(cancelled)
    root = absolute_path(model_root)
    lock = read_json_file(root/'.pixel-music-model-lock.json')
    if lock.get('repository') != BASE_REPOSITORY or lock.get('revision') != BASE_REVISION:
        fail('base_mismatch', 'External sound v1 requires the pinned YuE2 BF16 runtime.')
    config = read_json_file(root/'bf16/config.json')
    if config.get('quantization') is not None or config.get('quantization_config') is not None:
        fail('unsupported_quantization', 'External adapter conversion requires unquantized BF16 weights.')
    # The identity gate is independent of a caller-controlled manifest or marker.
    for name, expected in BASE_DIGESTS.items():
        try:
            observed = (digest_file(root/name) if cancelled is None else
                        cancellable_digest_file(root/name,cancelled=cancelled))
        except AdapterFormatError as exc:
            if exc.code == 'missing_file':
                fail('unverified_base_layout', f'Pinned base file missing: {name}.')
            raise
        if observed != expected:
            fail('unverified_base_layout', f'Pinned base file changed: {name}.')
    if config.get('dtype') != 'bfloat16' or config.get('num_hidden_layers') != 28:
        fail('unverified_base_layout', 'Unexpected BF16 model configuration.')
    with open_regular(root/'bf16/model.safetensors') as source:
        header, _ = tensor_header(source, os.fstat(source.fileno()).st_size)
    if header.get('__metadata__', {}).get('format') != 'mlx':
        fail('unverified_base_layout', 'Unexpected base tensor format.')
    shapes = {}
    for key, entry in header.items():
        check_cancelled(cancelled)
        if key == '__metadata__' or not key.endswith('.weight'):
            continue
        module = key[:-7]
        if module in ('vae2llm', 'llm2vae') or TARGET.fullmatch(module):
            # TARGET accepts only the seven linear projections per branch.
            if entry['dtype'] != 'BF16' or len(entry['shape']) != 2:
                fail('unverified_base_layout', f'Unexpected projection layout: {key}.')
            shapes[key] = entry['shape']
    if len(shapes) != 28 * 14 + 2:
        fail('unverified_base_layout', 'Incomplete AR/NAR projection inventory.')
    h, i, d = config['hidden_size'], config['intermediate_size'], config['latent_dim']
    q = config['num_attention_heads'] * config['head_dim']
    kv = config['num_key_value_heads'] * config['head_dim']
    expected_projections = {'q_proj': [q,h], 'k_proj': [kv,h], 'v_proj': [kv,h],
                            'o_proj': [h,q], 'gate_proj': [i,h], 'up_proj': [i,h],
                            'down_proj': [h,i]}
    for index in range(28):
        check_cancelled(cancelled)
        for branch in ('', 'nar_'):
            for projection, shape in expected_projections.items():
                family = 'self_attn' if projection.endswith('_proj') and projection[0] in 'qkvo' else 'mlp'
                key = f'model.layers.{index}.{branch}{family}.{projection}.weight'
                if shapes.get(key) != shape:
                    fail('unverified_base_layout', f'Unexpected projection shape: {key}.')
    if shapes.get('vae2llm.weight') != [h,d] or shapes.get('llm2vae.weight') != [d,h]:
        fail('unverified_base_layout', 'Unexpected latent head orientation.')
    try:
        mlx_version = importlib.metadata.version('mlx')
    except importlib.metadata.PackageNotFoundError:
        fail('runtime_unavailable', 'The normal YuE2 MLX runtime is required for bound conversion.')
    return {'repository': BASE_REPOSITORY, 'revision': BASE_REVISION,
            'modelRoot': str(root), 'modelSHA256': BASE_DIGESTS['bf16/model.safetensors'],
            'configSHA256': BASE_DIGESTS['bf16/config.json'],
            'sourceSHA256': {name: BASE_DIGESTS[name] for name in ('yue2_model.py','generate.py','yue2_vae.py')},
            'precision': 'BF16', 'layoutID': LAYOUT_ID, 'weightShapes': shapes,
            'runtimeIdentity': {'pythonExecutable': sys.executable,
                                'pythonVersion': sys.version.split()[0],
                                'mlxVersion': mlx_version},
            'publisherTrainingCheckpointSHA256': None}


def normalize_adapter(inspection: dict, destination: Path, base: dict | None = None,
                      cancelled: Callable[[], bool] | None = None) -> dict:
    """Recheck the source, rename factors, retain alpha once, and preserve raw dtype.

    The result is source-layout data with renderReady=false, not an MLX binding.
    All caller-supplied inventory/rank information is re-derived from source bytes.
    """
    if base is not None:
        if not isinstance(base, dict) or 'modelRoot' not in base:
            fail('unverified_base_layout', 'A supplied base dictionary cannot authorize a projection mapping.')
        observed_base = validate_local_base(base['modelRoot'],cancelled=cancelled)
        if base != observed_base:
            fail('base_mismatch', 'Base binding differs from the currently verified installation.')
    if not isinstance(inspection, dict) or inspection.get('protocol') != 'monsterovich-yue2-ab-v1':
        fail('invalid_inspection', 'Expected an inspected conventional YuE2 adapter.')
    try:
        original = absolute_path(inspection['weights']['path'])
        config = absolute_path(inspection['config']['path'])
    except (KeyError, TypeError):
        fail('invalid_inspection', 'Missing source references.')
    if original.name != 'lora.safetensors' or config != original.parent/'adapter_config.json':
        fail('invalid_inspection', 'Source references must identify one conventional adapter folder.')
    check_cancelled(cancelled)
    fresh = inspect_adapter(original.parent)
    check_cancelled(cancelled)
    if any(fresh[key]['sha256'] != inspection[key].get('sha256') for key in ('weights','config')):
        fail('source_changed', 'Adapter weights or configuration changed after inspection.')
    try:
        alpha = struct.pack('<f', fresh['alpha'])
    except (OverflowError, struct.error):
        fail('invalid_config', 'Alpha cannot be represented as a finite float32 scalar.')
    if not math.isfinite(struct.unpack('<f', alpha)[0]):
        fail('invalid_config', 'Alpha overflows float32.')
    if base is not None:
        if fresh['declaredBase'].get('base_revision') is not None:
            fail('unverified_training_base',
                 'The publisher training checkpoint revision is not verified against this MLX distribution.')
        for item in fresh['targets']:
            key = item['module']+'.weight'
            if observed_base['weightShapes'].get(key) != item['weightShape']:
                fail('shape_mismatch', f'{key}: adapter factors do not fit the verified BF16 base.')
    check_cancelled(cancelled)
    destination = absolute_path(destination)
    with new_file(destination) as output:
        with open_regular(original, MAX_ADAPTER_BYTES) as source:
            header, source_offset = tensor_header(source, os.fstat(source.fileno()).st_size)
            scan_finite(source, header, source_offset)
            check_cancelled(cancelled)
            initial_hash=(digest_stream(source) if cancelled is None else cancellable_digest_stream(source,cancelled))
            if initial_hash != fresh['weights']['sha256']:
                fail('source_changed', 'Adapter changed before normalization.')
            output_header, chunks, offset = {}, [], 0
            for item in fresh['targets']:
                check_cancelled(cancelled)
                target = item['module']
                for old, new in (('.lora_A', '.lora_down.weight'), ('.lora_B', '.lora_up.weight')):
                    entry = header[target+old]
                    start,end = entry['data_offsets']
                    length = end-start
                    output_header[target+new] = {'dtype': entry['dtype'], 'shape': entry['shape'],
                                                  'data_offsets': [offset,offset+length]}
                    chunks.append((source_offset+start,length,None)); offset += length
                output_header[target+'.alpha'] = {'dtype':'F32','shape':[], 'data_offsets':[offset,offset+4]}
                chunks.append((0,4,alpha)); offset += 4
            output_header['__metadata__'] = {
                'format':NORMALIZED_FORMAT, 'layout':LAYOUT_ID if base is not None else 'source-ab', 'branch':fresh['branch'],
                'normalizer_version':str(NORMALIZER_VERSION),
                'source_weights_sha256':fresh['weights']['sha256'],
                'source_config_sha256':fresh['config']['sha256'],
                'scaling':'alpha/r applied once at inference; B is not pre-scaled'}
            if base is not None:
                output_header['__metadata__']['base_model_sha256'] = base['modelSHA256']
                output_header['__metadata__']['base_revision'] = BASE_REVISION
            encoded = json.dumps(output_header,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
            encoded += b' '*((-len(encoded))%8)
            if (len(encoded)>MAX_HEADER_BYTES or len(output_header)-1>MAX_TENSOR_ENTRIES
                    or 8+len(encoded)+offset>MAX_ADAPTER_BYTES):
                fail('size_limit','Normalized adapter exceeds the file/header/tensor inventory limits.')
            output.write(struct.pack('<Q',len(encoded))); output.write(encoded)
            for position,length,literal in chunks:
                check_cancelled(cancelled)
                if literal is not None:
                    output.write(literal)
                    continue
                source.seek(position)
                while length:
                    check_cancelled(cancelled)
                    part=source.read(min(CHUNK_BYTES,length))
                    if not part:
                        fail('source_changed','Truncated source during normalization.')
                    output.write(part); length-=len(part)
            final_hash=(digest_stream(source) if cancelled is None else cancellable_digest_stream(source,cancelled))
            config_hash=(digest_file(config,MAX_CONFIG_BYTES) if cancelled is None else
                         cancellable_digest_file(config,MAX_CONFIG_BYTES,cancelled))
            if final_hash != fresh['weights']['sha256'] or config_hash != fresh['config']['sha256']:
                fail('source_changed','Source changed during normalization.')
    return {'path':str(destination),'sha256':(digest_file(destination) if cancelled is None else
                                            cancellable_digest_file(destination,cancelled=cancelled)),
            'bytes':destination.stat().st_size,'format':NORMALIZED_FORMAT,
            'layout':LAYOUT_ID if base is not None else 'source-ab',
            'bindingVerified':base is not None,
            'renderReady':False,
            'publisherTrainingCheckpointSHA256':None,
            'observedBase':base}


def main(argv: list[str] | None = None) -> int:
    parser=argparse.ArgumentParser(description='Inspect/import local source-layout YuE2 adapters. Does not render or approve.')
    commands=parser.add_subparsers(dest='command',required=True)
    for command in ('inspect','discover'):
        p=commands.add_parser(command); p.add_argument('folder',type=Path)
    p=commands.add_parser('import')
    p.add_argument('--store',type=Path,required=True); p.add_argument('--name',required=True)
    p.add_argument('--adapter',type=Path,action='append',required=True)
    p.add_argument('--new-version',action='store_true'); p.add_argument('--package-id')
    p.add_argument('--license-file',type=Path); p.add_argument('--card-file',type=Path)
    p=commands.add_parser('download')
    p.add_argument('--store',type=Path,required=True); p.add_argument('--pack-id',required=True)
    for command in ('list','orphans','hide'):
        p=commands.add_parser(command); p.add_argument('--store',type=Path,required=True)
        if command=='hide': p.add_argument('package_id')
    p=commands.add_parser('bind')
    p.add_argument('--store',type=Path,required=True)
    p.add_argument('--package-id',required=True); p.add_argument('--version-id',required=True)
    p.add_argument('--model',type=Path,required=True)
    p=commands.add_parser('approve')
    p.add_argument('--store',type=Path,required=True)
    p.add_argument('--package-id',required=True); p.add_argument('--version-id',required=True)
    p.add_argument('--model',type=Path,required=True); p.add_argument('--review-id',required=True)
    p.add_argument('--previews-stdin',action='store_true',required=True)
    p.add_argument('--acknowledged',action='store_true',required=True)
    p=commands.add_parser('decisions')
    p.add_argument('--store',type=Path,required=True)
    p.add_argument('--package-id',required=True); p.add_argument('--version-id',required=True)
    args=parser.parse_args(argv)
    cancellation=[False]
    def stop(_signal,_frame):
        cancellation[0]=True
        # Read-only commands have no publication to protect. Interrupt blocked
        # locks, hashing and scanning directly instead of swallowing the signal.
        if args.command in ('inspect','discover','list','orphans','decisions','download'):
            raise AdapterFormatError('cancelled','Catalog checking cancelled.')
    signal.signal(signal.SIGTERM,stop); signal.signal(signal.SIGINT,stop)
    try:
        if args.command=='inspect':
            result=inspect_adapter(args.folder)
        elif args.command=='discover':
            result=discover_adapters(args.folder)
        elif args.command=='download':
            from external_yue2_download import catalog, install_pack
            packs=[pack for pack in catalog() if pack['id']==args.pack_id]
            if len(packs)!=1:
                fail('unknown_pack','Choose a pack from the bundled compatible-adapter catalog.')
            def progress(value,status):
                print('PIXEL_MUSIC_PROGRESS='+str(value),flush=True)
                print('PIXEL_MUSIC_STATUS='+status,flush=True)
            result=install_pack(packs[0],args.store,progress=progress,cancelled=lambda:cancellation[0])
        else:
            import external_yue2_store as store
            if args.command=='import':
                texts={kind:path for kind,path in (('license',args.license_file),('card',args.card_file)) if path is not None}
                result=store.import_sound(args.store,args.adapter,name=args.name,
                    force_new=args.new_version,package_id=args.package_id,text_files=texts,
                    cancelled=lambda:cancellation[0])
            elif args.command=='list': result=store.versions(args.store,cancelled=lambda:cancellation[0])
            elif args.command=='orphans': result=store.orphan_versions(args.store,cancelled=lambda:cancellation[0])
            elif args.command=='bind':
                result=store.bind(args.store,args.package_id,args.version_id,args.model,
                                  cancelled=lambda:cancellation[0])
            elif args.command=='decisions':
                result=store.decision_references(args.store,args.package_id,args.version_id,
                                                cancelled=lambda:cancellation[0])
            elif args.command=='approve':
                from external_yue2_format import strict_json
                raw=sys.stdin.buffer.read(store.MAX_INDEX_BYTES+1) if hasattr(sys.stdin,'buffer') else sys.stdin.read(store.MAX_INDEX_BYTES+1).encode()
                if len(raw)>store.MAX_INDEX_BYTES:
                    raise AdapterFormatError('size_limit','Review data is too large.')
                body=strict_json(raw)
                if set(body)!={'previews'} or not isinstance(body['previews'],list):
                    raise AdapterFormatError('invalid_preview','Expected exactly two captured previews.')
                result=store.approve(args.store,args.package_id,args.version_id,args.model,
                    args.review_id,body['previews'],acknowledged=args.acknowledged,
                    cancelled=lambda:cancellation[0])
            else:
                store.hide(args.store,args.package_id,cancelled=lambda:cancellation[0])
                result={'status':'hidden','packageID':args.package_id}
        print(json.dumps(result,ensure_ascii=False,allow_nan=False,indent=2))
        return 0
    except (AdapterFormatError,OSError,ValueError) as exc:
        print(json.dumps({'error':getattr(exc,'code','io_error'),'message':str(exc)}),file=sys.stderr)
        return 130 if getattr(exc,'code',None)=='cancelled' else 65


if __name__=='__main__':
    raise SystemExit(main())
