"""Immutable, local-only storage for inspected (not approved) external sounds.

One small JSON index; one file lock; atomic publication. No inference, model
installation, external approval import, automatic selection, or weight activation.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import time
from typing import Callable
import uuid

from external_yue2_format import (AdapterFormatError, CHUNK_BYTES, MAX_ADAPTER_BYTES,
    MAX_CONFIG_BYTES, absolute_path, digest_file as _digest_file, digest_stream as _digest_stream, fail, inspect_adapter,
    open_directory, open_regular, read_json_file, strict_json, tensor_header)
from external_yue2_import import (NORMALIZER_VERSION, check_cancelled, new_file,
    normalize_adapter, validate_local_base, cancellable_digest_file, cancellable_digest_stream)

MAX_INDEX_BYTES = 2 * 1024 * 1024
MAX_VERSIONS = 1024
_HASH = re.compile(r'[0-9a-f]{64}\Z')


def digest_file(path: Path, limit: int | None=None, *, cancelled=None) -> str:
    return (_digest_file(path,limit) if cancelled is None else
            cancellable_digest_file(path,limit,cancelled))


def digest_stream(stream, *, cancelled=None) -> str:
    return _digest_stream(stream) if cancelled is None else cancellable_digest_stream(stream,cancelled)


def default_imported_sound_store() -> Path:
    return Path.home()/'Library/Application Support/Pixel Music/Training Styles/Imported'


def _managed_version(reference: dict, package_id: str, version_id: str,
                     expected_store: Path | None) -> tuple[Path,Path]:
    # Trust comes from the app-owned CLI argument/default, never the descriptor.
    root=absolute_path(expected_store if expected_store is not None else default_imported_sound_store())
    version=_version_dir(root,package_id,version_id)
    if absolute_path(reference['path'])!=version/'descriptor.json':
        fail('unmanaged_store','Descriptor is outside the independently configured imported-sound store.')
    return root,version


def _uuid(value: str) -> str:
    if not isinstance(value, str):
        fail('invalid_identity', 'Expected a UUID string.')
    try:
        result = str(uuid.UUID(value))
    except (ValueError, AttributeError):
        fail('invalid_identity', f'Invalid UUID: {value}')
    if value.lower() != result:
        fail('invalid_identity', 'Use a canonical, hyphenated UUID.')
    return result


def ensure_directory(path: Path) -> None:
    path = absolute_path(path)
    with open_directory(Path('/')) as initial:
        fd = os.dup(initial)
        try:
            for part in path.parts[1:]:
                try:
                    os.mkdir(part, 0o700, dir_fd=fd)
                except FileExistsError:
                    pass
                next_fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                os.close(fd); fd = next_fd
        except OSError as exc:
            fail('unsafe_path', f'Cannot create safe store directory {path}: {exc.strerror}')
        finally:
            os.close(fd)


@contextmanager
def _locked(root: Path, cancelled=None):
    check_cancelled(cancelled)
    with open_directory(root) as parent:
        try:
            fd = os.open('.index.lock', os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_NONBLOCK,
                         0o600, dir_fd=parent)
        except FileExistsError:
            fd = os.open('.index.lock', os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK,
                         dir_fd=parent)
        try:
            if not stat.S_ISREG(os.fstat(fd).st_mode):
                fail('unsafe_path', 'Store lock is not a regular file.')
            if cancelled is None:
                fcntl.flock(fd, fcntl.LOCK_EX)
            else:
                while True:
                    check_cancelled(cancelled)
                    try:
                        fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
                        break
                    except BlockingIOError:
                        time.sleep(0.05)
            check_cancelled(cancelled)
            yield
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN); os.close(fd)


def _load_index(root: Path, cancelled=None) -> dict:
    check_cancelled(cancelled)
    try:
        data = read_json_file(root/'index.json', MAX_INDEX_BYTES)
    except AdapterFormatError as exc:
        if exc.code == 'missing_file':
            return {'schemaVersion':1,'entries':[]}
        raise
    if set(data) != {'schemaVersion','entries'} or type(data['schemaVersion']) is not int or data['schemaVersion'] != 1:
        fail('invalid_index','Unsupported imported-sound index; original bytes are preserved.')
    entries = data['entries']
    if not isinstance(entries,list) or len(entries) > MAX_VERSIONS:
        fail('invalid_index','Invalid or oversized imported-sound index.')
    seen=set()
    for entry in entries:
        check_cancelled(cancelled)
        required={'packageID','versionID','name','descriptorSHA256','fingerprint','hidden'}
        if not isinstance(entry,dict) or set(entry)!=required:
            fail('invalid_index','Invalid version entry.')
        for key in ('packageID','versionID'): _uuid(entry[key])
        pair=(entry['packageID'],entry['versionID'])
        if pair in seen: fail('invalid_index','Duplicate version identity in index.')
        seen.add(pair)
        if (type(entry['hidden']) is not bool or not isinstance(entry['name'],str)
                or not entry['name'].strip() or len(entry['name'])>120):
            fail('invalid_index','Invalid version name or visibility.')
        for field in ('descriptorSHA256','fingerprint'):
            if not isinstance(entry[field],str) or not _HASH.fullmatch(entry[field]):
                fail('invalid_index','Invalid version checksum.')
    return data


def _json_bytes(value: dict) -> bytes:
    return (json.dumps(value,ensure_ascii=False,allow_nan=False,sort_keys=True,indent=2)+'\n').encode()


def _save_index(root: Path, value: dict, *, cancelled=None) -> None:
    check_cancelled(cancelled)
    data=_json_bytes(value)
    if len(data)>MAX_INDEX_BYTES or len(value['entries'])>MAX_VERSIONS:
        fail('size_limit','Imported-sound index is full.')
    temp=root/f'.index-{uuid.uuid4()}.tmp'
    try:
        with new_file(temp) as stream:
            stream.write(data)
            check_cancelled(cancelled)
        with open_directory(root) as parent:
            try:
                info=os.stat('index.json',dir_fd=parent,follow_symlinks=False)
                if not stat.S_ISREG(info.st_mode): fail('unsafe_path','Index is not a regular file.')
            except FileNotFoundError:
                pass
            check_cancelled(cancelled)
            os.replace(temp.name,'index.json',src_dir_fd=parent,dst_dir_fd=parent)
            os.fsync(parent)
    finally:
        _remove_file_if_present(temp)


def _remove_file_if_present(path: Path) -> None:
    with open_directory(path.parent) as parent:
        try: os.unlink(path.name,dir_fd=parent)
        except FileNotFoundError: pass


def _cleanup_stage(stage: Path) -> None:
    if not shutil.rmtree.avoids_symlink_attacks:
        fail('unsupported_platform','Safe request-scoped staging cleanup is unavailable.')
    with open_directory(stage.parent) as parent:
        try: shutil.rmtree(stage.name,dir_fd=parent)
        except FileNotFoundError: pass


def _copy(source: Path, destination: Path, limit: int, cancelled) -> None:
    with open_regular(source,limit) as input_file:
        with new_file(destination) as output:
            total=0
            while True:
                check_cancelled(cancelled)
                chunk=input_file.read(CHUNK_BYTES)
                if not chunk: break
                total+=len(chunk)
                if total>limit: fail('size_limit',f'{source.name} grew beyond its allowed size.')
                output.write(chunk)


def _version_dir(root: Path, package_id: str, version_id: str) -> Path:
    return root/_uuid(package_id)/'versions'/_uuid(version_id)


def _descriptor(root: Path, entry: dict, cancelled=None) -> tuple[dict, Path]:
    check_cancelled(cancelled)
    path=_version_dir(root,entry['packageID'],entry['versionID'])/'descriptor.json'
    with open_regular(path,MAX_INDEX_BYTES) as stream:
        raw=stream.read(MAX_INDEX_BYTES+1)
        if hashlib.sha256(raw).hexdigest()!=entry['descriptorSHA256']:
            fail('artifact_changed',f'Imported descriptor changed: {path}')
        value=strict_json(raw)
    if (value.get('protocol')!='pixel-music-external-yue2-v1'
            or type(value.get('schemaVersion')) is not int or value['schemaVersion']!=1
            or value.get('status')!='inspected'
            or value.get('renderReady') is not False
            or value.get('localBase') is not None
            or value.get('packageID')!=entry['packageID']
            or value.get('versionID')!=entry['versionID']
            or value.get('fingerprint')!=entry['fingerprint']
            or not isinstance(value.get('branches'),dict)
            or not 1<=len(value['branches'])<=2
            or set(value['branches'])-{'ar','nar'}):
        fail('invalid_descriptor','Unexpected imported descriptor; no approval inferred.')
    return value,path


def _result(root: Path, entry: dict, reused: bool=False, cancelled=None) -> dict:
    value,path=_descriptor(root,entry,cancelled)
    check_cancelled(cancelled)
    return {'packageID':entry['packageID'],'versionID':entry['versionID'],'name':entry['name'],
            'descriptor':{'path':str(path),'sha256':entry['descriptorSHA256']},
            'branches':sorted(value['branches']),'status':'inspected','renderReady':False,
            'hidden':entry['hidden'],'reused':reused,
            'warnings':value['warnings']}


def _exists_root(root: Path) -> bool:
    try: os.lstat(root)
    except FileNotFoundError: return False
    with open_directory(root): pass
    return True


def versions(root: Path, include_hidden: bool=False, *, cancelled=None) -> list[dict]:
    check_cancelled(cancelled)
    root=absolute_path(root)
    if not _exists_root(root): return []
    with _locked(root,cancelled):
        index=_load_index(root,cancelled)
        result=[]
        for entry in index['entries']:
            check_cancelled(cancelled)
            if include_hidden or not entry['hidden']:
                result.append(_result(root,entry,cancelled=cancelled))
        check_cancelled(cancelled)
        return result


def hide(root: Path, package_id: str, *, cancelled=None) -> None:
    root=absolute_path(root); package_id=_uuid(package_id)
    with _locked(root,cancelled):
        index=_load_index(root,cancelled)
        matches=[entry for entry in index['entries'] if entry['packageID']==package_id]
        if not matches: fail('missing_package','Package is not in this imported-sound index.')
        for entry in matches:
            check_cancelled(cancelled)
            entry['hidden']=True
        _save_index(root,index,cancelled=cancelled)


def import_sound(root: Path, folders: list[Path], *, name: str, force_new: bool=False,
                 package_id: str | None=None, text_files: dict[str,Path] | None=None,
                 cancelled: Callable[[],bool] | None=None) -> dict:
    """Publish an inspected source-layout package. Never approve or activate it."""
    if (not isinstance(folders,(list,tuple)) or not 1<=len(folders)<=2
            or not isinstance(name,str) or not name.strip() or len(name)>120
            or any(c in name for c in '\0\r\n') or type(force_new) is not bool):
        fail('invalid_request','Select one or two adapters and a single-line name of 1–120 characters.')
    package_id=_uuid(package_id) if package_id is not None else str(uuid.uuid4())
    text_files={} if text_files is None else text_files
    if not isinstance(text_files,dict) or set(text_files)-{'license','card'}:
        fail('invalid_request','Only explicitly selected license/card text can accompany an import.')
    root=absolute_path(root); ensure_directory(root)
    check_cancelled(cancelled)
    with _locked(root):
        index=_load_index(root)
        staging_parent=root/'.staging'; ensure_directory(staging_parent)
        stage=staging_parent/str(uuid.uuid4()); ensure_directory(stage)
        published=False
        try:
            branches={}
            originals=stage/'originals'; normalized=stage/'normalized'
            ensure_directory(originals); ensure_directory(normalized)
            for i,folder in enumerate(folders):
                check_cancelled(cancelled)
                source=absolute_path(folder); copied=originals/f'source-{i}'
                ensure_directory(copied)
                # Read weights first so special conditioning can be diagnosed even without a config.
                _copy(source/'lora.safetensors',copied/'lora.safetensors',MAX_ADAPTER_BYTES,cancelled)
                try:
                    _copy(source/'adapter_config.json',copied/'adapter_config.json',MAX_CONFIG_BYTES,cancelled)
                except AdapterFormatError as exc:
                    if exc.code!='missing_file': raise
                report=inspect_adapter(copied)
                branch=report['branch']
                if branch in branches: fail('duplicate_branch','A sound can contain at most one adapter per branch.')
                converted=normalize_adapter(report,normalized/f'{branch}.safetensors',cancelled=cancelled)
                def relative(asset):
                    return {**asset,'path':str(Path(asset['path']).relative_to(stage))}
                branches[branch]={key:report[key] for key in ('rank','alpha','targets','declaredBase','shapeCheck')}
                branches[branch].update(weights=relative(report['weights']),config=relative(report['config']),normalized=relative(converted))
            texts={}
            for kind,source in sorted(text_files.items()):
                check_cancelled(cancelled)
                target=stage/f'{kind}.txt'
                _copy(absolute_path(source),target,MAX_CONFIG_BYTES,cancelled)
                with open_regular(target,MAX_CONFIG_BYTES) as stream:
                    try: stream.read().decode('utf-8')
                    except UnicodeError: fail('invalid_text','License/card must be inert UTF-8 text.')
                texts[kind]={'path':target.name,'sha256':digest_file(target),'bytes':target.stat().st_size}
            converter_hash=digest_file(Path(__file__).with_name('external_yue2_import.py'))
            fingerprint=hashlib.sha256(_json_bytes({'normalizer':converter_hash,'sources':{
                branch:{key:item[key]['sha256'] for key in ('weights','config')}
                for branch,item in sorted(branches.items())},'texts':{key:value['sha256'] for key,value in texts.items()}})).hexdigest()
            if not force_new:
                for entry in index['entries']:
                    if entry['fingerprint']==fingerprint:
                        return _result(root,entry,reused=True)
            version_id=str(uuid.uuid4())
            descriptor={'schemaVersion':1,'protocol':'pixel-music-external-yue2-v1',
                'packageID':package_id,'versionID':version_id,'name':name.strip(),
                'createdAt':datetime.now(timezone.utc).isoformat(),'sourceKind':'local',
                'status':'inspected','renderReady':False,'localBase':None,'fingerprint':fingerprint,
                'branches':branches,'texts':texts,
                'licenseStatus':'provided_unverified' if 'license' in texts else 'not_provided',
                'normalizer':{'version':NORMALIZER_VERSION,'sha256':converter_hash,'layout':'source-ab'},
                'defaults':{'source':'application_audition_default','amount':0.5,
                            'branchScales':{branch:1.0 for branch in branches}},
                'warnings':['Source-format inspection only; the MLX projection layout has not been verified.',
                            'Training-checkpoint identity is unknown unless independently established.',
                            'No listening approval exists. This sound cannot yet be selected for rendering.',
                            'Published license text is stored as supplied, not as clearance for a particular use.']}
            with new_file(stage/'descriptor.json') as stream: stream.write(_json_bytes(descriptor))
            descriptor_hash=digest_file(stage/'descriptor.json')
            # Every file was fsynced by new_file; sync directories before publication.
            for directory,_,_ in os.walk(stage,topdown=False,followlinks=False):
                with open_directory(Path(directory)) as fd: os.fsync(fd)
            destination=_version_dir(root,package_id,version_id)
            ensure_directory(destination.parent)
            check_cancelled(cancelled)
            with open_directory(staging_parent) as source_parent, open_directory(destination.parent) as dest_parent:
                try: os.stat(destination.name,dir_fd=dest_parent,follow_symlinks=False)
                except FileNotFoundError: pass
                else: fail('destination_exists','Immutable version already exists.')
                os.rename(stage.name,destination.name,src_dir_fd=source_parent,dst_dir_fd=dest_parent)
                published=True
                os.fsync(source_parent); os.fsync(dest_parent)
            entry={'packageID':package_id,'versionID':version_id,'name':name.strip(),
                   'descriptorSHA256':descriptor_hash,'fingerprint':fingerprint,'hidden':False}
            index['entries'].append(entry)
            try:
                _save_index(root,index)
            except (OSError,AdapterFormatError) as exc:
                fail('index_publish_failed',f'Version was saved at {destination}, but indexing failed: {exc}. Inspect orphan versions; no approval was created.')
            return _result(root,entry)
        finally:
            if not published: _cleanup_stage(stage)


def orphan_versions(root: Path, *, cancelled=None) -> list[dict]:
    """Report unindexed published data for explicit recovery; never auto-approve it."""
    check_cancelled(cancelled)
    root=absolute_path(root)
    if not _exists_root(root): return []
    with _locked(root,cancelled):
        index=_load_index(root,cancelled)
        known={(e['packageID'],e['versionID']) for e in index['entries']}
        results=[]; scanned=0
        def child_dirs(parent):
            nonlocal scanned
            with open_directory(parent) as fd, os.scandir(fd) as entries:
                values=[]
                for entry in entries:
                    check_cancelled(cancelled)
                    scanned+=1
                    if scanned>MAX_VERSIONS*4: fail('size_limit','Orphan discovery limit exceeded.')
                    info=entry.stat(follow_symlinks=False)
                    if stat.S_ISLNK(info.st_mode): fail('unsafe_path','Symlink in immutable version store.')
                    if stat.S_ISDIR(info.st_mode) and not entry.name.startswith('.'):
                        values.append(parent/entry.name)
                return sorted(values)
        for package in child_dirs(root):
            check_cancelled(cancelled)
            package_id=_uuid(package.name)
            versions_dir=package/'versions'
            if not _exists_root(versions_dir): continue
            for version in child_dirs(versions_dir):
                check_cancelled(cancelled)
                version_id=_uuid(version.name)
                if (package_id,version_id) in known: continue
                value=read_json_file(version/'descriptor.json',MAX_INDEX_BYTES)
                entry={'packageID':package_id,'versionID':version_id,'name':value.get('name'),
                       'descriptorSHA256':digest_file(version/'descriptor.json',cancelled=cancelled),
                       'fingerprint':value.get('fingerprint'),'hidden':False}
                results.append({**_result(root,entry,cancelled=cancelled),'needsIndexRecovery':True})
        check_cancelled(cancelled)
        return results


def _entry(root: Path, package_id: str, version_id: str, cancelled=None) -> dict:
    package_id, version_id = _uuid(package_id), _uuid(version_id)
    for item in _load_index(root,cancelled)['entries']:
        check_cancelled(cancelled)
        if item['packageID'] == package_id and item['versionID'] == version_id:
            return item
    fail('missing_version', 'Imported sound is not in this store index.')


def _file_reference(path: Path, limit: int | None = None, cancelled=None) -> dict:
    return {'path':str(path),'sha256':digest_file(path,limit,cancelled=cancelled)}


def _checked_reference(version: Path, reference: dict, limit: int, cancelled=None) -> Path:
    if (not isinstance(reference,dict) or not {'path','sha256'} <= set(reference)
            or not isinstance(reference['path'],str)
            or not isinstance(reference['sha256'],str)
            or not _HASH.fullmatch(reference['sha256'])):
        fail('invalid_reference','Invalid immutable file reference.')
    relative=Path(reference['path'])
    if relative.is_absolute() or not relative.parts or '..' in relative.parts or '\0' in str(relative):
        fail('unsafe_path','Artifact reference must stay inside its version.')
    path=version/relative
    if digest_file(path,limit,cancelled=cancelled)!=reference['sha256']:
        fail('artifact_changed',f'Imported artifact changed: {path}')
    return path


def _checked_version(root: Path, entry: dict, cancelled=None) -> tuple[dict,Path,dict]:
    descriptor,path=_descriptor(root,entry,cancelled)
    version=path.parent
    for branch,details in descriptor['branches'].items():
        if not isinstance(details,dict): fail('invalid_descriptor','Invalid branch inventory.')
        for field,limit in (('weights',MAX_ADAPTER_BYTES),('config',MAX_CONFIG_BYTES),
                            ('normalized',MAX_ADAPTER_BYTES)):
            _checked_reference(version,details.get(field),limit,cancelled)
        originals=version/('originals/source-0')
        if branch not in ('ar','nar'): fail('invalid_descriptor','Unknown branch.')
    for details in descriptor.get('texts',{}).values():
        _checked_reference(version,details,MAX_CONFIG_BYTES,cancelled)
    return descriptor,version,{'path':str(path),'sha256':entry['descriptorSHA256']}


def _binding_namespace(base: dict, cancelled=None) -> tuple[str,str,dict]:
    base_hash=hashlib.sha256(_json_bytes(base)).hexdigest()
    converter=_file_reference(Path(__file__).with_name('external_yue2_import.py'),cancelled=cancelled)
    return base_hash,base_hash+'-'+converter['sha256'],converter


def _binding(root: Path, entry: dict, base: dict, cancelled=None) -> tuple[dict,dict]:
    descriptor,version,descriptor_ref=_checked_version(root,entry,cancelled)
    base_hash,namespace,current_converter=_binding_namespace(base,cancelled)
    binding_path=version/'bindings'/namespace/'binding.json'
    binding=read_json_file(binding_path,MAX_INDEX_BYTES)
    if (binding.get('protocol')!='pixel-music-external-yue2-binding-v1'
            or binding.get('descriptor')!=descriptor_ref or binding.get('baseSHA256')!=base_hash
            or set(binding.get('normalized',{}))!=set(descriptor['branches'])):
        fail('base_mismatch','Immutable adapter binding does not match the descriptor or installed base.')
    converter=binding.get('converter')
    if (not isinstance(converter,dict) or converter.get('sha256')!=current_converter['sha256']):
        fail('artifact_changed','Adapter binding converter changed.')
    for branch,reference in binding['normalized'].items():
        path=_checked_reference(version,reference,MAX_ADAPTER_BYTES,cancelled)
        if (path!=binding_path.parent/f'{branch}.safetensors'
                or reference.get('layout')!=base['layoutID']
                or reference.get('bindingVerified') is not True
                or reference.get('observedBase')!=base):
            fail('unverified_base_layout','Binding contains an unverified adapter layout.')
        with open_regular(path,MAX_ADAPTER_BYTES) as stream:
            header,_=tensor_header(stream,os.fstat(stream.fileno()).st_size)
            metadata=header.get('__metadata__',{})
            if (metadata.get('format')!='pixel-music-external-yue2-tensors-v1'
                    or metadata.get('layout')!=base['layoutID']
                    or metadata.get('base_model_sha256')!=base['modelSHA256']
                    or metadata.get('base_revision')!=base['revision']
                    or metadata.get('branch')!=branch
                    or digest_stream(stream,cancelled=cancelled)!=reference['sha256']):
                fail('artifact_changed','Bound adapter does not match its verified layout and base.')
    return binding,_file_reference(binding_path,MAX_INDEX_BYTES,cancelled)


def _absolute_normalized(version: Path, binding: dict) -> dict:
    return {branch:{**value,'path':str(version/value['path'])}
            for branch,value in binding['normalized'].items()}


def bind(root: Path, package_id: str, version_id: str, model_root: Path, *, cancelled=None) -> dict:
    """Publish write-once base-layout conversion from copied originals."""
    root=absolute_path(root)
    with _locked(root,cancelled):
        entry=_entry(root,package_id,version_id)
        descriptor,version,descriptor_ref=_checked_version(root,entry,cancelled)
        base=validate_local_base(model_root,cancelled=cancelled)
        base_hash,namespace,converter=_binding_namespace(base,cancelled)
        target=version/'bindings'/namespace
        if _exists_root(target):
            binding,reference=_binding(root,entry,base,cancelled)
            return {'reference':reference,'normalized':_absolute_normalized(version,binding),'base':base}
        parent=version/'bindings'; ensure_directory(parent)
        stage=parent/f'.stage-{uuid.uuid4()}'
        ensure_directory(stage)
        published=False
        try:
            normalized={}
            for branch,details in sorted(descriptor['branches'].items()):
                check_cancelled(cancelled)
                source=_checked_reference(version,details['weights'],MAX_ADAPTER_BYTES,cancelled)
                report=inspect_adapter(source.parent)
                check_cancelled(cancelled)
                if (report['branch']!=branch or report['weights']['sha256']!=details['weights']['sha256']
                        or report['config']['sha256']!=details['config']['sha256']):
                    fail('artifact_changed','Copied adapter no longer matches the descriptor.')
                converted=normalize_adapter(report,stage/f'{branch}.safetensors',base=base,cancelled=cancelled)
                normalized[branch]={**converted,'path':str(Path('bindings')/namespace/f'{branch}.safetensors')}
            record={'protocol':'pixel-music-external-yue2-binding-v1','schemaVersion':1,
                    'descriptor':descriptor_ref,'baseSHA256':base_hash,
                    'normalized':normalized,
                    'converter':converter}
            data=_json_bytes(record)
            check_cancelled(cancelled)
            with new_file(stage/'binding.json') as stream:
                stream.write(data)
                check_cancelled(cancelled)
            with open_directory(stage) as fd: os.fsync(fd)
            with open_directory(parent) as fd:
                check_cancelled(cancelled)
                os.rename(stage.name,target.name,src_dir_fd=fd,dst_dir_fd=fd)
                published=True; os.fsync(fd)
            return {'reference':_file_reference(target/'binding.json',MAX_INDEX_BYTES),
                    'normalized':_absolute_normalized(version,record),'base':base}
        finally:
            if not published: _cleanup_stage(stage)


def _check_audition(context: dict, version: Path, descriptor_ref: dict,
                    model_root: Path, role: str, cancelled=None) -> None:
    check_cancelled(cancelled)
    required={'schemaVersion','purpose','role','reviewID','jobID','projectID','sourceProjectID',
              'packageID','versionID','descriptor','baseBinding','modelPath','previewOutputPath'}
    if (not isinstance(context,dict) or set(context)!=required
            or type(context['schemaVersion']) is not int or context['schemaVersion']!=1
            or context['purpose']!='importedSoundAudition' or context['role']!=role
            or _uuid(context['packageID'])!=version.parent.parent.name
            or _uuid(context['versionID'])!=version.name
            or _uuid(context['sourceProjectID'])==_uuid(context['projectID'])
            or context['descriptor']!=descriptor_ref
            or context['modelPath']!=str(absolute_path(model_root))):
        fail('invalid_audition','Audition context does not match this descriptor, role and model.')
    review_id,job_id=_uuid(context['reviewID']),_uuid(context['jobID'])
    lock_path=absolute_path(model_root)/'.pixel-music-model-lock.json'
    if context['baseBinding']!=_file_reference(lock_path,MAX_CONFIG_BYTES,cancelled):
        fail('invalid_audition','Audition base binding changed.')
    output=version/'Auditions'/review_id/role/'Outputs'/(job_id+'.wav')
    if absolute_path(context['previewOutputPath'])!=output:
        fail('invalid_audition','Audition output is outside the captured review workspace.')


def validate_audition(context: dict, model_root: Path, *, expected_store: Path | None=None) -> dict:
    """Pin both audition roles before importing or constructing any model code."""
    # Hardcoded identity validation is independent of the model's own manifest.
    base=validate_local_base(model_root)
    if not isinstance(context,dict) or context.get('role') not in ('baseline','adapted'):
        fail('invalid_audition','Missing audition role.')
    root,version=_managed_version(context['descriptor'],context['packageID'],context['versionID'],expected_store)
    with _locked(root):
        entry=_entry(root,context['packageID'],context['versionID'])
        _,_,descriptor_ref=_checked_version(root,entry)
        _check_audition(context,version,descriptor_ref,model_root,context['role'])
        _binding(root,entry,base)
    return base


def _preview(version: Path, review_id: str, preview: dict, descriptor_ref: dict,
             base: dict, binding: dict, cancelled=None) -> tuple[dict,dict]:
    check_cancelled(cancelled)
    if (not isinstance(preview,dict) or set(preview)!={'role','jobID','projectID','output','result'}
            or preview['role'] not in ('baseline','adapted')):
        fail('invalid_preview','Expected a baseline or adapted completed preview.')
    role=preview['role']; _uuid(preview['jobID']); _uuid(preview['projectID'])
    output=preview['output']; result=preview['result']
    if not isinstance(output,dict) or not isinstance(result,dict):
        fail('invalid_preview','Preview references are missing.')
    path=Path(output.get('path','')); report_path=Path(result.get('path',''))
    project=version/'Auditions'/review_id/role
    if (path.parent!=project/'Outputs' or path.suffix!='.wav'
            or report_path!=path.with_suffix('.yue2')/'result.json'):
        fail('invalid_preview','Preview is outside its app-owned audition workspace.')
    for reference,limit in ((output,MAX_ADAPTER_BYTES),(result,MAX_INDEX_BYTES)):
        if not isinstance(reference.get('sha256'),str) or not _HASH.fullmatch(reference['sha256']):
            fail('invalid_preview','Preview checksum is missing.')
        if digest_file(Path(reference['path']),limit,cancelled=cancelled)!=reference['sha256']:
            fail('artifact_changed','Preview output or result changed.')
    report=read_json_file(report_path,MAX_INDEX_BYTES)
    files=report.get('files')
    context_ref=report.get('auditionContext')
    context_path=report_path.parent/'review-context.json'
    if (not isinstance(files,dict) or not isinstance(context_ref,dict)
            or set(context_ref)!={'path','sha256'} or context_ref['path']!=str(context_path)
            or context_ref['sha256']!=files.get(context_path.name)
            or context_ref['sha256']!=digest_file(context_path,MAX_INDEX_BYTES,cancelled=cancelled)):
        fail('invalid_preview','Preview lacks checksummed audition context.')
    context=read_json_file(context_path,MAX_INDEX_BYTES)
    _check_audition(context,version,descriptor_ref,Path(base['modelRoot']),role,cancelled)
    if (_uuid(context['reviewID'])!=review_id or _uuid(context['jobID'])!=_uuid(preview['jobID'])
            or _uuid(context['projectID'])!=_uuid(preview['projectID'])
            or context['previewOutputPath']!=str(path)):
        fail('invalid_preview','Preview audition identity differs from its completed output.')
    request=report.get('request')
    if (not isinstance(request,dict) or _uuid(request.get('id'))!=_uuid(preview['jobID'])
            or _uuid(request.get('projectID'))!=_uuid(preview['projectID'])
            or report.get('audioSHA256')!=output['sha256']):
        fail('invalid_preview','Preview result does not describe its completed output.')
    manifest=read_json_file(project/'pixel-music-project.json',MAX_INDEX_BYTES)
    manifest_project=manifest.get('project')
    records=manifest.get('outputs')
    if (not isinstance(manifest_project,dict)
            or _uuid(manifest_project.get('id'))!=_uuid(preview['projectID'])
            or not isinstance(records,list)
            or not any(isinstance(record,dict)
                       and _uuid(record.get('recipeID'))==_uuid(preview['jobID'])
                       and record.get('filename')==path.name
                       and record.get('sha256')==output['sha256']
                       and record.get('deletedAt') is None for record in records)):
        fail('invalid_preview','Preview is not a completed output of its app-owned project.')
    sound=report.get('importedSound')
    if role=='baseline':
        if sound is not None or request.get('yue2',{}).get('importedSound') is not None:
            fail('invalid_preview','Baseline preview applied an imported sound.')
    else:
        from external_yue2_apply import effective_scales, validate_selection
        application=sound.get('application') if isinstance(sound,dict) else None
        selection=sound.get('selection') if isinstance(sound,dict) else None
        if (not isinstance(sound,dict) or sound.get('applied') is not True or not isinstance(application,dict)
                or not isinstance(selection,dict) or application.get('base')!=base
                or application.get('descriptor')!=descriptor_ref
                or application.get('normalized')!=_absolute_normalized(version,binding)
                or not isinstance(application.get('updatedTargets'),list)
                or not application['updatedTargets']
                or selection.get('descriptor')!=descriptor_ref
                or _uuid(selection.get('packageID'))!=version.parent.parent.name
                or _uuid(selection.get('versionID'))!=version.name):
            fail('invalid_preview','Adapted preview lacks verified application provenance.')
        validate_selection(selection)
        requested=request.get('yue2',{}).get('importedSound')
        def canonical_selection(value):
            if not isinstance(value,dict): return value
            return {**value,**{key:_uuid(value.get(key)) for key in ('packageID','versionID')}}
        if canonical_selection(requested)!=canonical_selection(selection):
            fail('invalid_preview','Adapted application differs from the requested sound.')
        if not effective_scales(selection) or set(effective_scales(selection))-set(binding['normalized']):
            fail('invalid_preview','Adapted preview did not use an active sound.')
    options=request.get('yue2',{})
    if not isinstance(options,dict) or options.get('decodeLatentsPath'):
        fail('invalid_preview','Auditions must render the captured composition.')
    abc=options.get('abc','')
    if not isinstance(abc,str):
        fail('invalid_preview','Audition ABC must be text.')
    score=None
    score_path=report_path.parent/'score.abc'
    if (options.get('planning')!='off' or abc.strip() or 'score.abc' in files
            or os.path.lexists(score_path)):
        score=digest_file(score_path,MAX_INDEX_BYTES,cancelled=cancelled)
        if files.get('score.abc')!=score:
            fail('artifact_changed','Preview score bytes changed.')
        if role=='adapted' and not abc.strip():
            fail('invalid_preview','Adapted audition requires the captured baseline score.')
        if abc.strip() and hashlib.sha256(abc.encode('utf-8')).hexdigest()!=score:
            fail('invalid_preview','Requested ABC differs from the actual preview score bytes.')
    check_cancelled(cancelled)
    return preview,{'request':request,'context':context,'scoreSHA256':score}


def _comparison_request(request: dict, *, omit_abc: bool=False) -> dict:
    value={key:item for key,item in request.items() if key not in ('id','projectID')}
    if isinstance(value.get('yue2'),dict):
        value['yue2']={key:item for key,item in value['yue2'].items()
                       if key!='importedSound' and not (omit_abc and key=='abc')}
    return value


def _comparison(checked: list, error_code: str) -> str:
    if ({p['role'] for p,_ in checked}!={'baseline','adapted'}
            or _uuid(checked[0][0]['jobID'])==_uuid(checked[1][0]['jobID'])
            or _uuid(checked[0][0]['projectID'])==_uuid(checked[1][0]['projectID'])):
        fail(error_code,'Comparison jobs and projects must be distinct.')
    baseline=next(data for p,data in checked if p['role']=='baseline')
    adapted=next(data for p,data in checked if p['role']=='adapted')
    source_id=_uuid(baseline['context']['sourceProjectID'])
    if (source_id!=_uuid(adapted['context']['sourceProjectID'])
            or source_id in {_uuid(p['projectID']) for p,_ in checked}
            or baseline['scoreSHA256']!=adapted['scoreSHA256']):
        fail(error_code,'Comparison must share its source project and exact score bytes.')
    # Only a blank baseline ABC may become its captured score in the adapted request.
    omit_abc=baseline['scoreSHA256'] is not None and not baseline['request']['yue2'].get('abc','').strip()
    if (_comparison_request(baseline['request'],omit_abc=omit_abc)
            !=_comparison_request(adapted['request'],omit_abc=omit_abc)):
        fail(error_code,'Comparison requests differ beyond their captured baseline score and sound.')
    return source_id


def approve(root: Path, package_id: str, version_id: str, model_root: Path,
            review_id: str, previews: list[dict], *, acknowledged: bool, cancelled=None) -> dict:
    """Record one explicit, listened comparison without changing the descriptor."""
    if acknowledged is not True: fail('acknowledgment_required','Listen and acknowledge both outputs first.')
    root=absolute_path(root); review_id=_uuid(review_id)
    with _locked(root,cancelled):
        entry=_entry(root,package_id,version_id)
        descriptor,version,descriptor_ref=_checked_version(root,entry,cancelled)
        base=validate_local_base(model_root,cancelled=cancelled)
        binding,binding_ref=_binding(root,entry,base,cancelled)
        if not isinstance(previews,list) or len(previews)!=2:
            fail('invalid_preview','Both completed comparison outputs are required.')
        checked=[_preview(version,review_id,p,descriptor_ref,base,binding,cancelled) for p in previews]
        source_id=_comparison(checked,'invalid_preview')
        adapted=next(p for p,_ in checked if p['role']=='adapted')
        adapted_report=read_json_file(Path(adapted['result']['path']),MAX_INDEX_BYTES)
        record={'protocol':'pixel-music-external-yue2-approval-v1','schemaVersion':1,
                'packageID':entry['packageID'],'versionID':entry['versionID'],
                'reviewID':review_id,'sourceProjectID':source_id,
                'scoreSHA256':checked[0][1]['scoreSHA256'],
                'descriptor':descriptor_ref,'binding':binding_ref,
                'baseSHA256':binding['baseSHA256'],'previews':previews,
                'auditionedSelection':adapted_report['importedSound']['selection'],
                'acknowledged':True,'createdAt':datetime.now(timezone.utc).isoformat()}
        decisions=version/'review-decisions'; ensure_directory(decisions)
        path=decisions/f'{review_id}.json'
        data=_json_bytes(record)
        check_cancelled(cancelled)
        staging_parent=root/'.staging'; ensure_directory(staging_parent)
        stage=staging_parent/str(uuid.uuid4())
        with open_directory(staging_parent) as fd:
            os.mkdir(stage.name,0o700,dir_fd=fd)
        try:
            staged=stage/'decision.json'
            with new_file(staged) as stream:
                stream.write(data)
                check_cancelled(cancelled)
            reference=_file_reference(staged,MAX_INDEX_BYTES,cancelled)
            with open_directory(stage) as source_fd, open_directory(decisions) as destination_fd:
                os.fsync(source_fd)
                info=os.stat(staged.name,dir_fd=source_fd,follow_symlinks=False)
                if not stat.S_ISREG(info.st_mode):
                    fail('unsafe_path','Staged review decision is not a regular file.')
                check_cancelled(cancelled)
                try:
                    os.link(staged.name,path.name,src_dir_fd=source_fd,dst_dir_fd=destination_fd,
                            follow_symlinks=False)
                except FileExistsError:
                    fail('destination_exists',f'Will not overwrite {path}.')
                os.fsync(destination_fd)
            return {'path':str(path),'sha256':reference['sha256']}
        finally:
            _cleanup_stage(stage)


def decision_references(root: Path, package_id: str, version_id: str, *, cancelled=None) -> list[dict]:
    """Discover local review records; resolve() still revalidates base and previews."""
    root=absolute_path(root)
    with _locked(root,cancelled):
        entry=_entry(root,package_id,version_id,cancelled)
        _,version,descriptor_ref=_checked_version(root,entry,cancelled)
        decisions=version/'review-decisions'
        if not _exists_root(decisions): return []
        paths=[]
        with open_directory(decisions) as fd,os.scandir(fd) as entries:
            for item in entries:
                check_cancelled(cancelled)
                if len(paths)>=MAX_VERSIONS:
                    fail('size_limit','Too many imported-sound review decisions.')
                paths.append(decisions/item.name)
        result=[]
        for path in paths:
            check_cancelled(cancelled)
            if path.suffix!='.json' or _uuid(path.stem)!=path.stem:
                fail('invalid_approval','Unexpected review-decision filename.')
            record=read_json_file(path,MAX_INDEX_BYTES)
            if (record.get('protocol')!='pixel-music-external-yue2-approval-v1'
                    or type(record.get('schemaVersion')) is not int or record['schemaVersion']!=1
                    or record.get('packageID')!=entry['packageID']
                    or record.get('versionID')!=entry['versionID']
                    or record.get('reviewID')!=path.stem
                    or record.get('descriptor')!=descriptor_ref
                    or record.get('acknowledged') is not True):
                fail('invalid_approval','Review-decision record is not valid for this version.')
            created=record.get('createdAt')
            try:
                if not isinstance(created,str) or len(created)>64:
                    raise ValueError()
                instant=datetime.fromisoformat(created)
                if instant.utcoffset() is None:
                    raise ValueError()
                instant=instant.astimezone(timezone.utc)
            except (TypeError,ValueError,OverflowError):
                fail('invalid_approval','Review decision needs a valid creation time with a timezone.')
            reference={'reviewID':path.stem,'approval':_file_reference(path,MAX_INDEX_BYTES,cancelled)}
            result.append((instant,path.stem,reference))
        check_cancelled(cancelled)
        return [item[2] for item in sorted(result,key=lambda item:(item[0],item[1]))]


def resolve(selection: dict, model_root: Path, audition_context=None, *, expected_store: Path | None=None) -> dict:
    """Resolve only indexed, approved immutable bytes for normal rendering."""
    from external_yue2_apply import effective_scales, validate_selection
    validate_selection(selection)
    scales=effective_scales(selection)
    if not scales: fail('inactive_selection','Only active sounds need resolution.')
    descriptor_ref=selection['descriptor']
    package_id,version_id=_uuid(selection['packageID']),_uuid(selection['versionID'])
    root,version=_managed_version(descriptor_ref,package_id,version_id,expected_store)
    with _locked(root):
        entry=_entry(root,package_id,version_id)
        descriptor,actual_version,actual_ref=_checked_version(root,entry)
        if actual_ref!=descriptor_ref or actual_version!=version:
            fail('artifact_changed','Selection descriptor differs from indexed immutable version.')
        if set(scales)-set(descriptor['branches']):
            fail('invalid_selection','Selected scale has no adapter branch.')
        base=validate_local_base(model_root)
        binding,binding_ref=_binding(root,entry,base)
        approval_ref=selection.get('approval')
        approval=None
        if audition_context is not None:
            _check_audition(audition_context,version,actual_ref,model_root,'adapted')
            if approval_ref is not None:
                fail('invalid_audition','An audition must not borrow a listening approval.')
        else:
            if not isinstance(approval_ref,dict) or set(approval_ref)!={'path','sha256'}:
                fail('approval_required','Active imported sound requires a store approval.')
            approval_path=Path(approval_ref['path'])
            if (approval_path.parent!=version/'review-decisions' or approval_path.suffix!='.json'
                    or not isinstance(approval_ref['sha256'],str)
                    or not _HASH.fullmatch(approval_ref['sha256'])):
                fail('invalid_approval','Approval is outside this immutable version.')
            _uuid(approval_path.stem)
            if digest_file(approval_path,MAX_INDEX_BYTES)!=approval_ref['sha256']:
                fail('artifact_changed','Approval record changed.')
            approval=read_json_file(approval_path,MAX_INDEX_BYTES)
            if (approval.get('protocol')!='pixel-music-external-yue2-approval-v1'
                    or type(approval.get('schemaVersion')) is not int or approval['schemaVersion']!=1
                    or approval.get('packageID')!=package_id or approval.get('versionID')!=version_id
                    or approval.get('reviewID')!=approval_path.stem
                    or approval.get('descriptor')!=actual_ref or approval.get('binding')!=binding_ref
                    or approval.get('baseSHA256')!=binding['baseSHA256']
                    or approval.get('acknowledged') is not True):
                fail('invalid_approval','Approval is stale or does not match this descriptor, base and converter. Make a fresh comparison.')
            previews=approval.get('previews')
            if not isinstance(previews,list) or len(previews)!=2:
                fail('invalid_approval','Approval has no completed comparison.')
            checked=[_preview(version,approval['reviewID'],p,actual_ref,base,binding) for p in previews]
            source_id=_comparison(checked,'invalid_approval')
            if approval.get('sourceProjectID')!=source_id:
                fail('invalid_approval','Approval source project differs from its completed comparison.')
            if approval.get('scoreSHA256')!=checked[0][1]['scoreSHA256']:
                fail('invalid_approval','Approval score differs from its completed comparison.')
            adapted=next(p for p,_ in checked if p['role']=='adapted')
            adapted_report=read_json_file(Path(adapted['result']['path']),MAX_INDEX_BYTES)
            if approval.get('auditionedSelection')!=adapted_report['importedSound']['selection']:
                fail('invalid_approval','Auditioned selection differs from completed preview.')
        # The applicator multiplies master Amount exactly once. Resolve only
        # the raw per-branch multiplier here; effective_scales is used to
        # identify active branches, not as the packet's scale value.
        references=[{'branch':branch,'scale':selection[branch+'Scale'],'path':str(version/binding['normalized'][branch]['path']),
                     'sha256':binding['normalized'][branch]['sha256']}
                    for branch in sorted(scales)]
        source={branch:{field:details[field] for field in ('weights','config')}
                for branch,details in descriptor['branches'].items()}
        return {'base':base,'references':references,'provenance':{
            'packageID':package_id,'versionID':version_id,'descriptor':actual_ref,
            'approval':approval_ref,'normalized':_absolute_normalized(version,binding),'source':source,
            'converter':binding['converter'],'licenseStatus':descriptor['licenseStatus'],
            'auditionedSelection':approval['auditionedSelection'] if approval else None}}
