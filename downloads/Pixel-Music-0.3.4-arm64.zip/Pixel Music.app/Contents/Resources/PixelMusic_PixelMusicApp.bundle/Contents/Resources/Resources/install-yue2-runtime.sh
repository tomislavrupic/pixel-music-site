#!/bin/zsh
set -euo pipefail
runtime_dir="$1"
model_dir="$2"
uv_bin=""
for candidate in "$HOME/.local/bin/uv" /opt/homebrew/bin/uv /usr/local/bin/uv; do
  if [[ -x "$candidate" ]]; then uv_bin="$candidate"; break; fi
done
if [[ -z "$uv_bin" ]]; then echo 'uv is required to install the isolated YuE2 runtime.' >&2; exit 65; fi
echo 'PIXEL_MUSIC_PROGRESS=0.03'
echo 'PIXEL_MUSIC_STATUS=Preparing isolated YuE2 Python 3.12 runtime'
if [[ ! -x "$runtime_dir/bin/python" ]]; then "$uv_bin" venv --python 3.12 "$runtime_dir"; fi
"$uv_bin" pip install --python "$runtime_dir/bin/python" 'mlx==0.31.1' 'numpy==2.4.2' 'tiktoken==0.12.0' 'huggingface-hub==1.4.1'
echo 'PIXEL_MUSIC_PROGRESS=0.15'
echo 'PIXEL_MUSIC_STATUS=Downloading pinned YuE2 BF16 model and decoder (about 7 GB)'
"$runtime_dir/bin/python" - "$model_dir" <<'PY'
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from huggingface_hub import snapshot_download
root = Path(sys.argv[1])
repo = 'ahmadw/YuE2-3B-MLX'
rev = 'fe0a9050fd658257b486b880422d8872ee1f81e3'
snapshot_download(repo_id=repo, revision=rev, local_dir=root,
    allow_patterns=['bf16/*','generate.py','yue2_model.py','yue2_vae.py','README.md'])
print('PIXEL_MUSIC_PROGRESS=0.90', flush=True)
print('PIXEL_MUSIC_STATUS=Verifying full-precision weights and inference source', flush=True)
required = ['generate.py','yue2_model.py','yue2_vae.py','bf16/model.safetensors','bf16/vae.safetensors',
    'bf16/config.json','bf16/vae_config.json','bf16/qwen.tiktoken','bf16/yue2_generation_config.json']
hashes = {}
for name in required:
    path = root/name
    if path.is_symlink() or not path.is_file() or path.stat().st_size == 0:
        raise SystemExit('Incomplete YuE2 file: '+name)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8*1024*1024), b''): digest.update(block)
    hashes[name] = digest.hexdigest()
if json.loads((root/'bf16/config.json').read_text()).get('quantization'):
    raise SystemExit('Expected BF16 weights.')
import mlx.core as mx
import tiktoken
import numpy
assert mx.metal.is_available(), 'Apple Silicon Metal is required'
sys.path.insert(0, str(root))
import generate
(root/'pixel-yue2-files.json').write_text(json.dumps(hashes, indent=2))
(root/'.pixel-music-model-lock.json').write_text(json.dumps({
    'repository':repo, 'revision':rev, 'downloadedAt':datetime.now(timezone.utc).isoformat(),
    'components':{'YuE2-Vae':rev,'YuE2-MLX-source':rev}}, indent=2))
PY
echo 'PIXEL_MUSIC_PROGRESS=1.0'
echo 'PIXEL_MUSIC_STATUS=YuE2 BF16 files and runtime verified; listening test not yet run'
