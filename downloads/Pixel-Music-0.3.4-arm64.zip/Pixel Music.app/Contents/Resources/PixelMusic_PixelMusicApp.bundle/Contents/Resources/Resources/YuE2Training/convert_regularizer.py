"""One-time data-only conversion in a Torch environment; training stays MLX."""
import argparse
import json
from pathlib import Path
import numpy as np
import torch
p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
if a.output.exists():raise FileExistsError(a.output)
# Only NumPy array reconstruction and integer dtype objects are allowed, never arbitrary globals.
reconstruct=np.core.multiarray._reconstruct
allowed=[np.ndarray,np.dtype,(reconstruct,'numpy._core.multiarray._reconstruct'),(reconstruct,'numpy.core.multiarray._reconstruct')]
allowed += [type(np.dtype(t)) for t in ('int16','int32','int64','uint16')]
with torch.serialization.safe_globals(allowed): data=torch.load(a.source,map_location='cpu',weights_only=True)
rows=[]
for row in data:
    codes=np.asarray(row['codec'])
    if codes.ndim!=1 or codes.dtype.kind not in 'iu' or not len(codes) or np.any(codes<0) or np.any(codes>=32768):raise ValueError('Invalid regularizer codec')
    rows.append({'name':str(row['name']),'src':str(row['src']),'style':str(row['style']),'lyrics':str(row['lyrics']),'codec':codes.tolist()})
with a.output.open('x') as f:json.dump(rows,f)
print('Converted',len(rows),'records; source roles:',sorted({r['src'] for r in rows}))
