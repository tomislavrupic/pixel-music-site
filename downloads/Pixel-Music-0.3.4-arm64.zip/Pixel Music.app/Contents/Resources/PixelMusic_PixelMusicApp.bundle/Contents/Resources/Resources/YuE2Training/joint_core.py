"""MLX planner + decoder (NAR flow) artist adapter training primitives."""
import math
import mlx.core as mx
import mlx.nn as nn
from mlx.utils import tree_flatten
from core import targets, module_at, LoRALinear, ar_loss, hidden


class ProjectionDelta(nn.Module):
    """A frozen YuE2 projection plus a trainable full precision delta."""
    def __init__(self, base):
        super().__init__()
        if not isinstance(base, nn.Linear): raise ValueError('Projection must be linear')
        self.base = base
        self.diff = mx.zeros(base.weight.shape, dtype=mx.float32)
        self.diff_b = mx.zeros(base.bias.shape, dtype=mx.float32) if base.bias is not None else None
        self.base.freeze()

    def __call__(self, x):
        y = self.base(x) + (x.astype(mx.float32) @ self.diff.T).astype(x.dtype)
        if self.diff_b is not None: y = y + self.diff_b.astype(x.dtype)
        return y


def install_joint_lora(model, rank, decoder_rank=None):
    """Install planner LoRA, decoder LoRA and trainable VAE projection diffs."""
    from core import install_lora
    install_lora(model, rank, 'ar')
    install_lora(model, decoder_rank or rank, 'nar')
    for name in ('vae2llm', 'llm2vae'):
        setattr(model, name, ProjectionDelta(module_at(model, name)))


def prefix_cache(model, ids):
    """Build detached planner KV context for the NAR decoder."""
    x = model.model.embed_tokens(ids)
    cache = []
    for layer in model.model.layers:
        x, kv = layer.ar_prefill_kv(x)
        cache.append((mx.stop_gradient(kv[0]), mx.stop_gradient(kv[1])))
    return cache


def flow_loss(model, latents, noise, raw_t, ids):
    if latents.ndim != 2 or latents.shape[1] != model.config['latent_dim']:
        raise ValueError('Expected [frames, latent_dim] VAE latents')
    if latents.shape != noise.shape: raise ValueError('Noise and latent shapes differ')
    cache = prefix_cache(model, ids[None] if ids.ndim == 1 else ids)
    state = model.config.get('timestep_shift', 1.0)
    sig = mx.sigmoid(mx.array(raw_t, dtype=latents.dtype))
    sigma = state * sig / (1 + (state - 1) * sig)
    xt = sigma * noise + (1 - sigma) * latents
    velocity = model.nar_velocity(xt, raw_t, cache, ids.shape[-1])
    target = noise - latents
    return mx.mean((velocity.astype(mx.float32) - target.astype(mx.float32)) ** 2)


def planner_kl(model, base, ids, prefix_length):
    """KL(base || adapted) on next-token distributions, FS trust region."""
    a = hidden(model, ids, checkpoint_layers=True)[0, prefix_length - 1:-1]
    b = mx.stop_gradient(hidden(base, ids)[0, prefix_length - 1:-1])
    total = mx.array(0.0)
    def chunk(x, y):
        pa = nn.log_softmax(model.lm_head(x).astype(mx.float32), axis=-1)
        pb = mx.stop_gradient(nn.log_softmax(base.lm_head(y).astype(mx.float32), axis=-1))
        return mx.sum(mx.exp(pb) * (pb - pa))
    for i in range(0, a.shape[0], 256):
        total = total + mx.checkpoint(chunk)(a[i:i+256], b[i:i+256])
    return total / a.shape[0]


def joint_loss(model, ids, prefix_length, latents, noise, raw_t, flow_weight=1.0, decoder_ids=None, base=None, kl_weight=0.0):
    if ids.ndim != 2: raise ValueError('Expected [1, tokens]')
    planner = ar_loss(model, ids, prefix_length)
    decoder = flow_loss(model, latents, noise, raw_t, decoder_ids if decoder_ids is not None else ids[0])
    kl = planner_kl(model, base, ids, prefix_length) if base is not None and kl_weight else mx.array(0.0)
    return planner + flow_weight * decoder + kl_weight * kl


def export_joint_adapter(model, path, metadata=None):
    from pathlib import Path
    if Path(path).exists(): raise FileExistsError(path)
    values = {}
    for branch in ('ar', 'nar'):
        for key in targets(model, branch):
            layer = module_at(model, key)
            values[key + '.lora_down.weight'] = layer.A
            values[key + '.lora_up.weight'] = layer.B
    for name in ('vae2llm', 'llm2vae'):
        layer = getattr(model, name)
        values[name + '.diff'] = layer.diff
        if layer.diff_b is not None: values[name + '.diff_b'] = layer.diff_b
    meta = {**(metadata or {}), 'format': 'fl-yue2-lora-v1', 'branch': 'joint', 'decoder': 'nar-flow'}
    mx.save_safetensors(str(path), values, {k: str(v) for k, v in meta.items()})


class JointOptimizers:
    """Separate optimizer states; decoder-only steps never advance AR momentum."""
    def __init__(self, planner_lr, decoder_lr, io_lr):
        from mlx.optimizers import AdamW
        self.optimizers = {k: AdamW(learning_rate=v, weight_decay=0.0)
                           for k,v in [('planner',planner_lr),('decoder',decoder_lr),('io',io_lr)]}
        self.ema = {}

    @property
    def state(self):
        from mlx.utils import tree_unflatten
        return {**{k:v.state for k,v in self.optimizers.items()}, 'ema': tree_unflatten(list(self.ema.items()))}

    @state.setter
    def state(self, values):
        for k,v in self.optimizers.items(): v.state = values[k]
        self.ema = dict(tree_flatten(values['ema']))

    def update(self, model, grads, branch):
        from mlx.utils import tree_unflatten
        from mlx.optimizers import clip_grad_norm
        flat = dict(tree_flatten(grads)); params = dict(tree_flatten(model.trainable_parameters()))
        def group(k):
            return 'io' if k.startswith(('vae2llm.', 'llm2vae.')) else 'decoder' if '.nar_' in k else 'planner'
        selected = [(k,v) for k,v in flat.items() if (group(k)=='planner') == (branch=='planner')]
        selected, norm = clip_grad_norm(dict(selected), 1.0)
        for name in (('planner',) if branch=='planner' else ('decoder','io')):
            g = {k:v for k,v in selected.items() if group(k)==name}
            if g:
                updated = self.optimizers[name].apply_gradients(tree_unflatten(list(g.items())), tree_unflatten([(k,params[k]) for k in g]))
                model.update(updated)
        mx.eval(model.trainable_parameters(), self.state)
        return norm
