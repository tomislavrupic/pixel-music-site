#!/bin/zsh
set -euo pipefail

ace_root="$1"
source_dir="$2"
runtime_dir="$3"
checkpoints_dir="$4"
source_commit="14c0211d5a0653b0f63e27686f4c3f151b4d8629"
export HF_HUB_DISABLE_XET="${HF_HUB_DISABLE_XET:-1}"

echo "PIXEL_MUSIC_PROGRESS=0.03"
echo "PIXEL_MUSIC_STATUS=Preparing pinned ACE-Step source"
mkdir -p "$ace_root" "$checkpoints_dir"

if [[ -d "$source_dir/.git" ]]; then
  if [[ -n "$(git -C "$source_dir" status --porcelain)" ]]; then
    echo "The app-managed ACE-Step source has local changes. Move or preserve them before repairing the runtime." >&2
    exit 65
  fi
  git -C "$source_dir" fetch --quiet origin "$source_commit"
  git -C "$source_dir" checkout --quiet --detach "$source_commit"
elif [[ -e "$source_dir" ]]; then
  echo "ACE-Step source path exists but is not the managed Git checkout: $source_dir" >&2
  exit 65
else
  git clone --quiet https://github.com/ace-step/ACE-Step-1.5.git "$source_dir"
  git -C "$source_dir" checkout --quiet --detach "$source_commit"
fi

uv_bin=""
for candidate in "$HOME/.local/bin/uv" /opt/homebrew/bin/uv /usr/local/bin/uv; do
  if [[ -x "$candidate" ]]; then
    uv_bin="$candidate"
    break
  fi
done
if [[ -z "$uv_bin" ]]; then
  echo "uv is required for the isolated ACE-Step Python 3.11 runtime." >&2
  exit 65
fi

echo "PIXEL_MUSIC_PROGRESS=0.10"
echo "PIXEL_MUSIC_STATUS=Creating ACE-Step Python 3.11 runtime"
if [[ ! -x "$runtime_dir/bin/python" ]]; then
  "$uv_bin" venv --python 3.11 "$runtime_dir"
fi

echo "PIXEL_MUSIC_PROGRESS=0.16"
echo "PIXEL_MUSIC_STATUS=Installing pinned ACE-Step MLX runtime"
"$uv_bin" pip install --python "$runtime_dir/bin/python" --editable "$source_dir"

export ACESTEP_CHECKPOINTS_DIR="$checkpoints_dir"
echo "PIXEL_MUSIC_PROGRESS=0.30"
echo "PIXEL_MUSIC_STATUS=Downloading ACE-Step shared components"
"$runtime_dir/bin/python" -m acestep.model_downloader --model main --dir "$checkpoints_dir"

echo "PIXEL_MUSIC_PROGRESS=0.52"
echo "PIXEL_MUSIC_STATUS=Downloading ACE-Step 1.5 XL SFT full-quality model"
"$runtime_dir/bin/python" -m acestep.model_downloader --model acestep-v15-xl-sft --dir "$checkpoints_dir"

echo "PIXEL_MUSIC_PROGRESS=0.76"
echo "PIXEL_MUSIC_STATUS=Downloading ACE-Step 4B composition model"
"$runtime_dir/bin/python" -m acestep.model_downloader --model acestep-5Hz-lm-4B --dir "$checkpoints_dir"

echo "PIXEL_MUSIC_PROGRESS=0.96"
echo "PIXEL_MUSIC_STATUS=Verifying exact ACE-Step stack"
"$runtime_dir/bin/python" - "$checkpoints_dir" <<'PY'
from datetime import datetime, timezone
from huggingface_hub import HfApi
import importlib.metadata as metadata
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
required = ["acestep-v15-xl-sft", "acestep-5Hz-lm-4B", "vae", "Qwen3-Embedding-0.6B"]
missing = [name for name in required if not (root / name).is_dir()]
if missing:
    raise SystemExit("Missing ACE-Step checkpoints: " + ", ".join(missing))

def verify_index(folder):
    directory = root / folder
    index_path = directory / "model.safetensors.index.json"
    index = json.loads(index_path.read_text(encoding="utf-8"))
    weight_files = sorted(set(index.get("weight_map", {}).values()))
    missing_weights = [
        name for name in weight_files
        if not (directory / name).is_file() or (directory / name).stat().st_size == 0
    ]
    if not weight_files or missing_weights:
        raise SystemExit(
            f"Incomplete ACE-Step weights in {folder}: "
            + ", ".join(missing_weights or ["empty weight map"])
        )

verify_index("acestep-v15-xl-sft")
verify_index("acestep-5Hz-lm-4B")
for relative in [
    "vae/diffusion_pytorch_model.safetensors",
    "Qwen3-Embedding-0.6B/model.safetensors",
]:
    path = root / relative
    if not path.is_file() or path.stat().st_size == 0:
        raise SystemExit("Incomplete ACE-Step component: " + relative)
import acestep
import mlx
revision = HfApi().model_info("ACE-Step/acestep-v15-xl-sft").sha
composition_revision = HfApi().model_info("ACE-Step/acestep-5Hz-lm-4B").sha
lock = {
    "repository": "ACE-Step/acestep-v15-xl-sft",
    "revision": revision,
    "downloadedAt": datetime.now(timezone.utc).isoformat(),
    "components": {
        "ACE-Step/acestep-5Hz-lm-4B": composition_revision,
    },
}
(root / ".pixel-music-model-lock.json").write_text(
    json.dumps(lock, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)
print("ace-step", metadata.version("ace-step"), "mlx", metadata.version("mlx"))
PY

echo "PIXEL_MUSIC_PROGRESS=1.0"
echo "PIXEL_MUSIC_STATUS=ACE-Step XL SFT and 4B LM verified"
