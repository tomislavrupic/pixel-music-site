#!/bin/bash
set -euo pipefail
root="$1"
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
command -v ffmpeg >/dev/null || { echo 'Install FFmpeg before setting up song covers.'; exit 1; }
python_bin="$(command -v python3.11 || true)"
[ -n "$python_bin" ] || { echo 'Python 3.11 is required for song covers.'; exit 1; }
mkdir -p "$root"
if [ ! -x "$root/runtime/bin/python" ]; then "$python_bin" -m venv "$root/runtime"; fi
"$root/runtime/bin/python" -m pip install 'torch==2.8.0' 'torchaudio==2.8.0' 'transformers==4.45.2' 'huggingface-hub==0.36.0' 'safetensors==0.5.3' 'numpy==1.24.3' 'scipy==1.13.1' 'mir_eval==0.8.2' 'pretty_midi==0.2.10' 'mido==1.3.3' 'setuptools==78.1.1'
"$root/runtime/bin/python" - "$root" <<'PY'
import hashlib,json,sys
from pathlib import Path
from huggingface_hub import snapshot_download
root=Path(sys.argv[1])
models=[('m-a-p/SheetSage2','eab522a8168e8b8b8c4856bf8609cd86198f01fe','SheetSage2'),('m-a-p/MERT-v2-FullSong','d8ba1c745e733b3908ce6ad16ebeb17ac7600a42','MERT2')]
files={}
for repo,rev,name in models:
    snapshot_download(repo,revision=rev,local_dir=root/name,allow_patterns=['*.py','*.json','*.safetensors','*.txt'])
    for p in (root/name).iterdir():
        if p.is_file():
            h=hashlib.sha256()
            with p.open('rb') as f:
                for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
            files[str(p.relative_to(root))]=h.hexdigest()
# Imports verify the environment; no model loading or inference during setup.
import torch,torchaudio,transformers
(root/'installed.json').write_text(json.dumps({'models':models,'files':files,'torch':torch.__version__},indent=2))
PY
