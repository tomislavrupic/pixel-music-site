"""Train AR adapters from reviewed, pre-tokenized datasets. No audio inference."""
import argparse
import hashlib
import importlib.metadata
import json
import math
import random
import sys
import time
from pathlib import Path
import mlx.core as mx
import mlx.nn as nn
import mlx.optimizers as optim
from core import install_lora, ar_loss, export_adapter
from checkpoint import save_resume,load_resume
from selection import Selection


def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''): h.update(block)
    return h.hexdigest()


def validate_rows(rows, vocab, limit):
    if not isinstance(rows,list) or not rows:
        raise ValueError('Dataset must contain nonempty artist and regularizer arrays')
    for row in rows:
        ids,prefix=row['ids'],row['prefix_length']
        if not isinstance(ids,list) or not isinstance(prefix,int) or not 1<=prefix<len(ids)<=limit:
            raise ValueError('Invalid prefix/sequence length; no silent truncation')
        if any(type(t) is not int or not 0<=t<vocab for t in ids):
            raise ValueError('Invalid token ID')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model-source',type=Path,required=True,help='Pinned MLX source directory containing bf16/')
    p.add_argument('--dataset',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True,help='NEW run directory, never overwritten')
    p.add_argument('--steps',type=int,default=100)
    p.add_argument('--resume',type=Path,help='Resume saved optimizer/RNG into a NEW output directory')
    p.add_argument('--rank',type=int,default=16)
    p.add_argument('--learning-rate',type=float,default=1e-4)
    p.add_argument('--save-every',type=int,default=50)
    p.add_argument('--sequence-limit',type=int,default=2048)
    p.add_argument('--seed',type=int,default=7)
    p.add_argument('--patience',type=int,default=3,help='Stop after this many non-improving checkpoints; 0 disables')
    p.add_argument('--no-checkpointing',action='store_true')
    p.add_argument('--regularizer-fraction',type=float,default=0.5)
    args=p.parse_args()
    if min(args.steps,args.rank,args.save_every,args.sequence_limit)<1 or not math.isfinite(args.learning_rate) or args.learning_rate<=0 or not 0<args.regularizer_fraction<1:
        p.error('Invalid training settings')
    if args.patience<0:p.error('Patience must be nonnegative')
    if args.sequence_limit>24576: p.error('Sequence limit exceeds YuE2 context')
    if not mx.metal.is_available(): p.error('Metal is required')
    data=json.loads(args.dataset.read_text())
    model_path=args.model_source/'bf16'
    cfg=json.loads((model_path/'config.json').read_text())
    if cfg.get('quantization'): p.error('This trainer requires unquantized BF16 weights')
    for group in ('artist','regularizer'): validate_rows(data[group],cfg['vocab_size'],args.sequence_limit)
    if data.get('validation'):validate_rows(data['validation'],cfg['vocab_size'],args.sequence_limit)
    base_sha=sha256(model_path/'model.safetensors')
    if isinstance(data.get('acoustic_companion'),dict):
        comp=data['acoustic_companion']
        if comp['base_sha256']!=base_sha or sha256(comp['path'])!=comp['sha256']:p.error('Dataset base/companion mismatch')
    if isinstance(data.get('provenance'),dict) and data['provenance'].get('base_sha256',base_sha)!=base_sha:p.error('Dataset provenance base mismatch')
    if not data.get('provenance') or not data.get('acoustic_companion'):
        p.error('Dataset must identify provenance and the required acoustic_companion')
    args.output.mkdir(parents=True,exist_ok=False)
    settings={k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()}
    settings.update(dataset_sha256=sha256(args.dataset),base_sha256=base_sha,
                    source_sha256=sha256(args.model_source/'yue2_model.py'),dataset_provenance=data['provenance'],
                    acoustic_companion=data['acoustic_companion'],status='started',
                    toolkit_sha256={p.name:sha256(p) for p in Path(__file__).parent.glob('*.py')},
                    runtime={n:importlib.metadata.version(n) for n in ('mlx','numpy')})
    (args.output/'run.json').write_text(json.dumps(settings,indent=2))
    sys.path.insert(0,str(args.model_source.resolve()))
    from yue2_model import load_model
    model=load_model(model_path)
    mx.random.seed(args.seed)
    rng=random.Random(args.seed)
    install_lora(model,args.rank)
    model.eval()  # Frozen base has no training dropout; LoRA still differentiable.
    def training_loss(model,ids,prefix):
        return ar_loss(model,ids,prefix,checkpoint_layers=not args.no_checkpointing)
    step=nn.value_and_grad(model,training_loss)
    optimizer=optim.AdamW(learning_rate=args.learning_rate,weight_decay=0.01)
    signature={k:settings[k] for k in ('rank','learning_rate','seed','regularizer_fraction','sequence_limit','no_checkpointing','dataset_sha256','base_sha256','source_sha256','acoustic_companion')}
    start_step=load_resume(args.resume,model,optimizer,rng,signature) if args.resume else 0
    if args.steps<=start_step:raise ValueError('Steps must exceed resumed step')
    start=time.monotonic()
    def evaluate(label):
        rows=data.get('validation',[])
        if not rows:return {}
        values=[]
        for row in rows:
            value=float(ar_loss(model,mx.array([row['ids']]),row['prefix_length']).item())
            if not math.isfinite(value):raise FloatingPointError('Non-finite validation loss')
            values.append({'name':row['name'],'source':row.get('source','artist_audio'),'loss':value})
        (args.output/f'validation-{label}.json').write_text(json.dumps(values,indent=2))
        groups={}
        for r in values:groups.setdefault(r['source'],[]).append(r['loss'])
        means={k:sum(v)/len(v) for k,v in groups.items()}
        print(json.dumps({'validation':label,'losses':means}),flush=True)
        return means
    try:
        if args.resume:
            selection=Selection.restore(args.resume.parent,signature,args.patience)
            # Keep validation-before the original base, including across repeated resumes.
            (args.output/'validation-before.json').write_bytes((args.resume.parent/'validation-before.json').read_bytes())
            evaluate('resumed')
        else:
            selection=Selection(evaluate('before'),args.patience)
        (args.output/'selection.json').write_text(json.dumps(selection.report(),indent=2))
        with (args.output/'metrics.jsonl').open('x') as log:
            for n in range(start_step+1,args.steps+1):
                group='regularizer' if rng.random()<args.regularizer_fraction else 'artist'
                row=rng.choice(data[group])
                loss,grad=step(model,mx.array([row['ids']]),row['prefix_length'])
                mx.eval(loss,grad)
                if not math.isfinite(float(loss.item())): raise FloatingPointError('Non-finite loss')
                clipped,norm=optim.clip_grad_norm(grad,1.0)
                if not math.isfinite(float(norm.item())): raise FloatingPointError('Non-finite gradient')
                optimizer.update(model,clipped)
                mx.eval(model.parameters(),optimizer.state)
                metrics=dict(step=n,group=group,loss=float(loss.item()),seconds=time.monotonic()-start,
                             peak_memory_bytes=mx.get_peak_memory(),gradient_norm=float(norm.item()))
                line=json.dumps(metrics)
                print(line,flush=True)
                log.write(line+'\n'); log.flush()
                if n%args.save_every==0 or n==args.steps:
                    path=(args.output/f'step-{n:06d}.safetensors').resolve()
                    export_adapter(model,path,{'base_sha256':settings['base_sha256'],
                        'dataset_sha256':settings['dataset_sha256'],'step':n,
                        'acoustic_companion':json.dumps(data['acoustic_companion'])})
                    (path.with_suffix('.sha256')).write_text(sha256(path)+'\n')
                    save_resume(args.output/f'resume-{n:06d}',model,optimizer,rng,n,signature)
                    stop=selection.consider(path,evaluate(f'step-{n:06d}'))
                    (args.output/'selection.json').write_text(json.dumps(selection.report(),indent=2))
                    if stop:
                        settings['early_stopped_at']=n
                        break
        evaluate('after')
        settings['status']='completed'
    except BaseException:
        settings['status']='interrupted_or_failed'
        raise
    finally:
        (args.output/'run.json').write_text(json.dumps(settings,indent=2))

if __name__=='__main__': main()
