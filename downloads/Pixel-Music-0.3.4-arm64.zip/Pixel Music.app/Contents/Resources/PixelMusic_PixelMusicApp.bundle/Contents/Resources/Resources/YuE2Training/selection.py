"""Held-out loss selection is a technical signal, never listening acceptance."""
import math
class Selection:
    def __init__(self,baseline,patience=3):
        self.baseline=baseline;self.patience=patience;self.stale=0;self.best_checkpoint=None
        self.best_score=sum(baseline.values())/len(baseline) if baseline else float('inf')
    def consider(self,path,losses):
        if not self.baseline:return False
        if set(losses)!=set(self.baseline) or not all(math.isfinite(v) for v in losses.values()):raise ValueError('Invalid validation groups')
        score=sum(losses.values())/len(losses)
        if score<self.best_score and all(losses[k]<=v*1.02 for k,v in self.baseline.items()):
            self.best_score=score;self.best_checkpoint=str(path);self.stale=0
        else:self.stale+=1
        return self.patience>0 and self.stale>=self.patience
    def report(self):
        return {'baseline':self.baseline,'best_checkpoint':self.best_checkpoint,
                'best_score':self.best_score if self.baseline else None,'stale_evaluations':self.stale,
                'rule':'equal mean across source groups; no group >2% above baseline; lower score wins',
                'listening_accepted':False}

    @classmethod
    def restore(cls, run, signature, patience=3):
        """Restore the original holdout baseline and verified immutable winner."""
        import json
        from pathlib import Path
        run=Path(run)
        settings=json.loads((run/'run.json').read_text())
        for key in ('dataset_sha256','base_sha256','acoustic_companion'):
            if settings.get(key)!=signature.get(key):raise ValueError('Selection resume provenance mismatch')
        baseline=validation_means(run/'validation-before.json')
        selection=cls(baseline,patience)
        report_path=run/'selection.json'
        if not report_path.exists():return selection  # Interrupted before first completed evaluation.
        report=json.loads(report_path.read_text())
        if report.get('baseline')!=baseline:raise ValueError('Original validation baseline mismatch')
        best=report.get('best_checkpoint')
        if best:
            candidate=Path(best)
            if not candidate.is_absolute():raise ValueError('Selected checkpoint must be absolute')
            verify_candidate(candidate,signature)
            losses=validation_means(candidate.parent/('validation-'+candidate.stem+'.json'))
            selection.consider(candidate,losses)
            if selection.best_checkpoint is None or not math.isclose(selection.best_score,report['best_score'],rel_tol=1e-12):
                raise ValueError('Prior checkpoint does not satisfy original selection rule')
        elif report.get('best_score')!=(selection.best_score if baseline else None):
            raise ValueError('Invalid prior base score')
        stale=report.get('stale_evaluations',0)
        if not isinstance(stale,int) or isinstance(stale,bool) or stale<0:raise ValueError('Invalid stale count')
        selection.stale=stale
        return selection


def validation_means(path):
    import json
    groups={}
    for row in json.loads(path.read_text()):
        loss=row['loss']
        if not isinstance(loss,(int,float)) or isinstance(loss,bool) or not math.isfinite(loss):raise ValueError('Invalid validation loss')
        groups.setdefault(row['source'],[]).append(loss)
    return {key:sum(values)/len(values) for key,values in groups.items()}


def verify_candidate(path,signature):
    import hashlib,json,struct
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    if h.hexdigest()!=path.with_suffix('.sha256').read_text().strip():raise ValueError('Prior adapter checksum mismatch')
    with path.open('rb') as stream:
        raw=stream.read(8)
        if len(raw)!=8:raise ValueError('Invalid prior adapter')
        size=struct.unpack('<Q',raw)[0]
        if size>16*1024*1024:raise ValueError('Invalid prior adapter header')
        meta=json.loads(stream.read(size)).get('__metadata__',{})
    if meta.get('format')!='fl-yue2-lora-v1' or meta.get('branch')!='ar':raise ValueError('Invalid prior adapter type')
    for key in ('dataset_sha256','base_sha256'):
        if meta.get(key)!=signature.get(key):raise ValueError('Prior adapter provenance mismatch')
    if json.loads(meta.get('acoustic_companion','{}'))!=signature.get('acoustic_companion'):raise ValueError('Prior acoustic companion mismatch')
