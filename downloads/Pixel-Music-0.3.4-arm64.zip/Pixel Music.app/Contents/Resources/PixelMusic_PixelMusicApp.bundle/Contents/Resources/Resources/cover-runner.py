"""Pixel Music's local FLUX Klein cover adapter. Never overwrites a cover."""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import time


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--request', required=True)
    args = parser.parse_args()
    request = json.loads(Path(args.request).read_text())
    output = Path(request['output'])
    if output.exists() or output.suffix != '.png' or not output.parent.is_dir():
        raise ValueError('Cover output must be a new PNG in the reserved project folder.')
    model_path = Path(request['modelPath'])
    manifest_path = model_path / 'ali-model-manifest.json'
    manifest = json.loads(manifest_path.read_text())
    if manifest['repository'] != 'black-forest-labs/FLUX.2-klein-4B':
        raise ValueError('Select the installed FLUX.2 Klein 4B model.')
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    from mflux.models.common.config import ModelConfig
    from mflux.models.flux2.variants import Flux2Klein
    started = time.monotonic()
    model = Flux2Klein(model_config=ModelConfig.flux2_klein_4b(), model_path=str(model_path), quantize=None)
    result = model.generate_image(seed=request['seed'], prompt=request['prompt'], width=768, height=768,
                                  num_inference_steps=4, guidance=1.0)
    staged = output.parent / 'render.partial.png'
    result.image.save(staged, format='PNG')
    report = dict(request, modelID=manifest['repository'], modelRevision=manifest.get('revision'),
                  modelManifestSHA256=digest(manifest_path), runtime='mflux',
                  runtimeVersion=importlib.metadata.version('mflux'), adapterSHA256=digest(__file__),
                  width=768, height=768, steps=4, guidance=1.0,
                  elapsedSeconds=time.monotonic()-started, sha256=digest(staged))
    (output.parent / 'result.json').write_text(json.dumps(report, indent=2))
    os.link(staged, output)
    staged.unlink()


if __name__ == '__main__':
    main()
