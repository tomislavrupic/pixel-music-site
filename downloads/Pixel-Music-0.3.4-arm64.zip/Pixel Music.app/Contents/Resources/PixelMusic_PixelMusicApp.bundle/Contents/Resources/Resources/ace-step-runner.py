#!/usr/bin/env python3
"""Narrow Pixel Music bridge for the pinned ACE-Step 1.5 XL SFT runtime."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
import sys
import tempfile


XL_MODEL = "acestep-v15-xl-sft"
XL_LM = "acestep-5Hz-lm-4B"


def progress(value: float, message: str) -> None:
    print(f"PIXEL_MUSIC_PROGRESS={value:.2f} {message}", flush=True)


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description="Pixel Music ACE-Step bridge")
    value.add_argument("--checkpoints", required=True)
    value.add_argument("--model", required=True)
    value.add_argument("--lm", required=True)
    value.add_argument("--caption", required=True)
    value.add_argument("--lyrics", required=True)
    value.add_argument("--bpm", required=True, type=int)
    value.add_argument("--keyscale", required=True)
    value.add_argument("--duration", required=True, type=float)
    value.add_argument("--steps", required=True, type=int)
    value.add_argument("--guidance-scale", required=True, type=float)
    value.add_argument("--seed", required=True, type=int)
    value.add_argument("--output", required=True)
    value.add_argument("--instrumental", action="store_true")
    return value


def main() -> int:
    args = parser().parse_args()
    if args.model != XL_MODEL or args.lm != XL_LM:
        raise SystemExit("Pixel Music only certifies ACE-Step 1.5 XL SFT with the 4B LM.")
    if args.steps != 50:
        raise SystemExit("ACE-Step XL SFT must run at the pinned 50-step quality profile.")

    checkpoints = Path(args.checkpoints).expanduser().resolve()
    output = Path(args.output).expanduser().resolve()
    required = [checkpoints / args.model, checkpoints / args.lm, checkpoints / "vae", checkpoints / "Qwen3-Embedding-0.6B"]
    missing = [str(path) for path in required if not path.is_dir()]
    if missing:
        raise SystemExit("ACE-Step checkpoints are incomplete: " + ", ".join(missing))

    os.environ["ACESTEP_CHECKPOINTS_DIR"] = str(checkpoints)
    os.environ["ACESTEP_LM_BACKEND"] = "mlx"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"

    progress(0.05, "Loading ACE-Step 1.5 XL SFT")
    from acestep.handler import AceStepHandler
    from acestep.inference import GenerationConfig, GenerationParams, generate_music
    from acestep.llm_inference import LLMHandler

    dit_handler = AceStepHandler()
    status, ready = dit_handler.initialize_service(
        project_root=str(checkpoints.parent),
        config_path=args.model,
        device="auto",
        offload_to_cpu=False,
        offload_dit_to_cpu=False,
        quantization=None,
        use_mlx_dit=True,
    )
    if not ready:
        raise SystemExit(f"ACE-Step XL SFT failed to initialize: {status}")

    progress(0.11, "Loading ACE-Step 4B composition model")
    lm_handler = LLMHandler()
    status, ready = lm_handler.initialize(
        checkpoint_dir=str(checkpoints),
        lm_model_path=args.lm,
        backend="mlx",
        device="auto",
        offload_to_cpu=False,
        dtype=None,
    )
    if not ready:
        raise SystemExit(f"ACE-Step 4B composition model failed to initialize: {status}")

    params = GenerationParams(
        task_type="text2music",
        caption=args.caption,
        lyrics=args.lyrics,
        instrumental=args.instrumental,
        bpm=args.bpm,
        keyscale=args.keyscale,
        duration=args.duration,
        inference_steps=args.steps,
        guidance_scale=args.guidance_scale,
        seed=args.seed,
        thinking=True,
        use_cot_metas=False,
        use_cot_caption=False,
        use_cot_lyrics=False,
        use_cot_language=False,
        use_constrained_decoding=True,
    )
    config = GenerationConfig(
        batch_size=1,
        use_random_seed=False,
        seeds=[args.seed],
        audio_format="wav",
    )

    output.parent.mkdir(parents=True, exist_ok=True)
    progress(0.18, "Conditioning ACE-Step with the preserved recipe")
    with tempfile.TemporaryDirectory(prefix="pixel-music-ace-step-") as temp_dir:
        result = generate_music(
            dit_handler,
            lm_handler,
            params=params,
            config=config,
            save_dir=temp_dir,
        )
        if not result.success or not result.audios:
            detail = result.error or result.status_message or "unknown ACE-Step failure"
            raise SystemExit(detail)
        generated = Path(result.audios[0]["path"])
        if not generated.is_absolute():
            generated = Path(temp_dir) / generated
        if not generated.is_file():
            raise SystemExit(f"ACE-Step reported a missing output: {generated}")
        progress(0.97, "Writing ACE-Step WAV")
        shutil.copyfile(generated, output)

    print(f"PIXEL_MUSIC_ACE_MODEL={XL_MODEL}", flush=True)
    print(f"PIXEL_MUSIC_ACE_LM={XL_LM}", flush=True)
    progress(1.0, "ACE-Step WAV ready")
    return 0


if __name__ == "__main__":
    sys.exit(main())
