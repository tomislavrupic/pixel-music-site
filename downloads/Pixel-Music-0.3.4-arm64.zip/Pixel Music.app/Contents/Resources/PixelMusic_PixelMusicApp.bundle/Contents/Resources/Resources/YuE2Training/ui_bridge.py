"""Explicit local UI actions. This module never downloads models or overwrites outputs."""
import argparse
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import signal
import struct
import subprocess
import sys
import uuid

HERE = Path(__file__).resolve().parent


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write_new(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')


def absolute(value, kind=None):
    if not isinstance(value, str) or not Path(value).is_absolute():
        raise ValueError('Expected absolute local path')
    p = Path(value).resolve()
    if kind == 'file' and not p.is_file(): raise ValueError(f'Missing file: {p}')
    if kind == 'dir' and not p.is_dir(): raise ValueError(f'Missing directory: {p}')
    return p


def run(command):
    child = subprocess.Popen(command, start_new_session=True)
    previous = {}
    def stop(signum, frame):
        # Keep the UI busy until the child (and its ffmpeg group) has stopped.
        for sig in (signal.SIGTERM, signal.SIGINT): signal.signal(sig, signal.SIG_IGN)
        try: os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError: pass
        try:
            child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            try: os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError: pass
            child.wait()
        raise SystemExit(128 + signum)
    for sig in (signal.SIGTERM, signal.SIGINT):
        previous[sig] = signal.signal(sig, stop)
    try:
        code = child.wait()
        if code: raise subprocess.CalledProcessError(code, command)
    finally:
        for sig, handler in previous.items(): signal.signal(sig, handler)


def command(script, **options):
    result = [sys.executable, str(HERE / script)]
    for key, value in options.items():
        result.extend(['--' + key.replace('_', '-'), str(value)])
    return result


def allocate(workspace, category, action):
    parent = workspace / category
    parent.mkdir(parents=True, exist_ok=True)
    path = parent / str(uuid.uuid4())
    print(json.dumps({'event': 'allocated', 'action': action, category.rstrip('s'): str(path)}), flush=True)
    return path


def adapter_metadata(path):
    with path.open('rb') as f:
        raw = f.read(8)
        if len(raw) != 8: raise ValueError('Invalid adapter header')
        length = struct.unpack('<Q', raw)[0]
        if length > 16 * 1024 * 1024: raise ValueError('Adapter header too large')
        return json.loads(f.read(length)).get('__metadata__', {})


def identities(request):
    dataset = absolute(request['dataset'], 'file')
    adapter = absolute(request['adapter'], 'file')
    model = absolute(request['model_source'], 'dir')
    data = json.loads(dataset.read_text())
    companion = data['acoustic_companion']
    cp = absolute(companion['path'], 'file')
    base = model / 'bf16/model.safetensors'
    ds_hash, ar_hash = digest(dataset), digest(adapter)
    if digest(cp) != companion['sha256'] or digest(base) != companion['base_sha256']:
        raise ValueError('Base or acoustic companion integrity mismatch')
    meta = adapter_metadata(adapter)
    nar_meta = adapter_metadata(cp)
    if meta.get('format') != 'fl-yue2-lora-v1' or meta.get('branch') not in ('ar','joint') or nar_meta.get('format') != 'fl-yue2-lora-v1' or nar_meta.get('branch') != 'nar' or nar_meta.get('base_sha256') != companion['base_sha256']:
        raise ValueError('Invalid AR/NAR adapter format')
    if meta.get('base_sha256') != companion['base_sha256'] or meta.get('dataset_sha256') != ds_hash or json.loads(meta.get('acoustic_companion', '{}')) != companion:
        raise ValueError('Adapter metadata does not match dataset/base/companion')
    return {'adapter': {'path': str(adapter), 'sha256': ar_hash},
            'dataset': {'path': str(dataset), 'sha256': ds_hash},
            'acoustic_companion': companion, 'model_source': str(model),
            'base': {'path': str(base), 'sha256': digest(base)}}


def validate_render(folder, ids, adapted):
    recipe = json.loads((folder / 'recipe.json').read_text())
    if recipe.get('status') != 'completed' or recipe.get('dataset_sha256') != ids['dataset']['sha256'] or recipe.get('adapter_sha256') != (ids['adapter']['sha256'] if adapted else None):
        raise ValueError('Preview render is incomplete or uses different inputs')
    if recipe.get('seed') != 831001 or recipe.get('seconds') != 30 or recipe.get('acoustic_companion') != ids['acoustic_companion']:
        raise ValueError('Preview settings mismatch')
    audio = folder / 'audio.wav'
    if digest(audio) != recipe['audio_sha256']: raise ValueError('Preview master checksum mismatch')


def execute(request):
    workspace = absolute(request['workspace'], 'dir')
    result_path = absolute(request['result'])
    if not result_path.is_relative_to(workspace): raise ValueError('Result must be within workspace')
    if result_path.exists(): raise FileExistsError(result_path)
    if not result_path.parent.is_dir(): raise ValueError('Result parent does not exist')
    action = request['action']
    result = {'schema_version': 1, 'action': action, 'status': 'completed'}
    if action == 'prepare':
        songs = request['songs']
        if not isinstance(songs, list) or not songs: raise ValueError('Songs required')
        clean = []
        for song in songs:
            if song.get('reviewed') is not True or song.get('role') not in ('artist', 'validation'): raise ValueError('Reviewed songs and explicit role required')
            if not all(isinstance(song.get(k), str) and song[k].strip() for k in ('name', 'style', 'lyrics')): raise ValueError('Song name, style and lyrics required')
            item = dict(song); item['audio'] = str(absolute(song['audio'], 'file')); item['sha256'] = digest(item['audio']); clean.append(item)
        if not any(s['role'] == 'artist' for s in clean): raise ValueError('Artist song required')
        if len({s['sha256'] for s in clean}) != len(clean): raise ValueError('Duplicate audio')
        inputs = {k: absolute(request[k], 'file' if k == 'regularizer' else 'dir') for k in ('model_source', 'mert', 'assets', 'regularizer')}
        if request.get('variant') != 'v9' or not request.get('vae'):
            raise ValueError('Restart the updated app: joint preparation requires v9 and the VAE encoder')
        inputs['vae'] = absolute(request['vae'], 'dir')
        inputs['variant'] = 'v9'
        output = allocate(workspace, 'prepared', action)
        manifest = output.with_suffix('.request.json')
        excerpt_folder = output.with_name(output.name + '-excerpts'); excerpt_folder.mkdir()
        import soundfile as sf
        for index, item in enumerate(clean):
            source = item['audio']; info = sf.info(source)
            start = item.get('start_seconds', 0)
            duration = item.get('duration_seconds', info.duration)
            if isinstance(start, bool) or isinstance(duration, bool) or not isinstance(start, (int, float)) or not isinstance(duration, (int, float)) or not math.isfinite(start) or not math.isfinite(duration) or start < 0 or not 1 <= duration <= 60 or start + duration > info.duration + 1 / info.samplerate:
                raise ValueError('Excerpt must be 1–60 seconds and entirely within the original audio')
            audio, rate = sf.read(source, start=round(start * info.samplerate), frames=round(duration * info.samplerate), dtype='float32', always_2d=True)
            excerpt = excerpt_folder / f'{index:04d}.wav'
            sf.write(excerpt, audio, rate, subtype='FLOAT')
            item.update(original_audio=source, original_audio_sha256=item['sha256'], start_seconds=start, duration_seconds=duration, audio=str(excerpt), sha256=digest(excerpt))
        write_new(manifest, {'songs': clean, 'purpose': 'Pixel Music explicitly reviewed artist training'})
        run(command('prepare.py', manifest=manifest, output=output, sequence_limit=2048, **inputs))
        result['dataset'] = str(absolute(str(output / 'dataset.json'), 'file'))
    elif action == 'train':
        dataset = absolute(request['dataset'], 'file'); model = absolute(request['model_source'], 'dir')
        data = json.loads(dataset.read_text())
        rows = data.get('artist', [])
        if (data.get('provenance', {}).get('joint_contract') != 'vae-dilated-v1'
                or not rows or not all(r.get('latents_path') and r.get('latents_sha256') for r in rows)):
            raise ValueError('Prepare dataset again for joint training. This dataset cannot train the decoder.')
        script = 'joint_train.py'
        options = dict(model_source=model, dataset=dataset, steps=60, decoder_steps=90,
                       save_every=6, rank_planner=8, rank_decoder=8, window_frames=128)
        if request.get('resume'):
            checkpoint = absolute(request['resume'], 'dir')
            state = json.loads((checkpoint / 'state.json').read_text())
            if state.get('sha256') != digest(checkpoint / 'state.safetensors'):
                raise ValueError('Incomplete or altered resume checkpoint')
            step = state.get('step')
            if not isinstance(step, int) or isinstance(step, bool) or not 0 <= step < 60:
                raise ValueError('Checkpoint has already reached the 60-step training limit')
            options['resume'] = checkpoint
        output = allocate(workspace, 'runs', action)
        options['output'] = output
        run(command(script, **options))
        result['run'] = str(output)
        selection = output / 'selection.json'
        if selection.is_file():
            selected = json.loads(selection.read_text()).get('best_checkpoint')
            if selected: result['adapter'] = str(absolute(selected, 'file'))
    elif action == 'preview':
        ids = identities(request)
        if not isinstance(request.get('style'), str) or not request['style'].strip(): raise ValueError('Preview style required')
        lyrics = request.get('lyrics', '[instrumental]')
        if not isinstance(lyrics, str) or not lyrics.strip(): raise ValueError('Preview lyrics required')
        output = allocate(workspace, 'previews', action); output.mkdir()
        for label in ('baseline', 'adapted'):
            options = dict(model_source=ids['model_source'], dataset=ids['dataset']['path'], output=output / label, style=request['style'], lyrics=lyrics, seed=831001, seconds=30)
            if label == 'adapted': options['adapter'] = ids['adapter']['path']
            run(command('render.py', **options)); validate_render(output / label, ids, label == 'adapted')
        normalized = shutil.which('ffmpeg') is not None
        if normalized:
            run(command('listening_pair.py', baseline=output / 'baseline/audio.wav', adapted=output / 'adapted/audio.wav', output=output / 'listening'))
        else:
            print('ffmpeg unavailable: audition uses original masters without loudness matching.', flush=True)
        listening = {}
        for label in ('baseline', 'adapted'):
            path = output / 'listening' / (label + '.wav') if normalized else output / label / 'audio.wav'
            listening[label] = {'path': str(path), 'sha256': digest(path)}
        write_new(output / 'preview.json', dict(ids, status='completed', normalized=normalized, listening=listening, seed=831001, seconds=30, style=request['style'], lyrics=lyrics))
        result.update(preview=str(output), normalized=normalized, **{k: v['path'] for k, v in listening.items()})
    elif action == 'approve':
        ids = identities(request); preview = absolute(request['preview'], 'dir')
        record = json.loads((preview / 'preview.json').read_text())
        if record.get('status') != 'completed' or any(record.get(k) != v for k, v in ids.items()): raise ValueError('Preview does not match selected adapter/dataset')
        for label in ('baseline', 'adapted'):
            validate_render(preview / label, ids, label == 'adapted')
            item = record['listening'][label]
            if digest(absolute(item['path'], 'file')) != item['sha256']: raise ValueError('Listening file checksum mismatch')
        name = request.get('name')
        if not isinstance(name, str) or not name.strip(): raise ValueError('Style name required')
        output = allocate(workspace, 'approvals', action).with_suffix('.json')
        write_new(output, dict(ids, schema_version=1, status='approved', id=output.stem, name=name.strip(), preview={'path': str(preview), 'sha256': digest(preview / 'preview.json')}, runtime='mlx', protocol='yue2-joint-style-v1' if adapter_metadata(Path(ids['adapter']['path'])).get('branch') == 'joint' else 'yue2-ar-style-v1', planning='off', created_at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        result['approval'] = str(output)
    else:
        raise ValueError('Unknown action')
    write_new(result_path, result)
    print(json.dumps(result), flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=Path, required=True)
    args = parser.parse_args()
    execute(json.loads(args.request.read_text()))


if __name__ == '__main__': main()
