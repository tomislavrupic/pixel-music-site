#!/usr/bin/env python3
"""Pixel Music adapter for the pinned community YuE2 MLX port. No inference at import."""
import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import sys
import time

REPOSITORY = 'ahmadw/YuE2-3B-MLX'
REVISION = 'fe0a9050fd658257b486b880422d8872ee1f81e3'
_style_spec = importlib.util.spec_from_file_location('pixel_music_style_adapter', Path(__file__).with_name('style_adapter.py'))
style_adapter = importlib.util.module_from_spec(_style_spec)
_style_spec.loader.exec_module(style_adapter)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def reserve_output(out):
    if out.exists() or out.is_symlink():
        raise FileExistsError('A master already exists at this output path.')
    artifacts = out.with_suffix('.yue2')
    artifacts.mkdir(parents=False, exist_ok=False)
    return artifacts


def verify_latent(path, expected):
    if Path(path).is_symlink() or not Path(path).is_file() or sha256(path) != expected:
        raise ValueError('The saved source latent is missing or its checksum changed.')


def semantic_budget(options, duration, model_max):
    return min(model_max, 9000) if options.get('autoDuration') is True else duration * 25


def validate_options(options, duration):
    style_adapter.validate_options(options)
    mode = options.get('planning', 'full')
    if mode not in ('full', 'melody', 'off') or (mode == 'off' and options.get('abc', '').strip()):
        raise ValueError('ABC input requires melody/full planning.')
    for name, low, high, default in [('guidance', .1, 10, 1), ('steps', 1, 128, 32),
            ('temperature', 0, 2, 1), ('topP', .01, 1, .95), ('topK', 1, 184704, 100),
            ('repetitionPenalty', 1, 2, 1.2), ('penaltyWindow', 1, 1000, 50)]:
        value = options.get(name, default)
        if not isinstance(value, (int, float)) or not math.isfinite(value) or not low <= value <= high:
            raise ValueError('Invalid YuE2 setting: ' + name)
    if not 10 <= duration <= 360:
        raise ValueError('Duration cap must be 10–360 seconds.')


def verify_install(root):
    lock = json.loads((root/'.pixel-music-model-lock.json').read_text())
    if lock['repository'] != REPOSITORY or lock['revision'] != REVISION:
        raise ValueError('The installed YuE2 revision does not match this adapter.')
    manifest = json.loads((root/'pixel-yue2-files.json').read_text())
    required = ['generate.py', 'yue2_model.py', 'yue2_vae.py', 'bf16/model.safetensors',
                'bf16/vae.safetensors', 'bf16/config.json', 'bf16/vae_config.json',
                'bf16/qwen.tiktoken', 'bf16/yue2_generation_config.json']
    for name in required:
        path = root/name
        if path.is_symlink() or not path.is_file() or sha256(path) != manifest.get(name):
            raise ValueError('Installed YuE2 file changed or is incomplete: ' + name)
    config = json.loads((root/'bf16/config.json').read_text())
    if config.get('quantization'):
        raise ValueError('This installation requires BF16, not quantized weights.')
    return lock, manifest


def conditioned_style(request):
    root_names = {'cSharp':'C-sharp', 'dSharp':'D-sharp', 'fSharp':'F-sharp', 'gSharp':'G-sharp', 'aSharp':'A-sharp'}
    root = root_names.get(request['rootNote'], request['rootNote'].upper())
    import re
    scale = re.sub(r'(?<!^)(?=[A-Z])', ' ', request['scale']).lower()
    caption = request['caption'].strip()
    vocal = request.get('vocalChoice', 'prompted')
    if vocal not in ('male', 'female', 'prompted'):
        raise ValueError('Unknown vocal choice')
    if vocal != 'prompted' and request.get('lyrics', '').strip().lower() != '[instrumental]':
        caption += '\n' + vocal.capitalize() + ' lead vocals. This vocal choice takes precedence over conflicting voice descriptions.'
    return caption + f"\nTempo: {request['tempoBPM']} BPM. Key: {root} {scale}."


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--request-json', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    request = json.loads(args.request_json)
    options = request['yue2']
    validate_options(options, request['durationSeconds'])
    if request['provider'] != 'yue2-mlx' or request['modelID'] != REPOSITORY:
        raise ValueError('Recipe is not a YuE2 recipe.')
    out = args.out.absolute()
    artifacts = reserve_output(out)
    started = time.monotonic()
    (artifacts/'request.json').write_text(json.dumps(request, indent=2, ensure_ascii=False))
    print('PIXEL_MUSIC_PROGRESS=0.04 YuE2 loading and verifying BF16', flush=True)
    lock, hashes = verify_install(args.model)
    trained_style = style_adapter.verify(options, args.model) if not options.get('decodeLatentsPath') else None
    sys.path.insert(0, str(args.model))
    import mlx.core as mx
    import numpy as np
    from generate import Yue2Pipeline, Sampling, write_wav
    if not mx.metal.is_available():
        raise RuntimeError('Apple Silicon Metal is required.')
    warnings = []
    def log(message):
        print(message, flush=True)
        if '[plan] ABC hit max_tokens' in message:
            raise ValueError('Score planning exceeded its context budget. Shorten lyrics or supply an ABC score.')
        if '[semantic] hit max_tokens' in message:
            warnings.append('Length cap reached; the song may end before a natural ending.')
            print('YUE2_TRUNCATED', flush=True)
        if message.startswith('[plan]'):
            print('PIXEL_MUSIC_PROGRESS=0.12 YuE2 conditioning score', flush=True)
        elif message.startswith('[semantic]'):
            print('PIXEL_MUSIC_PROGRESS=0.25 YuE2 generating song tokens', flush=True)
        elif message.startswith('[nar]'):
            print('PIXEL_MUSIC_PROGRESS=0.65 YuE2 generating acoustic latents', flush=True)
        elif message.startswith('[vae]'):
            print('PIXEL_MUSIC_PROGRESS=0.94 YuE2 decoding', flush=True)
    pipe = Yue2Pipeline(args.model/'bf16', log=log)
    if trained_style is not None:
        style_adapter.apply(pipe.model, trained_style)
    if args.plan_only:
        if options['planning'] == 'off':
            raise ValueError('Score planning requires melody or full mode.')
        from generate import generate_tokens, token_prefix
        style = conditioned_style(request)
        ids, truncated = generate_tokens(pipe.model,
            token_prefix(pipe.tokenizer, style, request['lyrics'].strip(), options['planning']),
            pipe.abc_sampling, request['seed'], 'abc', on_token=pipe._progress('abc'))
        if truncated:
            raise ValueError('Score exceeded the planning budget. Shorten the lyrics.')
        score = pipe.tokenizer.decode(ids)
        if not score.strip():
            raise ValueError('Planning returned an empty score.')
        (artifacts/'score.abc').write_text(score)
        (artifacts/'tokens.json').write_text(json.dumps({'abc': ids}))
        (artifacts/'result.json').write_text(json.dumps({'operation': 'plan', 'request': request,
            'repository': REPOSITORY, 'revision': REVISION, 'precision': 'bf16',
            'adapterSHA256': sha256(__file__), 'modelFiles': hashes,
            'abcSampling': pipe.abc_sampling.__dict__, 'elapsedSeconds': time.monotonic()-started,
            'files': {p.name: sha256(p) for p in artifacts.iterdir() if p.is_file()}}, indent=2))
        return
    duration = request['durationSeconds']
    budget = semantic_budget(options, duration, pipe.semantic_sampling.max_tokens)
    sampling = Sampling(temperature=options['temperature'], top_p=options['topP'],
                        top_k=options['topK'], repetition_penalty=options['repetitionPenalty'],
                        penalty_window=options['penaltyWindow'], min_tokens=min(pipe.semantic_sampling.min_tokens, budget),
                        max_tokens=budget)
    latent_path = artifacts/'audio.latents.npy'
    if options.get('decodeLatentsPath'):
        source = Path(options['decodeLatentsPath'])
        verify_latent(source, options['decodeLatentsSHA256'])
        shutil.copyfile(source, latent_path)
        latent = np.load(latent_path, allow_pickle=False)
        if latent.ndim != 2 or latent.shape[1] != 64 or not 1 <= latent.shape[0] <= 9000 or not np.isfinite(latent).all():
            raise ValueError('Source latents have invalid dimensions or values.')
        audio = pipe.decode(mx.array(latent))
        info = {}
        for name in ('score.abc', 'tokens.json'):
            if (source.parent/name).is_file():
                shutil.copyfile(source.parent/name, artifacts/name)
    else:
        style = conditioned_style(request)
        audio, info = pipe(style, request['lyrics'].strip(), cot=options['planning'],
            seed=request['seed'], abc=options.get('abc', '').strip() or None,
            cfg_scale=options['guidance'], semantic_sampling=sampling, steps=options['steps'],
            on_latents=lambda z: np.save(latent_path, np.array(z)))
        if info.get('abc') is not None:
            (artifacts/'score.abc').write_text(info['abc'])
        (artifacts/'tokens.json').write_text(json.dumps({'codec':info['codec'], 'prefix':info['prefix']}))
    pcm = np.array(audio, dtype=np.float32)
    if pcm.ndim != 2 or pcm.shape[1] != 2 or pcm.shape[0] == 0 or not np.isfinite(pcm).all():
        raise ValueError('YuE2 did not return finite stereo audio.')
    # Write inside the reserved bundle; publish with a link that fails if a master exists.
    staged = artifacts/'render.wav'
    write_wav(staged, audio)
    report = {'repository':REPOSITORY, 'revision':REVISION, 'precision':'bf16',
        'runtime':{name:importlib.metadata.version(name) for name in ('mlx','numpy','tiktoken')},
        'adapterSHA256':sha256(__file__), 'modelFiles':hashes, 'request':request,
        'sampling':sampling.__dict__, 'abcSampling':pipe.abc_sampling.__dict__,
        'elapsedSeconds':time.monotonic()-started, 'durationSeconds':pcm.shape[0]/48000,
        'sampleRate':48000, 'channels':2, 'warnings':warnings,
        'sourceOutputID':options.get('sourceOutputID'),
        'trainedStyle':trained_style, 'trainedStyleApplied':trained_style is not None,
        'sourceScorePath':options.get('sourceScorePath'), 'sourceScoreSHA256':options.get('sourceScoreSHA256'),
        'audioSHA256':sha256(staged),
        'files':{p.name:sha256(p) for p in artifacts.iterdir() if p.is_file() and p != staged}}
    (artifacts/'result.json').write_text(json.dumps(report, indent=2, ensure_ascii=False))
    os.link(staged, out)
    staged.unlink()
    print('PIXEL_MUSIC_PROGRESS=0.98 YuE2 writing WAV and provenance', flush=True)

if __name__ == '__main__':
    main()
