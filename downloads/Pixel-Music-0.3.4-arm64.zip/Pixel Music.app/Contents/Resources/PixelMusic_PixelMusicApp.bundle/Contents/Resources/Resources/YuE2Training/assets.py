"""Pinned safetensors verification and standalone NAR conversion; no pickle."""
import argparse
import hashlib
import json
from pathlib import Path
import mlx.core as mx

REPO='Mothersuperior/yue2-mothersuperior-realaudio-tokenizer-v4'
REVISION='430084f7c8eeeb5fc6947ea31b3f2f25f7602def'
PROFILES={
 'v4': {
  'tokenizer_head_joint_v4.safetensors':'0117394bb7db3dc88e4cb62a5e6e909283e1042240a3678780dcf9396502327e',
  'nar_lora_joint_v4.safetensors':'7c99b788ca1167a1532b35fff2085d8d14549c8eaa87f9eda7ce68c041841fcc'},
 'v9': {
  'tokenizer_head_joint_v9.safetensors':'06440f25605c6c12c4e517ef033d7b70b8d9e961b3b06aa3848b1f8028fd7eb8',
  'nar_lora_joint_v9.safetensors':'585f303da1d5252d228d1e8ac6d4c4d11d970df9297406935cc8bdafa49cfa7e'}
}


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''): h.update(block)
    return h.hexdigest()


def profile_files(variant):
    if variant not in PROFILES: raise ValueError('Unknown asset variant: '+variant)
    return PROFILES[variant]

def verify_assets(root, variant='v4'):
    files=profile_files(variant)
    for name,sha in files.items():
        path=Path(root)/name
        if not path.is_file(): raise ValueError('Missing checkpoint: '+name)
        if sha and digest(path)!=sha: raise ValueError('Checkpoint checksum mismatch: '+name)
    return {'repository':REPO,'revision':REVISION,'variant':variant,'files':files}


def convert_nar_tensors(source, base, layers):
    out={}; consumed=set()
    for i in range(layers):
        for block,names in [('nar_self_attn',('q_proj','k_proj','v_proj','o_proj')),('nar_mlp',('gate_proj','up_proj','down_proj'))]:
            for name in names:
                key=f'layers.{i}.{block}.{name}'
                ak,bk=key+'.lora_A',key+'.lora_B'
                if ak not in source or bk not in source: raise ValueError('Incomplete NAR adapter')
                a,b=source[ak],source[bk]
                target=base['model.'+key+'.weight']
                if a.ndim!=2 or b.ndim!=2 or a.shape[0]<1 or a.shape[0]!=b.shape[1] or (b.shape[0],a.shape[1])!=target.shape:
                    raise ValueError('NAR shape mismatch: '+key)
                out['model.'+key+'.lora_down.weight']=a
                out['model.'+key+'.lora_up.weight']=b
                consumed.update((ak,bk))
    for module in ('vae2llm','llm2vae'):
        for kind,suffix in [('weight','.diff'),('bias','.diff_b')]:
            key=module+'.'+kind
            if key not in source or source[key].shape!=base[key].shape: raise ValueError('Missing/mismatched projection: '+key)
            out[module+suffix]=source[key].astype(mx.float32)-base[key].astype(mx.float32)
            consumed.add(key)
    if consumed!=set(source): raise ValueError('Unexpected NAR checkpoint tensors')
    if not all(bool(mx.all(mx.isfinite(v)).item()) for v in out.values()): raise ValueError('Non-finite checkpoint')
    return out


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--assets',type=Path,required=True)
    p.add_argument('--base',type=Path,required=True,help='BF16 directory')
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--variant',choices=tuple(PROFILES),default='v4')
    a=p.parse_args()
    if a.output.exists(): raise FileExistsError(a.output)
    files=profile_files(a.variant)
    manifest=verify_assets(a.assets,a.variant)
    base=mx.load(str(a.base/'model.safetensors'))
    source=mx.load(str(a.assets/next(name for name in files if name.startswith('nar_lora'))))
    layers=json.loads((a.base/'config.json').read_text())['num_hidden_layers']
    converted=convert_nar_tensors(source,base,layers)
    base_hash=digest(a.base/'model.safetensors')
    source_name=next(name for name in files if name.startswith('nar_lora'))
    mx.save_safetensors(str(a.output),converted,{'format':'fl-yue2-lora-v1','branch':'nar','variant':a.variant,'base_sha256':base_hash,
        'source_sha256':files[source_name],'repository':REPO,'revision':REVISION})
    report={**manifest,'converted_sha256':digest(a.output),'base_sha256':base_hash,'tensor_count':len(converted)}
    a.output.with_suffix('.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))

if __name__=='__main__': main()
