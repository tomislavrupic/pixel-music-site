"""Train a single YuE2 artist adapter: planner CE + decoder flow matching."""
import argparse, hashlib, json, math, random, time
from pathlib import Path
import numpy as np
import mlx.core as mx
import mlx.nn as nn
import mlx.optimizers as optim
from core import ar_loss, apply_adapter
from joint_core import install_joint_lora, joint_loss, export_joint_adapter
from core import ar_loss


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model-source',type=Path,required=True); p.add_argument('--dataset',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True); p.add_argument('--steps',type=int,default=100)
    p.add_argument('--rank-planner',type=int,default=8); p.add_argument('--rank-decoder',type=int,default=8)
    p.add_argument('--planner-learning-rate',type=float,default=3e-5); p.add_argument('--decoder-learning-rate',type=float,default=4e-5)
    p.add_argument('--io-learning-rate',type=float,default=2e-5); p.add_argument('--flow-weight',type=float,default=1.0)
    p.add_argument('--decoder-steps',type=int,default=150,help='Decoder flow updates spread across planner steps')
    p.add_argument('--artist-fraction',type=float,default=0.5); p.add_argument('--kl-weight',type=float,default=0.1)
    p.add_argument('--ema-decay',type=float,default=0.99)
    p.add_argument('--window-frames',type=int,default=128); p.add_argument('--save-every',type=int,default=20); p.add_argument('--seed',type=int,default=7)
    p.add_argument('--resume', type=Path)
    a=p.parse_args()
    if min(a.steps,a.rank_planner,a.rank_decoder,a.window_frames,a.save_every,a.decoder_steps)<1 or a.flow_weight<0 or not 0< a.artist_fraction <=1 or a.kl_weight<0 or not 0<=a.ema_decay<1: p.error('Invalid training settings')
    if not mx.metal.is_available(): p.error('Metal is required')
    data=json.loads(a.dataset.read_text()); rows=[r for r in data.get('artist',[]) if r.get('latents_path')]; regularizer=data.get('regularizer',[])
    if not rows: raise ValueError('Joint training requires prepared VAE latents')
    model_path=a.model_source/'bf16'; cfg=json.loads((model_path/'config.json').read_text())
    base_sha=digest(model_path/'model.safetensors'); comp=data.get('acoustic_companion')
    if not isinstance(comp,dict) or comp.get('base_sha256')!=base_sha or digest(comp['path'])!=comp['sha256']: raise ValueError('Dataset base/companion mismatch')
    if data.get('provenance',{}).get('joint_contract') != 'vae-dilated-v1':
        raise ValueError('Rebuild dataset with the corrected VAE encoder')
    validation = data.get('validation', [])
    heldout = [r for r in validation if r.get('latents_path')]
    if not heldout: raise ValueError('A held-out artist song with VAE latents is required')
    for r in rows + heldout:
        if digest(r['latents_path']) != r.get('latents_sha256'): raise ValueError('VAE latent checksum mismatch: '+r['name'])
        lat = np.load(r['latents_path'], allow_pickle=False)
        if lat.shape != (len(r['ids'])-r['prefix_length']-1, cfg['latent_dim']) or not np.isfinite(lat).all():
            raise ValueError('Invalid or misaligned latents: '+r['name'])
    if a.output.exists(): raise FileExistsError(a.output)
    a.output.mkdir(parents=True)
    settings={k:str(v) if isinstance(v,Path) else v for k,v in vars(a).items()}; settings.update(status='started',dataset_sha256=digest(a.dataset),base_sha256=base_sha,acoustic_companion=comp,protocol='yue2-joint-artist-v1')
    (a.output/'run.json').write_text(json.dumps(settings,indent=2))
    import sys; sys.path.insert(0,str(a.model_source.resolve()))
    from yue2_model import load_model
    base=load_model(model_path); model=load_model(model_path)
    # Training and rendering must start from exactly the same decoder companion.
    apply_adapter(model, comp['path'])
    install_joint_lora(model,a.rank_planner,a.rank_decoder); model.eval(); base.eval()
    from joint_core import JointOptimizers, planner_kl, flow_loss
    from checkpoint import save_resume, load_resume
    from mlx.utils import tree_flatten, tree_unflatten
    rng=random.Random(a.seed); mx.random.seed(a.seed)
    optimizer=JointOptimizers(a.planner_learning_rate,a.decoder_learning_rate,a.io_learning_rate)
    optimizer.ema={k:mx.array(v) for k,v in tree_flatten(model.trainable_parameters())}
    signature={k:v for k,v in settings.items() if k not in ('output','resume','status')}
    first=load_resume(a.resume,model,optimizer,rng,signature) if a.resume else 0
    if first >= a.steps: raise ValueError('Resume already completed')
    start=time.monotonic(); checkpoints=[]; best=None; best_path=None
    def with_ema(action):
        current=dict(tree_flatten(model.trainable_parameters()))
        model.update(tree_unflatten(list(optimizer.ema.items())))
        try: return action()
        finally: model.update(tree_unflatten(list(current.items())))
    def sample(row, start=None, gen=None):
        ids=list(row['ids']); prefix=int(row['prefix_length'])
        lat=np.load(row['latents_path'],allow_pickle=False).astype(np.float32)
        n=min(a.window_frames,len(lat))
        offset=rng.randint(0,len(lat)-n) if start is None else min(start,len(lat)-n)
        lat=lat[offset:offset+n]
        decoder_ids=ids[:prefix]+ids[prefix+offset:prefix+offset+n]+[ids[-1]]
        noise=mx.random.normal(lat.shape) if gen is None else mx.array(gen.standard_normal(lat.shape).astype(np.float32))
        return mx.array(lat),noise,mx.array(decoder_ids)
    def raw_time(sigma):
        # nar_velocity applies the shift internally; invert it so sigma is Beta(2,2).
        shift=cfg.get('timestep_shift',1.0)
        t=sigma/(shift-(shift-1)*sigma)
        return math.log(t/(1-t))
    def planner_loss(m, ids, prefix):
        ce=ar_loss(m,ids,prefix,checkpoint_layers=True)
        return ce + a.kl_weight*planner_kl(m,base,ids,prefix) if a.kl_weight else ce
    planner_step=nn.value_and_grad(model,planner_loss)
    decoder_step=nn.value_and_grad(model,lambda m,l,n,t,ids: a.flow_weight*flow_loss(m,l,n,t,ids))
    def evaluate():
        totals={'artist_ce':[], 'regularizer_ce':[], 'decoder_loss':[]}
        for row in validation:
            loss=ar_loss(model,mx.array([row['ids']]),int(row['prefix_length']))
            key='artist_ce' if row.get('latents_path') else 'regularizer_ce'
            totals[key].append(float(loss.item()))
        gen=np.random.default_rng(831001)
        for row in heldout:
            lat,noise,ids=sample(row,start=max(0,(len(row['ids'])-row['prefix_length']-1-a.window_frames)//2),gen=gen)
            for sigma in (.2,.5,.8):
                totals['decoder_loss'].append(float(flow_loss(model,lat,noise,raw_time(sigma),ids).item()))
        return {k:sum(v)/len(v) for k,v in totals.items() if v}
    baseline=with_ema(evaluate)
    (a.output/'validation-before.json').write_text(json.dumps(baseline,indent=2))
    try:
        for step in range(first+1,a.steps+1):
            use_artist=not regularizer or rng.random()<a.artist_fraction
            row=rng.choice(rows if use_artist else regularizer)
            value,grad=planner_step(model,mx.array([row['ids']]),int(row['prefix_length']))
            mx.eval(value,grad)
            if not math.isfinite(float(value.item())): raise ValueError('Nonfinite planner loss')
            norm=optimizer.update(model,grad,'planner')
            decoder_losses=[]
            # Exact update budget, independent of the planner's artist/regularizer choice.
            for _ in range(step*a.decoder_steps//a.steps-(step-1)*a.decoder_steps//a.steps):
                lat,noise,ids=sample(rng.choice(rows))
                sigma=float(np.clip(rng.betavariate(2,2),.02,.98))
                dv,dg=decoder_step(model,lat,noise,raw_time(sigma),ids); mx.eval(dv,dg)
                if not math.isfinite(float(dv.item())): raise ValueError('Nonfinite decoder loss')
                optimizer.update(model,dg,'decoder'); decoder_losses.append(float(dv.item()))
            decay=min(a.ema_decay,(1+step)/(10+step))
            current=dict(tree_flatten(model.trainable_parameters()))
            optimizer.ema={k:v*decay+current[k]*(1-decay) for k,v in optimizer.ema.items()}; mx.eval(optimizer.ema)
            metric={'step':step,'planner_loss':float(value.item()),'decoder_loss':sum(decoder_losses)/len(decoder_losses) if decoder_losses else None,
                    'decoder_updates':step*a.decoder_steps//a.steps,'group':'artist' if use_artist else 'regularizer','gradient_norm':float(norm.item()),'seconds':time.monotonic()-start}
            print(json.dumps(metric),flush=True)
            with (a.output/'metrics.jsonl').open('a') as f: f.write(json.dumps(metric)+'\n')
            if step%a.save_every==0 or step==a.steps:
                path=(a.output/f'step-{step:06d}.safetensors').resolve()
                meta={'base_sha256':base_sha,'dataset_sha256':settings['dataset_sha256'],'acoustic_companion':json.dumps(comp),'step':step,'rank_planner':a.rank_planner,'rank_decoder':a.rank_decoder,'protocol':'yue2-joint-artist-v2'}
                with_ema(lambda: export_joint_adapter(model,path,meta))
                path.with_suffix('.sha256').write_text(digest(path)+'\n'); checkpoints.append(str(path))
                scores=with_ema(evaluate)
                (a.output/f'validation-step-{step:06d}.json').write_text(json.dumps(scores,indent=2))
                score=sum(scores[k]/max(baseline[k],1e-8) for k in scores)
                if best is None or score<best: best=score; best_path=str(path)
                (a.output/'selection.json').write_text(json.dumps({'best_checkpoint':best_path,'checkpoints':checkpoints,'criterion':'held-out normalized artist CE + regularizer CE + decoder loss','score':best},indent=2))
                save_resume(a.output/f'resume-{step:06d}',model,optimizer,rng,step,signature)
        settings.update(status='completed',planner_updates=a.steps,decoder_updates=a.decoder_steps)
    except BaseException as error:
        settings.update(status='failed',error=str(error))
        raise
    finally:
        (a.output/'run.json').write_text(json.dumps(settings,indent=2))

if __name__=='__main__': main()
