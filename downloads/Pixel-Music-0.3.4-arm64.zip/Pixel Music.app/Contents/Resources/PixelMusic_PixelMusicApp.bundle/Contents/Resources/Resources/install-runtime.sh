#!/bin/zsh
set -euo pipefail

runtime_dir="$1"
model_dir="$2"
merge_commit="784b29e2691a93ca7483147d86f61859dfaa6296"
export HF_HUB_DISABLE_XET="${HF_HUB_DISABLE_XET:-1}"

echo "PIXEL_MUSIC_PROGRESS=0.05"
echo "PIXEL_MUSIC_STATUS=Creating isolated Python runtime"
python_bootstrap=""
for candidate in \
  /opt/homebrew/bin/python3 \
  /opt/homebrew/opt/python@3.14/bin/python3.14 \
  /opt/homebrew/opt/python@3.13/bin/python3.13 \
  /opt/homebrew/opt/python@3.12/bin/python3.12 \
  /opt/homebrew/opt/python@3.11/bin/python3.11 \
  /usr/local/bin/python3 \
  /usr/bin/python3
do
  if [[ -x "$candidate" ]] && "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)' 2>/dev/null; then
    python_bootstrap="$candidate"
    break
  fi
done

if [[ -z "$python_bootstrap" ]]; then
  echo "Python 3.10 or newer is required. Install Python with Homebrew and try again." >&2
  exit 65
fi

"$python_bootstrap" -m venv "$runtime_dir"

echo "PIXEL_MUSIC_PROGRESS=0.15"
echo "PIXEL_MUSIC_STATUS=Installing pinned MLX-Audio"
"$runtime_dir/bin/python" -m pip install --upgrade pip
"$runtime_dir/bin/python" -m pip install "mlx-audio @ git+https://github.com/Blaizzy/mlx-audio.git@$merge_commit" "huggingface_hub[hf_xet]"

echo "PIXEL_MUSIC_PROGRESS=0.35"
echo "PIXEL_MUSIC_STATUS=Downloading MiniMax Music 3 MXFP8"
mkdir -p "$model_dir"
"$runtime_dir/bin/python" - "$model_dir" <<'PY'
from datetime import datetime, timezone
from huggingface_hub import HfApi, snapshot_download
import json
from pathlib import Path
import sys

repository = "mlx-community/MiniMax-Music3-mxfp8"
model_dir = Path(sys.argv[1])
revision = HfApi().model_info(repository).sha
snapshot_download(repo_id=repository, revision=revision, local_dir=model_dir)
index_path = model_dir / "model.safetensors.index.json"
index = json.loads(index_path.read_text(encoding="utf-8"))
weight_files = sorted(set(index.get("weight_map", {}).values()))
missing = [name for name in weight_files if not (model_dir / name).is_file() or (model_dir / name).stat().st_size == 0]
if not weight_files or missing:
    raise SystemExit("Incomplete MiniMax model weights: " + ", ".join(missing or ["empty weight map"]))
lock = {
    "repository": repository,
    "revision": revision,
    "downloadedAt": datetime.now(timezone.utc).isoformat(),
}
(model_dir / ".pixel-music-model-lock.json").write_text(
    json.dumps(lock, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)
PY

echo "PIXEL_MUSIC_PROGRESS=0.96"
echo "PIXEL_MUSIC_STATUS=Verifying runtime and model"
"$runtime_dir/bin/python" -c 'from mlx_audio.music import load; import sys; load(sys.argv[1]); print("verified")' "$model_dir"

echo "PIXEL_MUSIC_PROGRESS=1.0"
echo "PIXEL_MUSIC_STATUS=Runtime and model verified"
