"""Local real-audio -> MERT20 -> pinned real-audio tokens -> reviewed dataset."""
import argparse
import json
import math
import sys
import time
from pathlib import Path
import numpy as np
from assets import digest, verify_assets


def interpolate_frames(features, frames):
    if features.ndim!=2 or len(features)<1 or frames<1:raise ValueError('Empty features')
    position=np.clip((np.arange(frames)+.5)*len(features)/frames-.5,0,len(features)-1)
    lo=np.floor(position).astype(int);hi=np.minimum(lo+1,len(features)-1)
    alpha=(position-lo)[:,None]
    return (features[lo]*(1-alpha)+features[hi]*alpha).astype(np.float32)


def make_row(name,prefix,codec,limit):
    c=np.asarray(codec)
    if c.ndim!=1 or not len(c) or c.dtype.kind not in 'iu' or np.any(c<0) or np.any(c>=32768):raise ValueError('Invalid codec')
    ids=list(prefix)+[int(t)+151853 for t in c]+[151852]
    if len(ids)>limit:raise ValueError(f'{name}: {len(ids)} tokens exceeds limit {limit}; no automatic truncation')
    return {'name':name,'ids':ids,'prefix_length':len(prefix)}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('manifest','output','model-source','mert','assets','regularizer'):
        p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--vae',type=Path)
    p.add_argument('--variant',choices=('v4','v9'),default='v4')
    p.add_argument('--sequence-limit',type=int,default=4096)
    p.add_argument('--regularizer-count',type=int,default=64)
    a=p.parse_args()
    if not 1<=a.sequence_limit<=24576 or a.regularizer_count<1:p.error('Invalid sequence/count')
    if a.output.exists():raise FileExistsError(a.output)
    manifest=json.loads(a.manifest.read_text())
    songs=manifest['songs']
    if not songs or not all(s.get('reviewed') is True for s in songs):raise ValueError('Each song needs reviewed caption/lyrics')
    roles={s.get('role','artist') for s in songs}
    if roles-{'artist','validation'} or 'artist' not in roles:raise ValueError('Expected artist and optional validation songs')
    source_hashes=[digest(Path(s['audio'])) for s in songs]
    if len(set(source_hashes))!=len(source_hashes):raise ValueError('Duplicate audio across dataset roles')
    for s,sha in zip(songs,source_hashes):
        if s.get('sha256') and s['sha256']!=sha:raise ValueError('Source master checksum mismatch')
    provenance=verify_assets(a.assets,a.variant)
    sys.path.insert(0,str(a.model_source.resolve()))
    from generate import Tokenizer,token_prefix
    import mlx.core as mx
    import soundfile as sf
    from scipy.signal import resample_poly
    from mert import MERT2MLX
    from token_head import from_torch_arrays,predict
    if a.vae:
        from vae_encoder import VAEEncoder
    if not mx.metal.is_available():raise ValueError('Metal required')
    tokenizer=Tokenizer(a.model_source/'bf16/qwen.tiktoken')
    companion=a.assets/f'nar-{a.variant}-mlx.safetensors'
    _,meta=mx.load(str(companion),return_metadata=True)
    base_sha=digest(a.model_source/'bf16/model.safetensors')
    if meta.get('base_sha256')!=base_sha:raise ValueError('Acoustic companion base mismatch')
    a.output.mkdir(parents=True,exist_ok=False)
    mert=MERT2MLX(a.mert)
    vae=VAEEncoder(a.vae) if a.vae else None
    head=from_torch_arrays(mx.load(str(a.assets/f'tokenizer_head_joint_{a.variant}.safetensors')))
    result={'artist':[],'regularizer':[],'validation':[],'provenance':{'assets':provenance,
        'mert_weights_sha256':digest(a.mert/'model.safetensors'),'manifest_sha256':digest(a.manifest),
        'base_sha256':base_sha,'purpose':manifest.get('purpose','user supplied dataset'),'feature_contract':'30s chunks, tails under1s omitted, linear resize25Hz, fp16 roundtrip, track instance norm',
        'mert_source_sha256':digest(Path(__file__).with_name('mert.py'))},
        'acoustic_companion':{'path':str(companion.resolve()),'sha256':digest(companion),'base_sha256':base_sha}}
    if vae is not None:
        result['provenance'].update(joint_contract='vae-dilated-v1', vae_weights_sha256=digest(a.vae/'model.safetensors'), vae_source_sha256=digest(Path(__file__).with_name('vae_encoder.py')))
    for song,sha in zip(songs,source_hashes):
        begin=time.monotonic();audio,sr=sf.read(song['audio'],dtype='float32',always_2d=True)
        if not np.isfinite(audio).all() or not len(audio) or np.max(np.abs(audio))<1e-7:raise ValueError('Invalid/silent audio')
        g=math.gcd(sr,24000);mono=resample_poly(audio.mean(1),24000//g,sr//g).astype(np.float32)
        if len(mono)<24000:raise ValueError('Audio must be at least one second')
        # Match Mothersuperior preprocessing, including tail discard + final interpolation.
        parts=[]
        for start in range(0,len(mono),720000):
            chunk=mono[start:start+720000]
            if len(chunk)>=24000:parts.append(np.array(mert.encode(chunk,layer=20)[0]))
        features=interpolate_frames(np.concatenate(parts),round(len(mono)/24000*25)).astype(np.float16).astype(np.float32)
        codec=predict(head,features)
        prefix=token_prefix(tokenizer,song['style'],song['lyrics'],'off')
        row=make_row(song['name'],prefix,codec,a.sequence_limit)
        row.update(source_project_id=song.get('source_project_id'),audio=str(Path(song['audio']).resolve()),audio_sha256=sha,style=song['style'],lyrics=song['lyrics'],duration_seconds=len(audio)/sr)
        folder=a.output/sha;folder.mkdir()
        np.save(folder/'features.npy',features);np.save(folder/'codec.npy',codec)
        row['codec_path']=str((folder/'codec.npy').resolve());row['codec_sha256']=digest(folder/'codec.npy')
        if vae is not None:
            stereo=resample_poly(audio,48000//math.gcd(sr,48000),sr//math.gcd(sr,48000),axis=0).astype(np.float32)
            latents=np.asarray(vae.encode(stereo))
            if len(codec) != len(latents):
                raise ValueError(f'{song["name"]}: codec/latent frame alignment mismatch; no automatic truncation')
            np.save(folder/'latents.npy',latents)
            row['latents_path']=str((folder/'latents.npy').resolve());row['latents_sha256']=digest(folder/'latents.npy')
        result[song.get('role','artist')].append(row)
        print(json.dumps({'song':song['name'],'frames':len(codec),'seconds':time.monotonic()-begin}),flush=True)
    regularizer=json.loads(a.regularizer.read_text())
    selected={'minted':0,'minted_val':0}
    for r in regularizer:
        role=r['src']
        if role not in selected or selected[role]>=a.regularizer_count:continue
        prefix=token_prefix(tokenizer,r['style'],r['lyrics'],'off')
        if len(prefix)+len(r['codec'])+1>a.sequence_limit:continue
        row=make_row(r['name'],prefix,r['codec'],a.sequence_limit)
        row['source']='minted_regularizer'
        result['regularizer' if role=='minted' else 'validation'].append(row);selected[role]+=1
    if selected['minted']==0 or selected['minted_val']==0:raise ValueError('No fitting train/validation regularizer songs')
    result['provenance']['regularizer_sha256']=digest(a.regularizer)
    result['provenance']['regularizer_selection']={'counts':selected,'policy':'first complete songs fitting explicit sequence limit; no truncation'}
    (a.output/'dataset.json').write_text(json.dumps(result))
    print('Dataset:',a.output/'dataset.json',flush=True)

if __name__=='__main__':main()
