"""MLX inference for Mothersuperior v4's PyTorch TransformerEncoder head.
Checkpoint conversion is explicit; no pickle is loaded by this module.
"""
import mlx.core as mx
import mlx.nn as nn
import numpy as np


class Block(nn.Module):
    def __init__(self, width, heads):
        super().__init__()
        self.heads = heads
        self.qkv = nn.Linear(width, 3*width)
        self.out = nn.Linear(width, width)
        self.norm1 = nn.LayerNorm(width, eps=1e-5)
        self.norm2 = nn.LayerNorm(width, eps=1e-5)
        self.linear1 = nn.Linear(width, 4*width)
        self.linear2 = nn.Linear(4*width, width)

    def __call__(self, x):
        b, t, w = x.shape
        q, k, v = mx.split(self.qkv(self.norm1(x)), 3, axis=-1)
        q, k, v = [a.reshape(b,t,self.heads,w//self.heads).transpose(0,2,1,3) for a in (q,k,v)]
        att = mx.fast.scaled_dot_product_attention(q,k,v,scale=(w//self.heads)**-0.5)
        x = x + self.out(att.transpose(0,2,1,3).reshape(b,t,w))
        return x + self.linear2(nn.gelu(self.linear1(self.norm2(x))))


class TokenHead(nn.Module):
    def __init__(self, width=512, layers=8, heads=8, window=512, input_dim=1024, vocab=32768):
        super().__init__()
        self.inp = nn.Linear(input_dim, width)
        self.pos = mx.zeros((1,window,width))
        self.layers = [Block(width,heads) for _ in range(layers)]
        self.norm = nn.LayerNorm(width,eps=1e-5)
        self.head = nn.Linear(width,vocab)

    def __call__(self, x):
        x = self.inp(x) + self.pos[:,:x.shape[1]]
        for layer in self.layers:
            x = layer(x)
        return self.head(self.norm(x))


def from_torch_arrays(state, **config):
    model = TokenHead(**config)
    mapped = {}
    for key, value in state.items():
        key = key.replace('enc.layers.', 'layers.')
        key = key.replace('self_attn.in_proj_weight', 'qkv.weight').replace('self_attn.in_proj_bias','qkv.bias')
        key = key.replace('self_attn.out_proj.', 'out.')
        mapped[key] = mx.array(value)
    model.load_weights(list(mapped.items()), strict=True)
    model.eval()
    return model


def predict(head, features):
    features = np.asarray(features, dtype=np.float32)
    if features.ndim != 2 or len(features) == 0 or not np.isfinite(features).all():
        raise ValueError('Expected nonempty finite feature matrix')
    features = (features-features.mean(0))/(features.std(0)+1e-5)
    total, window = len(features), head.pos.shape[1]
    out = np.zeros(total,dtype=np.int32)
    starts = list(range(0,max(1,total-window+1),window//2))
    if starts[-1]+window < total:
        starts.append(max(0,total-window))
    for start in starts:
        value = features[start:start+window]
        count = len(value)
        value = np.pad(value,((0,window-count),(0,0)))
        ids = np.array(mx.argmax(head(mx.array(value[None]))[0,:count],axis=-1))
        lo = start+(0 if start==0 else window//4)
        hi = start+count-(0 if start+count>=total else window//4)
        out[lo:hi] = ids[lo-start:hi-start]
    return out
