"""Experimental MLX AR LoRA training for the pinned YuE2 MLX backbone.

Algorithm adapted from filliptm/ComfyUI-FL-YuE2 (Apache-2.0),
revision 16d0c0f. See LICENSE-UPSTREAM and README.md.
"""
import math
from pathlib import Path
import mlx.core as mx
import mlx.nn as nn
from mlx.utils import tree_flatten


def targets(model, branch='ar'):
    if branch not in ('ar', 'nar'):
        raise ValueError('Unknown adapter branch')
    for i in range(len(model.model.layers)):
        for module, names in (('self_attn', ('q_proj', 'k_proj', 'v_proj', 'o_proj')),
                              ('mlp', ('gate_proj', 'up_proj', 'down_proj'))):
            for name in names:
                yield f'model.layers.{i}.{"nar_" if branch == "nar" else ""}{module}.{name}'


def module_at(model, path):
    for part in path.split('.'):
        model = model[int(part)] if part.isdecimal() else getattr(model, part)
    return model


class LoRALinear(nn.Module):
    def __init__(self, base, rank):
        super().__init__()
        if rank < 1 or not isinstance(base, nn.Linear):
            raise ValueError('Positive rank and unquantized linear layer required')
        self.base = base
        self.A = mx.random.normal((rank, base.weight.shape[1])) / math.sqrt(base.weight.shape[1])
        self.B = mx.zeros((base.weight.shape[0], rank))
        self.base.freeze()

    def __call__(self, x):
        return self.base(x) + ((x.astype(mx.float32) @ self.A.T) @ self.B.T).astype(x.dtype)


def install_lora(model, rank, branch='ar'):
    keys = list(targets(model, branch))
    if any(not isinstance(module_at(model, key), nn.Linear) for key in keys):
        raise ValueError('Model already adapted or quantized')
    # Freeze the base once. A second call installs the NAR branch without
    # freezing the planner adapters already attached to the model.
    if not any(isinstance(module_at(model, key), LoRALinear) for key in targets(model, 'ar')):
        model.freeze()
    for key in keys:
        parent, name = key.rsplit('.', 1)
        setattr(module_at(model, parent), name, LoRALinear(module_at(model, key), rank))


def hidden(model, ids, checkpoint_layers=False):
    x = model.model.embed_tokens(ids)
    for layer in model.model.layers:
        # No mutable KV caches in the differentiated training graph.
        if checkpoint_layers:
            def forward(parameters, value, layer=layer):
                layer.update(parameters)
                return layer.ar_prefill_kv(value)[0]
            x = mx.checkpoint(forward)(layer.trainable_parameters(), x)
        else:
            x, _ = layer.ar_prefill_kv(x)
    return model.model.norm(x)


def ar_loss(model, ids, prefix_length, checkpoint_layers=False):
    if ids.ndim != 2 or ids.shape[0] != 1 or not 1 <= prefix_length < ids.shape[1]:
        raise ValueError('Expected one sequence with nonempty prefix and targets')
    h = hidden(model, ids, checkpoint_layers)[0, prefix_length - 1:-1]
    labels = ids[0, prefix_length:]
    total = mx.array(0.0)
    for start in range(0, labels.size, 256):
        def ce(value, target):
            logits = model.lm_head(value).astype(mx.float32)
            return nn.losses.cross_entropy(logits, target, reduction='sum')
        total = total + (mx.checkpoint(ce) if checkpoint_layers else ce)(h[start:start + 256], labels[start:start + 256])
    return total / labels.size


def export_adapter(model, path, metadata=None):
    path = Path(path)
    if path.exists():
        raise FileExistsError(path)
    values = {}
    for key in targets(model):
        layer = module_at(model, key)
        values[key + '.lora_down.weight'] = layer.A
        values[key + '.lora_up.weight'] = layer.B
    meta = {**(metadata or {}), 'format': 'fl-yue2-lora-v1', 'branch': 'ar'}
    mx.save_safetensors(str(path), values, {k: str(v) for k, v in meta.items()})


def apply_adapter(model, path, strength=1.0):
    """Validate everything first, then merge into this in-memory model only."""
    if not math.isfinite(strength):
        raise ValueError('Non-finite strength')
    values, meta = mx.load(str(path), return_metadata=True)
    branch = meta.get('branch')
    if meta.get('format') != 'fl-yue2-lora-v1' or branch not in ('ar', 'nar', 'joint'):
        raise ValueError('Not an FL YuE2 adapter')
    branches = ('ar', 'nar') if branch == 'joint' else (branch,)
    keys = [k for b in branches for k in targets(model, b)]
    if 'nar' in branches:
        keys += ['vae2llm', 'llm2vae']
    allowed = {k+s for k in keys for s in ('.lora_down.weight', '.lora_up.weight', '.alpha', '.diff', '.diff_b')}
    if not values or set(values) - allowed:
        raise ValueError('Empty or unsupported adapter tensors')
    state = dict(tree_flatten(model.parameters()))
    updates = {}
    for key in keys:
        a, b = values.get(key+'.lora_down.weight'), values.get(key+'.lora_up.weight')
        if (a is None) != (b is None):
            raise ValueError('Incomplete pair: '+key)
        if a is not None:
            weight = state[key+'.weight']
            if a.ndim != 2 or b.ndim != 2 or a.shape[0] < 1 or a.shape[0] != b.shape[1] or (b.shape[0], a.shape[1]) != weight.shape:
                raise ValueError('Shape mismatch: '+key)
            alpha = values.get(key+'.alpha')
            if alpha is not None and alpha.size != 1:
                raise ValueError('Alpha must be scalar')
            scale = float(alpha.item()) / a.shape[0] if alpha is not None else 1.0
            updates[key+'.weight'] = weight.astype(mx.float32) + strength * scale * (b.astype(mx.float32) @ a.astype(mx.float32))
        elif key+'.alpha' in values:
            raise ValueError('Alpha without pair')
        for suffix, param in (('.diff', '.weight'), ('.diff_b', '.bias')):
            if key+suffix in values:
                original = state.get(key+param)
                delta = values[key+suffix]
                if original is None or delta.shape != original.shape:
                    raise ValueError('Projection shape mismatch: '+key)
                updates[key+param] = updates.get(key+param, original.astype(mx.float32)) + strength*delta
    if not updates or not all(bool(mx.all(mx.isfinite(v)).item()) for v in updates.values()):
        raise ValueError('No applicable tensors or non-finite adapter')
    model.load_weights([(k, v.astype(state[k].dtype)) for k, v in updates.items()], strict=False)
    mx.eval(model.parameters())
    return meta
