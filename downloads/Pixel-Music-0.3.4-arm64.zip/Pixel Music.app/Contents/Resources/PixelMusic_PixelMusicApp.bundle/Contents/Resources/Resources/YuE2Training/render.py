"""Explicit opt-in listening render with pinned acoustic companion and optional AR style."""
import argparse
import dataclasses
import json
import math
import sys
import time
from pathlib import Path
import numpy as np
from assets import digest
from core import apply_adapter


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model-source',type=Path,required=True)
    p.add_argument('--dataset',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--adapter',type=Path)
    p.add_argument('--strength',type=float,default=1.0)
    p.add_argument('--style',required=True)
    p.add_argument('--lyrics',default='[instrumental]')
    p.add_argument('--seed',type=int,default=831001)
    p.add_argument('--seconds',type=int,default=30)
    p.add_argument('--steps',type=int,default=32)
    p.add_argument('--codec',type=Path,help='Reconstruct prepared real audio tokens instead of generating new tokens')
    a=p.parse_args()
    if not 1<=a.seconds<=360 or not 1<=a.steps<=128 or not math.isfinite(a.strength):p.error('Invalid render settings')
    if a.output.exists():raise FileExistsError(a.output)
    data=json.loads(a.dataset.read_text());comp=data['acoustic_companion'];base=a.model_source/'bf16'
    if digest(comp['path'])!=comp['sha256'] or digest(base/'model.safetensors')!=comp['base_sha256']:raise ValueError('Model/companion integrity mismatch')
    sys.path.insert(0,str(a.model_source.resolve()))
    import mlx.core as mx
    import soundfile as sf
    from generate import Yue2Pipeline,token_prefix,synthesize
    if a.adapter:
        _,meta=mx.load(str(a.adapter),return_metadata=True)
        if meta.get('base_sha256')!=comp['base_sha256'] or meta.get('dataset_sha256')!=digest(a.dataset):raise ValueError('AR adapter base/dataset mismatch')
        if json.loads(meta['acoustic_companion'])!=comp:raise ValueError('AR/NAR companion mismatch')
    a.output.mkdir(parents=True,exist_ok=False)
    settings={k:str(v) if isinstance(v,Path) else v for k,v in vars(a).items()}
    settings.update(base_sha256=comp['base_sha256'],acoustic_companion=comp,dataset_sha256=digest(a.dataset),
                    toolkit_sha256={p.name:digest(p) for p in Path(__file__).parent.glob('*.py')},adapter_sha256=digest(a.adapter) if a.adapter else None,runtime='mlx',runtime_version=mx.__version__,status='started')
    (a.output/'recipe.json').write_text(json.dumps(settings,indent=2))
    start=time.monotonic()
    try:
        pipe=Yue2Pipeline(base,log=lambda s:print(s,flush=True))
        apply_adapter(pipe.model,comp['path'])
        if a.adapter:apply_adapter(pipe.model,a.adapter,a.strength)
        if a.codec:
            codec=np.load(a.codec,allow_pickle=False)
            if codec.ndim!=1 or not len(codec) or codec.dtype.kind not in 'iu' or np.any(codec<0) or np.any(codec>=32768):raise ValueError('Invalid codec')
            original_frames=len(codec);codec=codec[:a.seconds*25].tolist()
            prefix=token_prefix(pipe.tokenizer,a.style,a.lyrics,'off')
            latent=synthesize(pipe.model,prefix,codec,a.seed,a.steps)
            audio=pipe.decode(latent);info={'codec':codec,'prefix':prefix}
            settings['source_codec_sha256']=digest(a.codec);settings['source_frames']=original_frames
        else:
            sampling=dataclasses.replace(pipe.semantic_sampling,max_tokens=a.seconds*25,min_tokens=min(200,a.seconds*25))
            audio,info=pipe(a.style,a.lyrics,cot='off',seed=a.seed,semantic_sampling=sampling,steps=a.steps)
        audio=np.array(audio,dtype=np.float32)
        if audio.ndim!=2 or audio.shape[1]!=2 or not len(audio) or not np.isfinite(audio).all():raise ValueError('Invalid waveform')
        rms=float(np.sqrt(np.mean(audio.astype(np.float64)**2)))
        if rms<1e-7:raise ValueError('Silent waveform')
        sf.write(a.output/'audio.wav',audio,48000,subtype='PCM_24')
        (a.output/'tokens.json').write_text(json.dumps({'codec':info['codec'],'prefix':info['prefix']}))
        settings.update(status='completed',elapsed_seconds=time.monotonic()-start,duration_seconds=len(audio)/48000,
            peak=float(np.max(abs(audio))),rms=rms,clipped_fraction=float(np.mean(abs(audio)>=.9999)),
            audio_sha256=digest(a.output/'audio.wav'),frames=len(info['codec']),
            hit_duration_cap=len(info['codec'])>=a.seconds*25,peak_memory_bytes=mx.get_peak_memory(),listening_accepted=False)
    except BaseException:
        settings['status']='failed';raise
    finally:
        (a.output/'recipe.json').write_text(json.dumps(settings,indent=2))
    print(json.dumps(settings,indent=2),flush=True)

if __name__=='__main__':main()
