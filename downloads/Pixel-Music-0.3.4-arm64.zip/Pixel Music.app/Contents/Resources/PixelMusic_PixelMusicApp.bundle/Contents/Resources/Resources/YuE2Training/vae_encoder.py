"""MLX encoder for the released YuE2 Oobleck VAE.

The generation bundle only needs the decoder. Artist training needs the other
half: real recordings -> 64-channel VAE latents at 25 frames/s. This module
loads the official full VAE checkpoint and folds PyTorch weight-norm tensors
without importing Torch.
"""
import json
from pathlib import Path
import mlx.core as mx
import numpy as np


class VAEEncoder:
    def __init__(self, root):
        root = Path(root)
        self.config = json.loads((root / 'config.json').read_text())
        self.weights = mx.load(str(root / 'model.safetensors'))
        self.ec = self.config['encoder_config']
        if self.config.get('sample_rate') != 48000 or self.config.get('downsampling_ratio') != 1920:
            raise ValueError('Expected the released 48 kHz YuE2 VAE')
        self.weights = {k: mx.stop_gradient(v) for k, v in self.weights.items() if k.startswith('encoder.')}

    def _weight(self, key):
        v = self.weights[key + '.weight_v']
        g = self.weights[key + '.weight_g']
        # torch weight_norm normalizes over all non-output dimensions.
        denom = mx.sqrt(mx.sum(v * v, axis=(1, 2), keepdims=True) + 1e-12)
        return (v * (g / denom)).transpose(0, 2, 1)

    def _conv(self, x, key, stride=1, padding=0, dilation=1):
        y = mx.conv1d(x, self._weight(key), stride=stride, padding=padding, dilation=dilation)
        bias = self.weights.get(key + '.bias')
        return y + bias if bias is not None else y

    def _snake(self, x, key):
        alpha = self.weights[key + '.alpha']; beta = self.weights[key + '.beta']
        a = mx.exp(alpha)[None, None, :]; b = mx.exp(beta)[None, None, :]
        return x + mx.sin(x * a) ** 2 / (b + 1e-9)

    def _residual(self, x, key, dilation):
        y = self._snake(x, key + '.layers.0')
        y = self._conv(y, key + '.layers.1', padding=3*dilation, dilation=dilation)
        y = self._snake(y, key + '.layers.2')
        y = self._conv(y, key + '.layers.3')
        return x + y

    def encode(self, audio):
        """Return [frames, 64] float32 latents from [samples, 2] audio."""
        x = mx.array(audio, dtype=mx.float32)
        if x.ndim == 1: x = mx.stack([x, x], axis=-1)
        if x.ndim != 2 or x.shape[1] != 2 or x.shape[0] < 1920:
            raise ValueError('Expected stereo audio with at least one latent frame')
        if not bool(mx.all(mx.isfinite(x)).item()): raise ValueError('Audio contains non-finite samples')
        x = x[None]
        x = self._conv(x, 'encoder.layers.0', padding=3)
        strides = self.ec['strides']
        for i, stride in enumerate(strides):
            key = f'encoder.layers.{i + 1}'
            for j in range(3): x = self._residual(x, key + f'.layers.{j}', (1, 3, 9)[j])
            x = self._snake(x, key + '.layers.3')
            x = self._conv(x, key + '.layers.4', stride=stride, padding=(stride + 1) // 2)
        x = self._snake(x, 'encoder.layers.7')
        x = self._conv(x, 'encoder.layers.8', padding=1)
        # The encoder emits mean and log-scale; YuE2 uses the deterministic
        # mean for training targets and the first 64 channels are the latent.
        x = x[0]
        if x.shape[-1] != 128: raise ValueError('Unexpected YuE2 VAE encoder width')
        return x[:, :64].astype(mx.float32)


def encode_file(root, audio, sample_rate):
    import soundfile as sf
    from scipy.signal import resample_poly
    wave = np.asarray(audio, dtype=np.float32)
    if wave.ndim == 1: wave = np.stack([wave, wave], axis=-1)
    if sample_rate != 48000:
        g = np.gcd(sample_rate, 48000)
        wave = resample_poly(wave, 48000 // g, sample_rate // g, axis=0).astype(np.float32)
    return VAEEncoder(root).encode(wave)
