"""Immutable optimizer/RNG checkpoints; never executes serialized Python."""
import json
from pathlib import Path
import mlx.core as mx
from mlx.utils import tree_flatten,tree_unflatten
from assets import digest


def save_resume(path,model,optimizer,rng,step,signature):
    path=Path(path);path.mkdir(parents=True,exist_ok=False)
    arrays={'model.'+k:v for k,v in tree_flatten(model.trainable_parameters())}
    arrays.update({'optimizer.'+k:v for k,v in tree_flatten(optimizer.state)})
    arrays.update({f'random.{i}':v for i,v in enumerate(mx.random.state)})
    mx.save_safetensors(str(path/'state.safetensors'),arrays)
    (path/'state.json').write_text(json.dumps({'step':step,'signature':signature,'python_rng':rng.getstate(),
        'sha256':digest(path/'state.safetensors')}))


def load_resume(path,model,optimizer,rng,signature):
    path=Path(path);meta=json.loads((path/'state.json').read_text())
    if meta['signature']!=signature or meta['sha256']!=digest(path/'state.safetensors'):raise ValueError('Resume signature/checksum mismatch')
    values=mx.load(str(path/'state.safetensors'))
    state={k[6:]:v for k,v in values.items() if k.startswith('model.')}
    expected=dict(tree_flatten(model.trainable_parameters()))
    if set(state)!=set(expected) or any(state[k].shape!=v.shape for k,v in expected.items()):raise ValueError('Resume adapter mismatch')
    if not all(bool(mx.all(mx.isfinite(v)).item()) for v in values.values()):raise ValueError('Nonfinite resume state')
    model.update(tree_unflatten(list(state.items())))
    optimizer.state=tree_unflatten([(k[10:],v) for k,v in values.items() if k.startswith('optimizer.')])
    mx.random.state=[values[f'random.{i}'] for i in range(len(mx.random.state))]
    py=meta['python_rng'];rng.setstate((py[0],tuple(py[1]),py[2]))
    return meta['step']
