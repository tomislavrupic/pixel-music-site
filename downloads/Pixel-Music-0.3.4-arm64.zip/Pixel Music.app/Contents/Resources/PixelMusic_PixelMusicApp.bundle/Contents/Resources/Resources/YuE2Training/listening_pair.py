"""Create equal-loudness audition copies; never alter generated masters."""
import argparse,json,subprocess
from pathlib import Path
from assets import digest
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--baseline',type=Path,required=True);p.add_argument('--adapted',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
report={'purpose':'level-matched listening copies; subjective acceptance pending','target_lufs':-20,'files':[]}
for label,source in [('baseline',a.baseline),('adapted',a.adapted)]:
    first=subprocess.run(['ffmpeg','-nostdin','-v','info','-i',str(source),'-af','loudnorm=I=-20:TP=-1:LRA=11:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
    m=json.JSONDecoder().raw_decode(first.stderr[first.stderr.rfind('{'):])[0]
    filt=f"loudnorm=I=-20:TP=-1:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true:print_format=json"
    output=a.output/(label+'.wav')
    result=subprocess.run(['ffmpeg','-nostdin','-v','info','-n','-i',str(source),'-af',filt,'-ar','48000','-c:a','pcm_s24le',str(output)],capture_output=True,text=True,check=True)
    stats=json.JSONDecoder().raw_decode(result.stderr[result.stderr.rfind('{'):])[0]
    report['files'].append({'label':label,'source':str(source.resolve()),'source_sha256':digest(source),'output':str(output.resolve()),'output_sha256':digest(output),'filter':filt,'stats':stats})
(a.output/'comparison.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
