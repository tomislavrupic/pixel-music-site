#!/usr/bin/env python3
"""Pinned local CPU transcription. No model loading at import."""
import argparse,hashlib,json,time
from pathlib import Path

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--request',type=Path,required=True)
    a=p.parse_args(); request=json.loads(a.request.read_text())
    out=a.request.parent/'transcription'
    out.mkdir(exist_ok=False)
    lock=json.loads((a.root/'installed.json').read_text())
    expected=[['m-a-p/SheetSage2','eab522a8168e8b8b8c4856bf8609cd86198f01fe','SheetSage2'],['m-a-p/MERT-v2-FullSong','d8ba1c745e733b3908ce6ad16ebeb17ac7600a42','MERT2']]
    if lock['models'] != expected: raise ValueError('Song cover model revision mismatch')
    required={'SheetSage2/config.json','SheetSage2/model.safetensors','MERT2/config.json','MERT2/model.safetensors'}
    if not required.issubset(lock['files']):raise ValueError('Incomplete transcription model manifest')
    for name,digest in lock['files'].items():
        if '..' in Path(name).parts or Path(name).is_absolute() or sha(a.root/name)!=digest:
            raise ValueError('Song cover model files changed: '+name)
    source=Path(request['source'])
    source_hash=sha(source)
    import torch
    from transformers import AutoModel
    torch.set_num_threads(min(8,torch.get_num_threads()))
    started=time.monotonic()
    model=AutoModel.from_pretrained(str(a.root/'SheetSage2'),base_model_path=str(a.root/'MERT2'),
        trust_remote_code=True,local_files_only=True,torch_dtype=torch.float32).eval().to('cpu')
    result=model.transcribe(source,output_dir=out,melody_only=True,dtype='fp32',preset='default')
    if result.get('abc_error') or not result.get('abc'):raise ValueError('No usable melody score was produced')
    if sha(source)!=source_hash:raise ValueError('Source recording changed during transcription')
    score=out/'score.abc'
    if not score.is_file():raise ValueError('Transcription did not save its score')
    (out/'pixel-provenance.json').write_text(json.dumps({'request':request,'sourceSHA256':source_hash,
        'models':expected,'modelFiles':lock['files'],'adapterSHA256':sha(__file__),
        'device':'cpu','precision':'fp32','elapsedSeconds':time.monotonic()-started,
        'scoreSHA256':sha(score),'warnings':result.get('warnings',[])},indent=2))
if __name__=='__main__':main()
