"""Frozen MLX inference for released MERT-v2 FullSong checkpoints.

Input is unstandardized mono float32 audio at 24 kHz. ``encode`` returns the
zero-based Conformer block 20 by default, matching upstream hidden_states[20].
All frontend and neural operations execute in MLX; no PyTorch is imported.
"""
from pathlib import Path
import json
import mlx.core as mx
import mlx.nn as nn


class MERT2MLX:
    def __init__(self, model_path):
        root = Path(model_path)
        self.config = json.loads((root / 'config.json').read_text())
        if self.config['variant'] != 'fs' or self.config['sampling_rate'] != 24000:
            raise ValueError('Expected the released 24 kHz MERT2 FullSong checkpoint')
        heads = int(self.config['num_attention_heads'])
        hidden = int(self.config['hidden_size'])
        if hidden % heads or 'rotary_embedding_base' not in self.config:
            raise ValueError('MERT checkpoint has an invalid rotary configuration')
        # The upstream Torch model keeps inv_freq as a non-persistent buffer.
        # MLX has no mutable buffer-loading step, so materialise and validate
        # the exact frequency table once rather than inheriting loader state.
        head_dim = hidden // heads
        base = float(self.config['rotary_embedding_base'])
        self.rotary_inv_freq = mx.stop_gradient(1.0 / (base ** (mx.arange(0, head_dim, 2, dtype=mx.float32) / head_dim)))
        self.weights = mx.load(str(root / 'model.safetensors'))
        # Stored PyTorch Conv1d is OIK; Metal convolutions consume OKI.
        for key, value in list(self.weights.items()):
            if key.endswith('.weight') and value.ndim == 3 and 'pointwise_block.3' not in key:
                self.weights[key] = value.transpose(0, 2, 1)
        self.weights = {k: mx.stop_gradient(v) for k, v in self.weights.items()}
        if not bool(mx.all(mx.isfinite(self.rotary_inv_freq)).item()):
            raise ValueError('MERT rotary frequencies are non-finite')

    def linear(self, x, p):
        y = x @ self.weights[p + '.weight'].T
        return y + self.weights[p + '.bias'] if p + '.bias' in self.weights else y

    def norm(self, x, p, eps=1e-5):
        return mx.fast.layer_norm(x, self.weights[p+'.weight'], self.weights[p+'.bias'], eps)

    def conv(self, x, p, stride=1, padding=0, groups=1):
        y = mx.conv1d(x, self.weights[p+'.weight'], stride=stride, padding=padding, groups=groups)
        return y + self.weights[p+'.bias'] if p+'.bias' in self.weights else y

    def frontend(self, waveform):
        c = self.config
        n, hop = c['n_fft'], c['hop_length']
        # torch.stft(center=True,pad_mode='reflect'), periodic Hann window.
        half = n // 2
        padded = mx.concatenate([waveform[:, 1:half+1][:, ::-1], waveform,
                                 waveform[:, -half-1:-1][:, ::-1]], axis=1)
        indices = mx.arange(n)[None, :] + hop * mx.arange((padded.shape[1]-n)//hop+1)[:, None]
        frames = padded[:, indices] * self.weights['feature_extractor.spectrogram.window']
        spectrum = mx.fft.rfft(frames, axis=-1)
        power = spectrum.real**2 + spectrum.imag**2
        mel = power @ self.weights['feature_extractor.mel_scale.fb']
        mel = (10 * mx.log10(mx.maximum(mel, 1e-10)))[:, :-1]
        return (mel-self.weights['feature_extractor.mel_mean']) / mx.maximum(self.weights['feature_extractor.mel_std'], 1e-5)

    def subsample(self, x):
        for i, depth in enumerate(self.config['subsampling_depths']):
            p = f'subsampling_module.{i}'
            if p+'.resampling_layer.0.weight' in self.weights:
                x = self.conv(self.norm(x, p+'.resampling_layer.0', 1e-6), p+'.resampling_layer.2', stride=(1,2,2)[i])
            for j in range(depth):
                q = p+f'.convnext_layers.{j}'
                y = self.conv(x, q+'.depthwise_block.1', padding=3, groups=x.shape[-1])
                y = nn.gelu(self.linear(self.norm(y, q+'.pointwise_block.0', 1e-6), q+'.pointwise_block.1'))
                mag = mx.sqrt(mx.sum(y*y, axis=1, keepdims=True))
                normalized = mag/(mx.mean(mag, axis=-1, keepdims=True)+1e-6)
                y = y + self.weights[q+'.pointwise_block.3.weight']*(y*normalized)+self.weights[q+'.pointwise_block.3.bias']
                x = x + self.linear(y, q+'.pointwise_block.4')
        return x

    def block(self, x, i):
        p = f'layers.{i}'
        def ffn(y, which):
            return self.linear(nn.gelu(self.linear(y, p+f'.{which}.w_1')), p+f'.{which}.w_2')
        x = x + 0.5*ffn(self.norm(x, p+'.ffn1_layer_norm'), 'ffn1')
        y = self.norm(x, p+'.attn_layer_norm')
        b,t,d = y.shape
        heads = self.config['num_attention_heads']; hd = d//heads
        q,k,v = [self.linear(y, p+f'.attn.{name}_proj').reshape(b,t,heads,hd).transpose(0,2,1,3) for name in ('query','key','value')]
        q = mx.fast.rope(q, hd, traditional=False, base=self.config['rotary_embedding_base'], scale=1.0, offset=0)
        k = mx.fast.rope(k, hd, traditional=False, base=self.config['rotary_embedding_base'], scale=1.0, offset=0)
        y = mx.fast.scaled_dot_product_attention(q,k,v,scale=hd**-0.5).transpose(0,2,1,3).reshape(b,t,d)
        x = x + self.linear(y,p+'.attn.out_proj')
        y = self.conv(self.norm(x,p+'.conv_module.layer_norm'),p+'.conv_module.conv_block.1')
        a,g = mx.split(y,2,axis=-1); y=a*mx.sigmoid(g)
        y = self.conv(y,p+'.conv_module.conv_block.3',padding=15,groups=d)
        y = nn.gelu(self.norm(y,p+'.conv_module.conv_block.4.1'))
        x = x+self.conv(y,p+'.conv_module.conv_block.6')
        x = x+0.5*ffn(self.norm(x,p+'.ffn2_layer_norm'),'ffn2')
        return self.norm(x,p+'.final_layer_norm')

    def encode(self, waveform, layer=20):
        """Return [batch, floor(samples/960), 1024], without chunking/padding."""
        waveform = mx.array(waveform, dtype=mx.float32)
        if waveform.ndim == 1: waveform = waveform[None]
        if waveform.ndim != 2 or waveform.shape[0] == 0 or waveform.shape[1] < 1025:
            raise ValueError('Expected nonempty mono batch with at least 1025 samples')
        if not bool(mx.all(mx.isfinite(waveform))): raise ValueError('Audio contains non-finite samples')
        if not 0 <= layer < self.config['num_hidden_layers']: raise ValueError('Invalid MERT layer')
        x = self.subsample(self.frontend(waveform))
        for i in range(layer+1):
            x = self.block(x,i)
            mx.eval(x)
        return mx.stop_gradient(x)

    def extract(self, waveform, chunk_seconds=30, layer=20):
        """Encode 1-D mono audio in independent chunks; return [frames,1024].

        This deliberately resets context at each chunk, as the training data
        preparation does. It is not equivalent to full-song context inference.
        A short last chunk is zero-padded to 1025 samples, then cropped to its
        floor(samples/960) valid frames. Chunk sizes must align to 25 Hz.
        """
        wave = mx.array(waveform, dtype=mx.float32)
        size = int(chunk_seconds*24000)
        if wave.ndim != 1 or wave.size < 1025 or size < 1025 or size % 960:
            raise ValueError('Expected mono audio and a chunk size aligned to 25 Hz')
        parts=[]
        for start in range(0,wave.size,size):
            piece=wave[start:start+size]; valid=piece.size//960
            if not valid: continue
            if piece.size < 1025: piece=mx.pad(piece,[(0,1025-piece.size)])
            parts.append(self.encode(piece,layer=layer)[0,:valid])
        return mx.concatenate(parts,axis=0)
