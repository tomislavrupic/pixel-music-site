#!/bin/bash
set -euo pipefail
root="$1"
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
python_bin="$(command -v python3.11 || command -v python3.12 || true)"
[ -n "$python_bin" ] || { echo 'Python 3.11 or 3.12 is required for voice setup.'; exit 1; }
mkdir -p "$root"
if [ ! -x "$root/runtime/bin/python" ]; then "$python_bin" -m venv "$root/runtime"; fi
"$root/runtime/bin/python" -m pip install 'mlx-audio==0.5.3' 'soundfile==0.13.1'
"$root/runtime/bin/python" - "$root" <<'PY'
import hashlib,json,sys,importlib.metadata,subprocess
from pathlib import Path
from huggingface_hub import snapshot_download
root=Path(sys.argv[1]);repo='mlx-community/Qwen3-TTS-12Hz-1.7B-Base-bf16';rev='a6eb4f68e4b056f1215157bb696209bc82a6db48'
snapshot_download(repo,revision=rev,local_dir=root/'model',allow_patterns=['*.json','*.safetensors','*.txt','README.md'])
files={}
for p in (root/'model').rglob('*'):
    if not p.is_file() or '.cache' in p.parts:continue
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    files[str(p.relative_to(root/'model'))]=h.hexdigest()
from mlx_audio.tts.utils import load_model
import soundfile
(root/'requirements.lock.txt').write_text(subprocess.check_output([sys.executable,'-m','pip','freeze'],text=True))
manifest={'modelID':repo,'revision':rev,'runtime':'mlx-audio','runtimeVersion':importlib.metadata.version('mlx-audio'),'files':files}
tmp=root/'installed.tmp.json';tmp.write_text(json.dumps(manifest,indent=2));tmp.replace(root/'installed.json')
print('Qwen3 voice runtime and BF16 model installed. No speech generated.',flush=True)
PY
