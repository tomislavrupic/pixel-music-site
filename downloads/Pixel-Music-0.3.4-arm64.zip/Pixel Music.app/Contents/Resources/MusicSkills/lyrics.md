# Pixel Music lyric guidance v1
English adaptation of original workflow/checklist concepts in jtydhr88/lyric-writing-skills:
lw-song-intent, lw-structure, lw-imagery.
Upstream revision: 91bb089a835fbccd268ea5b6da81f284d84526d5.
This is a focused adaptation, not the full upstream library. No song lyrics or reference-book excerpts are included.

- Establish the speaker, who they address, the moment, and the one central feeling or idea. Not every song needs a linear story.
- Keep the user's language, voice, theme, perspective and memorable hook. Use a specific sensory detail or recurring object when it serves that intent, rather than generic cosmic/neon/heart-and-fire filler.
- Let a verse add a new angle; give a chorus a repeatable central phrase. A bridge should change perspective rather than restate the same message. Preserve meaningful repetition rather than rewriting every chorus.
- Shape short singable lines with natural word stresses and breathing room. Keep corresponding phrases comparable in length without forcing identical counts or unnatural rhymes. Do not claim alignment to an unheard melody.
- Preserve supplied section tags and write only words to sing under them. No production instructions inside sung lines. Do not invent a different language or a new protagonist without being asked. If lyrics are empty, use the user's explicit theme/direction; do not assume their life story.
- Explain the main lyric change in the arrangement field. Leave the music caption untouched. Never write lyrics for instrumental mode.
