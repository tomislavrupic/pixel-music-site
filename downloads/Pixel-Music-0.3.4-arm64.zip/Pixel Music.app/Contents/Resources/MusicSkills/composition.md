# Pixel Music composition guidance v1
English adaptation of original workflow/checklist concepts in jtydhr88/music-composition-skills:
mc-development, mc-arrangement-arch, mc-render-compile, mc-ai-tell-audit.
Upstream revision: 064683f05643ba1801063c0f4cac848cdd1e36a8.
This is a focused adaptation, not the full upstream skill library. No reference-book excerpts are included.

Make decisions before writing the final prompt:
- Identity: retain the user's emotional intent, genre, essential instruments, vocal role and explicit constraints. Pick one recognizable instrumental motif, described by contour and rhythm rather than adjectives.
- Development: decide how that motif returns. Use fragmentation, displacement, variation, extension or a changed register; preserve enough rhythm or contour to recognize it. Do not introduce an unrelated tune in every section.
- Arrangement: assign an opening, a development, a contrast and a return/ending appropriate to the supplied material. Name instrument entrances AND exits. Give a later section a different role from its first appearance.
- Energy: consider subtraction, a reduced texture, a displaced accent or a brief harmonic detour instead of simply stacking layers. Minimal/dub pieces can develop through subtle timbral changes; don't force an EDM drop or pop chorus onto them.
- Groove: distinguish deliberate machine precision from loose human timing. Choose an intentional bass/drum relationship, syncopation or one off-cycle fill when appropriate, not arbitrary tempo changes.
- Surprise: introduce one or two consequential changes, then reconnect to the motif. Avoid random genre lists, constant novelty, generic build/drop cliches and gratuitous distortion. Weirdness must have an audible purpose.
- Audit: could this brief fit any song? If yes replace vague praise with a specific musical event. Is the second appearance different? Does the ending resolve or deliberately leave a trace? Are too many instruments competing for the same role?
- Compile: write a concise YuE2 style caption containing the strongest identity and a few audible development cues. The arrangement is an editable listening guide, not exact timing or guaranteed bar control. Do not emit ABC, MIDI, tool calls or code. Preserve key/tempo and the user's existing lyric structure. Do not place prose arrangement instructions in lyrics. Never claim to have heard or measured audio.
