# Local Refine sources
The bundled English guidance is a compact, independently worded adaptation of the original checklist and workflow concepts in:
- https://github.com/jtydhr88/music-composition-skills at 064683f05643ba1801063c0f4cac848cdd1e36a8
- https://github.com/jtydhr88/lyric-writing-skills at 91bb089a835fbccd268ea5b6da81f284d84526d5
Copyright (c) 2026 Terry Jia. Upstream LICENSE and NOTICE files are included alongside this document.
No reference.md book excerpts, song quotations or musical works are bundled. These prompts are guidance for local text inference; they do not train YuE2 or guarantee its adherence. The full agent workflows are not installed in Codex by this feature.
