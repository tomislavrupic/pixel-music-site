# Emotional Composer · musical transformation guidance v2

Selected arrangement and development concepts adapted from `mc-arrangement-arch` and `mc-development` in https://github.com/jtydhr88/music-composition-skills, upstream revision 064683f05643ba1801063c0f4cac848cdd1e36a8. This focused English adaptation includes no reference-book excerpts. See composition-LICENSE and composition-NOTICE beside this file.

Abzu is an internal creative mapping system, not physics, neuroscience, therapy, or an objective model of human emotion. Translate its selected path and the user's emotional trajectory into audible compositional behavior before producing any candidate summary or composition brief. Framework names and state numbers never belong in the YuE2-facing brief.

## Work from the current musical identity

Each strategy starts from what the song already is. Preserve a recognizable motif, tonal center, tempo, lyric structure, vocal choice, and genre-specific rhythmic language unless the user explicitly asks otherwise. Ask what transformation of that identity moves the piece toward the next intended state. Do not solve every change by introducing new material.

## Contextual musical levers

Use combinations rather than fixed emotion-to-music mappings:
- harmony: stability/ambiguity, harmonic rhythm, voice leading, suspension, borrowed color, delayed cadence, pedal relationships;
- bass: independence, contrary/oblique motion, pedal tones, withheld roots, rhythmic relationship to drums;
- motif: recurrence, fragmentation, inversion, rhythmic displacement, interval expansion/compression, register change, extension, subtraction, changed accompaniment;
- rhythm: syncopation, phrase displacement, density, missing accents, longer/shorter phrase units, groove continuity versus interruption;
- texture: instrument role changes, entrances and exits, narrowing/widening register, foreground/background swaps, subtraction before addition;
- form: opening, development, pressure, reduction, return, ending, or lyric-derived roles appropriate to the actual piece.

Major/minor, consonance/dissonance, speed, register, density, and loudness have no universal emotional meaning. Interpret them only in relation to the established material and requested trajectory. Do not force modulation merely because emotion changes.

## Development without generic climax logic

Rising tension can come from withholding resolution, bass separation, motif fragmentation, phrase extension, rhythmic displacement, reduction, silence, or role reversal. Falling tension does not require a clean cadence or softer dynamics. A return should be recognizable but may change register, harmony, rhythm, orchestration, or phrase length. An unresolved ending can still be structurally complete.

## Concrete arrangement decisions

Use these suggestions inside the existing strategy fields, within the requested prose budget. Explicit intention, trajectory, project controls and exclusions take priority over these suggestions and preset preferences. Do not add fields, require reference tracks, force asymmetric bar counts or invent exact timestamps.

- `melody`: describe the recognizable motif by contour and rhythm, then name one transformation and what remains recognizable when it returns. For vocal songs, develop the motif without changing the lyric words or their structure; instrumental songs need no vocal directions.
- `texture`: name an instrument or role already supported by the song identity, where it enters or leaves, and the audible purpose. A layer can withdraw before a return so the same motif feels renewed; do not automatically add instruments to make every return bigger.
- `bass` and `rhythm`: choose whether bass and drums reinforce or answer each other, or deliberately leave space. Keep the established tempo and style of groove; loose timing and off-cycle fills are options, not requirements for music that calls for machine precision.
- `form`: make each short entry explain an audible change in material, density or instrument role. Identify the intended contrast and return; choose a reduced section or subtraction where it serves the trajectory. Repeated sections may vary accompaniment while retaining the motif, or remain unchanged when repetition is the intent.
- `compositionBrief`: carry the strongest development and arrangement decisions forward to the score planner. Include an intentional ending, such as a cadence, an unresolved motif return or a layer withdrawal, that fits the requested emotional arc. Do not promise exact timing, bar counts, mix levels or faithful audio execution.

Before returning JSON, check that a listener could distinguish the candidates by their musical actions, that entrances and exits fit the supplied instruments, and that the return connects to the opening. Prefer a few consequential events over a checklist of every technique. If a suggestion conflicts with the user's piece, omit it instead of forcing a pop chorus, climax or drop.

## Candidate comparison

Candidates must differ in real musical mechanisms. One might destabilize bass while keeping upper harmony stable; another might keep harmony stable while fragmenting rhythm; another might use phrase extension and subtraction; another might alter motif register and cadence behavior. Do not generate multiple adjective-level paraphrases.

A ranking summary is a compact description of the audible mechanism. A composition brief is a richer but concise instruction to YuE2's score planner. Neither should contain notation, exact ABC, or internal framework terminology.
