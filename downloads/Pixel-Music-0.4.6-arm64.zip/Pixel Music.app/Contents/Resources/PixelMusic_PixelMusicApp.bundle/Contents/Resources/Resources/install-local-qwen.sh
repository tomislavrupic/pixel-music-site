#!/bin/zsh
set -euo pipefail
python_bin="$1"
model_dir="$2"
runtime_dir="${3:-$HOME/Library/Application Support/Pixel Music/Refine/runtime/mlx-serve}"
trap 'echo "Local Qwen installation failed. Check the details above and retry." >&2' ZERR
[[ "$(uname -m)" == arm64 ]] || { echo 'Local Qwen requires Apple Silicon.' >&2; exit 65; }
echo 'PIXEL_MUSIC_STATUS=Checking Local Qwen prerequisites'
"$python_bin" -c 'import huggingface_hub' || { echo 'Repair the YuE2 music runtime first.' >&2; exit 65; }
if [[ ! -x "$runtime_dir/bin/mlx-serve" ]]; then
  echo 'PIXEL_MUSIC_STATUS=Downloading verified mlx-serve runtime'
  work_dir=$(mktemp -d)
  trap 'rm -rf "$work_dir"' EXIT
  /usr/bin/curl --fail --location --retry 2 --connect-timeout 30 --max-time 1800 \
    'https://github.com/ddalcu/mlx-serve/releases/download/v26.8.9/mlx-serve-bin-macos-arm64.tar.gz' -o "$work_dir/runtime.tar.gz"
  echo 'fd1a8fd7da24e7c1f583864b4fd1548e161539b143d787a70f00c9a2745145a8  '"$work_dir/runtime.tar.gz" | /usr/bin/shasum -a 256 -c -
  mkdir "$work_dir/extracted"
  /usr/bin/tar -xzf "$work_dir/runtime.tar.gz" -C "$work_dir/extracted"
  binary_path=$(find "$work_dir/extracted" -type f -name 'mlx-serve' -print -quit)
  [[ -n "$binary_path" ]] || { echo 'Runtime archive has no mlx-serve executable.' >&2; exit 65; }
  "$binary_path" --version
  mkdir -p "${runtime_dir:h}"
  # Rename the complete distribution only after verification.
  [[ ! -e "$runtime_dir" ]] || { echo 'Incomplete runtime folder exists. Reveal Data → Refine/runtime and move it aside, then retry.' >&2; exit 65; }
  mkdir "$work_dir/distribution"
  mv "${binary_path:h}" "$work_dir/distribution/bin"
  mv "$work_dir/distribution" "$runtime_dir"
fi
"$runtime_dir/bin/mlx-serve" --version | /usr/bin/grep -F '26.8.9'
echo 'PIXEL_MUSIC_PROGRESS=0.25' 
echo 'PIXEL_MUSIC_STATUS=Checking selected Qwen model files'
"$python_bin" -u - "$model_dir" <<'PY'
import sys
from pathlib import Path
from huggingface_hub import snapshot_download
root = Path(sys.argv[1])
if root.is_symlink() or root.resolve() == Path('/'):
    raise ValueError('Choose a regular model folder.')
# Existing complete user-selected models are reused, never replaced.
managed = Path.home()/'Library/Application Support/Pixel Music/Refine/models/Qwen3-4B-4bit'
if root == managed or not (root/'config.json').is_file():
    print('PIXEL_MUSIC_STATUS=Downloading Qwen3 4B · about 2.5 GB', flush=True)
    snapshot_download('mlx-community/Qwen3-4B-4bit',
        revision='4dcb3d101c2a062e5c1d4bb173588c54ea6c4d25', local_dir=root)
print('PIXEL_MUSIC_PROGRESS=0.95', flush=True)
PY
# Use the same complete-model validation as inference.
"$python_bin" - "${0:h}" "$model_dir" <<'PY'
import sys
sys.path.insert(0, sys.argv[1])
from local_qwen import check_model
check_model(sys.argv[2])
PY
echo 'PIXEL_MUSIC_PROGRESS=1.0'
echo 'PIXEL_MUSIC_STATUS=Local Qwen installed and files verified'
