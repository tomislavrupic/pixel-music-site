#!/bin/zsh
set -euo pipefail
python_bin="$1"
if [[ ! -x "$python_bin" ]]; then
  echo 'Install the Original YuE2 music runtime first.' >&2
  exit 65
fi
exec "$python_bin" -u "${0:A:h}/install_yue2_ruach.py" --base "$2" --destination "$3" --cache "$4"
