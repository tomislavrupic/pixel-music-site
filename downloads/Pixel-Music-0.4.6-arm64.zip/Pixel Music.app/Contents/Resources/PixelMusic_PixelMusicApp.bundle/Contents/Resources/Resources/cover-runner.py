"""Pixel Music's local FLUX Klein cover adapter. Never overwrites a cover."""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import time
import uuid


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def validate_request(request):
    kind = request.get('ownerKind', 'track')
    if kind == 'preset':
        if any(field in request for field in ('projectID', 'sourceOutputID', 'sourceAudioSHA256')):
            raise ValueError('Preset artwork cannot claim track ownership.')
        for field in ('presetID', 'generationID'):
            try:
                uuid.UUID(request[field])
            except (KeyError, ValueError, TypeError) as exc:
                raise ValueError('Invalid preset artwork owner.') from exc
    elif kind == 'track':
        if 'presetID' in request or 'generationID' in request:
            raise ValueError('Track artwork cannot claim preset ownership.')
        for field in ('projectID', 'sourceOutputID', 'sourceAudioSHA256'):
            if not request.get(field):
                raise ValueError('Missing track cover owner.')
    else:
        raise ValueError('Unknown cover owner kind.')
    output = Path(request['output'])
    if output.exists() or output.is_symlink() or output.name != 'cover.png' or not output.parent.is_dir() or output.parent.is_symlink():
        raise ValueError('Cover output must be a new PNG in the reserved owner folder.')
    return request


def build_report(request, model_id, model_revision, manifest_sha256, runtime_version, adapter_sha256,
                 elapsed, image_sha256):
    return dict(request, ownerKind=request.get('ownerKind', 'track'), modelID=model_id,
                modelRevision=model_revision, modelManifestSHA256=manifest_sha256,
                runtime='mflux', runtimeVersion=runtime_version, adapterSHA256=adapter_sha256,
                width=768, height=768, steps=4, guidance=1.0,
                elapsedSeconds=elapsed, sha256=image_sha256)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--request', required=True)
    args = parser.parse_args()
    request = json.loads(Path(args.request).read_text())
    validate_request(request)
    output = Path(request['output'])
    model_path = Path(request['modelPath'])
    manifest_path = model_path / 'ali-model-manifest.json'
    manifest = json.loads(manifest_path.read_text())
    if manifest['repository'] != 'black-forest-labs/FLUX.2-klein-4B':
        raise ValueError('Select the installed FLUX.2 Klein 4B model.')
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    from mflux.models.common.config import ModelConfig
    from mflux.models.flux2.variants import Flux2Klein
    started = time.monotonic()
    model = Flux2Klein(model_config=ModelConfig.flux2_klein_4b(), model_path=str(model_path), quantize=None)
    result = model.generate_image(seed=request['seed'], prompt=request['prompt'], width=768, height=768,
                                  num_inference_steps=4, guidance=1.0)
    staged = output.parent / 'render.partial.png'
    result.image.save(staged, format='PNG')
    report = build_report(request, manifest['repository'], manifest.get('revision'), digest(manifest_path),
                          importlib.metadata.version('mflux'), digest(__file__),
                          time.monotonic()-started, digest(staged))
    (output.parent / 'result.json').write_text(json.dumps(report, indent=2))
    os.link(staged, output)
    staged.unlink()


if __name__ == '__main__':
    main()
