"""Explicit training bounds; never silently crop a song."""
import math
MAX_SECONDS = 360
SEQUENCE_LIMIT = 12288

def validate_audio_range(start, duration, total, rate):
    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in (start,duration,total,rate)):
        raise ValueError('Invalid audio range')
    if rate <= 0 or start < 0 or not 1 <= duration <= MAX_SECONDS or start+duration > total+1/rate:
        raise ValueError('Use a full track up to six minutes, or explicitly select a 1–360 second excerpt inside the recording. No automatic trimming.')
    return start,duration

def check_sequence_budget(name, seconds, prefix_tokens, limit=SEQUENCE_LIMIT):
    tokens=prefix_tokens+round(seconds*25)+1
    if tokens>limit: raise ValueError(f'{name}: {tokens} tokens exceeds limit {limit}; shorten the lyrics or explicitly select a shorter range; no automatic truncation')
    return tokens
