"""Download verified data, stream-repack without numeric changes, publish once.

Uses the installed pinned MLX source and decoder. Never imports publisher code.
"""
import argparse
import base64
import ctypes
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import ssl
import stat
import struct
import sys
import tempfile
from urllib.request import HTTPSHandler, Request, build_opener

from external_yue2_download import SafeRedirect, allowed_url
from external_yue2_format import open_directory, open_regular, tensor_header
from external_yue2_import import new_file
from external_yue2_store import ensure_directory
import yue2_backbones as profiles


class InstallationCancelled(RuntimeError):
    pass


def open_download(url, offset):
    try:
        import certifi
        context=ssl.create_default_context(cafile=certifi.where())
    except ImportError: context=ssl.create_default_context()
    headers={'Accept-Encoding':'identity','User-Agent':'PixelMusic/0.4.5'}
    if offset: headers['Range']=f'bytes={offset}-'
    return build_opener(SafeRedirect(),HTTPSHandler(context=context)).open(Request(url,headers=headers),timeout=30)


def download_verified(asset, cache, *, open_url=open_download, progress=lambda n:None):
    cache=Path(cache);ensure_directory(cache)
    size=asset['bytes']; expected=asset['sha256']; filename=asset['source']
    if (type(size) is not int or not 0<size<=8*1024**3 or not re.fullmatch('[a-f0-9]{64}',expected)
            or not re.fullmatch(r'[A-Za-z0-9_.+-]+',filename)):
        raise ValueError('Invalid pinned model asset.')
    final=cache/(expected+'.safetensors'); partial=expected+'.partial'
    with open_directory(cache) as parent:
        lock_fd=os.open('.download.lock',os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW|os.O_NONBLOCK,0o600,dir_fd=parent)
        try:
            if not stat.S_ISREG(os.fstat(lock_fd).st_mode): raise ValueError('Invalid download lock.')
            fcntl.flock(lock_fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            if final.exists() or final.is_symlink():
                if final.stat().st_size!=size or profiles.digest(final)!=expected:
                    raise ValueError('Cached model failed its pinned checksum. Remove the damaged cache file and retry.')
                progress(size);return final
            fd=os.open(partial,os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW|os.O_NONBLOCK,0o600,dir_fd=parent)
            with os.fdopen(fd,'r+b') as output:
                own=os.fstat(output.fileno())
                if not stat.S_ISREG(own.st_mode) or own.st_size>size: raise ValueError('Invalid partial model cache.')
                checksum=hashlib.sha256()
                for block in iter(lambda:output.read(8*1024*1024),b''): checksum.update(block)
                count=output.tell()
                if count<size:
                    url=f'https://huggingface.co/{profiles.RUACH}/resolve/{profiles.RUACH_REVISION}/{filename}'
                    with open_url(url,count) as response:
                        if not allowed_url(response.geturl()): raise ValueError('Unsafe download redirect.')
                        if response.status==206:
                            match=re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)',response.headers.get('Content-Range',''))
                            if (not match or tuple(map(int,match.groups()))!=(count,size-1,size)):
                                raise ValueError('Publisher returned an invalid resume range.')
                        elif response.status==200:
                            output.seek(0);output.truncate();count=0;checksum=hashlib.sha256()
                        else: raise ValueError('Download request failed.')
                        progress(count)
                        while block:=response.read(8*1024*1024):
                            count+=len(block)
                            if count>size: raise ValueError('Download exceeded the pinned file size.')
                            output.write(block);checksum.update(block);progress(count)
                        output.flush();os.fsync(output.fileno())
                if count!=size: raise ValueError('Download incomplete; retry resumes the saved partial file.')
                if checksum.hexdigest()!=expected:
                    named=os.stat(partial,dir_fd=parent,follow_symlinks=False)
                    if (named.st_ino,named.st_dev)==(own.st_ino,own.st_dev): os.unlink(partial,dir_fd=parent)
                    raise ValueError('Download checksum mismatch; no model was installed. Retry the download.')
                named=os.stat(partial,dir_fd=parent,follow_symlinks=False)
                if (named.st_ino,named.st_dev)!=(own.st_ino,own.st_dev): raise ValueError('Cache file changed during download.')
                os.link(partial,final.name,src_dir_fd=parent,dst_dir_fd=parent,follow_symlinks=False)
                os.unlink(partial,dir_fd=parent);os.fsync(parent)
            return final
        finally: os.close(lock_fd)


def stream_convert(source, destination, base):
    with open_regular(source) as stream,open_regular(base) as reference:
        size=os.fstat(stream.fileno()).st_size
        header,start=tensor_header(stream,size)
        base_header,_=tensor_header(reference,os.fstat(reference.fileno()).st_size)
        converted=profiles.renamed_header(header)
        layout=lambda h:{k:(v['dtype'],v['shape']) for k,v in h.items() if k!='__metadata__'}
        if layout(converted)!=layout(base_header): raise ValueError('Source tensor layout does not match the pinned MLX backbone.')
        stream.seek(0);original_header=stream.read(start)
        raw=json.dumps(converted,separators=(',',':'),sort_keys=True).encode();raw+=b' '*((-len(raw))%8)
        payload=hashlib.sha256()
        with new_file(Path(destination)) as output:
            output.write(struct.pack('<Q',len(raw)));output.write(raw)
            for block in iter(lambda:stream.read(8*1024*1024),b''):
                output.write(block);payload.update(block)
        return {'schemaVersion':1,'sourceHeader':base64.b64encode(original_header).decode(),
                'sourceBytes':size,'tensorPayloadSHA256':payload.hexdigest(),
                'conversion':'time-embedder names only; unchanged tensor bytes and dtypes'}


def publish_directory(stage, destination):
    # macOS renamex_np(RENAME_EXCL) refuses even an existing empty directory.
    if sys.platform!='darwin': raise OSError('Exclusive directory publication requires macOS.')
    libc=ctypes.CDLL(None,use_errno=True)
    rename=libc.renamex_np;rename.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_uint];rename.restype=ctypes.c_int
    if rename(os.fsencode(stage),os.fsencode(destination),4)!=0:
        code=ctypes.get_errno();raise OSError(code,os.strerror(code),str(destination))


def additional_download_bytes(asset, cache):
    cache=Path(cache)
    completed=cache/(asset['sha256']+'.safetensors')
    if completed.exists() or completed.is_symlink():
        with open_regular(completed,asset['bytes']) as stream:
            if os.fstat(stream.fileno()).st_size!=asset['bytes']: raise ValueError('Invalid completed model cache.')
        return 0  # download_verified authenticates all cached bytes before use.
    partial=cache/(asset['sha256']+'.partial')
    if partial.exists() or partial.is_symlink():
        with open_regular(partial,asset['bytes']) as stream:
            return asset['bytes']-os.fstat(stream.fileno()).st_size
    return asset['bytes']


def install(base, destination, cache, *, open_url=open_download):
    base=Path(base).absolute();destination=Path(destination).absolute();cache=Path(cache).absolute()
    if destination==base or destination in base.parents or base in destination.parents:
        raise ValueError('Choose a separate Ruach folder outside the Original model folder.')
    # Path equality is lexical: case aliases can still name the same directory on
    # macOS. Original exists before conversion, so compare ancestor inode identity.
    if base.exists():
        for ancestor in destination.parents:
            try:
                same=base.samefile(ancestor)
            except FileNotFoundError:
                continue
            if same:
                raise ValueError('Choose a separate Ruach folder outside the Original model folder.')
    if destination.exists() or destination.is_symlink():
        raise ValueError('Ruach destination already exists. Choose a new empty destination path; existing models are preserved.')
    ensure_directory(destination.parent)
    report(.02,'Verifying Original BF16 source and decoder')
    profiles.verify_package(base,profiles.ORIGINAL)
    for name,expected in profiles.ORIGINAL_HASHES.items():
        if profiles.digest(base/name)!=expected: raise ValueError('Original model differs from the pinned MLX package: '+name)
    # Temporary source cache and converted output coexist; reserve adequate space.
    ensure_directory(cache)
    source_space=additional_download_bytes(profiles.RUACH_ASSET,cache)
    decoder_space=(base/'bf16/vae.safetensors').stat().st_size
    output_space=profiles.RUACH_ASSET['bytes']+decoder_space+512*1024**2
    shared=os.stat(cache).st_dev==os.stat(destination.parent).st_dev
    if (shutil.disk_usage(destination.parent).free<output_space+(source_space if shared else 0)
            or (not shared and shutil.disk_usage(cache).free<source_space+512*1024**2)):
        raise ValueError('Not enough free space. Allow about 16 GB for download and conversion, plus the existing Original model.')
    report(.05,'Downloading Ruach First Wave BF16 · 7.3 GB; retry resumes partial data')
    weight=download_verified(profiles.RUACH_ASSET,cache,open_url=open_url,
        progress=lambda n:report(.05+.65*n/profiles.RUACH_ASSET['bytes'],f'Downloading · {n/1e9:.2f} / 7.26 GB'))
    stage=Path(tempfile.mkdtemp(prefix='.'+destination.name+'-',dir=destination.parent))
    try:
        report(.72,'Converting tensor names · BF16 bytes stay unchanged')
        (stage/'bf16').mkdir()
        receipt=stream_convert(weight,stage/'bf16/model.safetensors',base/'bf16/model.safetensors')
        receipt.update(repository=profiles.RUACH,revision=profiles.RUACH_REVISION,
                       sourceFile=profiles.RUACH_ASSET['source'],sourceSHA256=profiles.RUACH_ASSET['sha256'],
                       license='CC BY-NC-SA 4.0',mlxSourceRevision=profiles.ORIGINAL_REVISION)
        for name,expected in profiles.ORIGINAL_HASHES.items():
            if name=='bf16/model.safetensors':continue
            with open_regular(base/name) as source,new_file(stage/name) as target: shutil.copyfileobj(source,target,8*1024*1024)
            if profiles.digest(stage/name)!=expected: raise ValueError('Original component changed while copying: '+name)
        (stage/'conversion.json').write_text(json.dumps(receipt,indent=2))
        (stage/'SOURCE.txt').write_text('Ruach First Wave 2.4 x 0.75\nhttps://huggingface.co/'+profiles.RUACH+'\nCC BY-NC-SA 4.0\nSource SHA-256: '+profiles.RUACH_ASSET['sha256']+'\n')
        hashes={name:profiles.digest(stage/name) for name in profiles.REQUIRED}
        (stage/'pixel-yue2-files.json').write_text(json.dumps(hashes,indent=2))
        (stage/'.pixel-music-model-lock.json').write_text(json.dumps({
            'repository':profiles.RUACH,'revision':profiles.RUACH_REVISION,
            'downloadedAt':datetime.now(timezone.utc).isoformat(),
            'components':{'YuE2-MLX-source':profiles.ORIGINAL_REVISION,'YuE2-Vae':profiles.ORIGINAL_REVISION,
                          'Ruach-merge':'2.4x0.75','Ruach-source-SHA256':profiles.RUACH_ASSET['sha256']}},indent=2))
        report(.9,'Verifying converted model against the original publisher checksum')
        profiles.verify_package(stage,profiles.RUACH)
        publish_directory(stage,destination)
        report(1,'Ruach BF16 installed · select it to use; listening quality unverified')
    finally:
        if stage.exists(): shutil.rmtree(stage)


def report(value, status):
    print(f'PIXEL_MUSIC_PROGRESS={value:.4f}',flush=True)
    print('PIXEL_MUSIC_STATUS='+status,flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--base',type=Path,required=True)
    parser.add_argument('--destination',type=Path,required=True);parser.add_argument('--cache',type=Path,required=True)
    args=parser.parse_args()
    def cancelled(*_): raise InstallationCancelled('Installation cancelled; retry resumes the download.')
    signal.signal(signal.SIGTERM,cancelled);signal.signal(signal.SIGINT,cancelled)
    install(args.base,args.destination,args.cache)

if __name__=='__main__':
    try: main()
    except Exception as error:
        print(str(error),file=sys.stderr,flush=True);sys.exit(1)
