"""Pinned YuE2 backbone identities and data-only package verification."""
import base64
import hashlib
import io
import json
import os
from pathlib import Path

from external_yue2_format import open_regular, read_json_file, tensor_header

ORIGINAL = 'ahmadw/YuE2-3B-MLX'
ORIGINAL_REVISION = 'fe0a9050fd658257b486b880422d8872ee1f81e3'
RUACH = 'goldhub/YuE2-RS-Finetunes'
RUACH_REVISION = 'b29378f7b966c737bedb88ec1d37f88330f6f3f1'
RUACH_ASSET = {'source':'YuE2-3B-RS-FW-2.4x0.75-BF16.safetensors', 'bytes':7261442328,
               'sha256':'304696c0ef273c455ede46ca3a252f57e3683b5aa3107617c09a08a658b56bfa'}
# Independently verified against the installed pinned original distribution.
ORIGINAL_HASHES = {
    'generate.py':'5de06be8d3db45dc72c7cd780ed50e6bbac9453b272992b32a1c81d8e042fc0d',
    'yue2_model.py':'ef5230b3dea7f5b4823c1c1de159228c7199266b30ea68ca79ced4f0c7d0190e',
    'yue2_vae.py':'f45e397485be682649b36257e9c76b9184fa460f0abedf05ff3bb21c66ab216b',
    'bf16/model.safetensors':'e6012e94aca961eebc2f57ae0c5417b1f40125c33c41e5f3a6ca0b28982361f7',
    'bf16/vae.safetensors':'dc7bea8e4f8e764be6ee2ce3291606a5381aaa20f5c4eb26e86ca81dd1eeac6e',
    'bf16/config.json':'ad3477bbef890bf98ae196c1e4b44779494a6231c4ab66f32708eabadf265329',
    'bf16/vae_config.json':'f0191bb9694009956de44e0c361a6f1334760be4c8f848e599bde242a54a0970',
    'bf16/qwen.tiktoken':'b2b1b8dfb5cc5f024bafc373121c6aba3f66f9a5a0269e243470a1de16a33186',
    'bf16/yue2_generation_config.json':'203830cebde6e3644eb291925362990d198e66c3b6006cd11f1aaa21904bcc61',
}
REQUIRED = tuple(ORIGINAL_HASHES)


def digest(path):
    with open_regular(path) as stream:
        h=hashlib.sha256()
        for block in iter(lambda:stream.read(8*1024*1024),b''): h.update(block)
        return h.hexdigest()


def renamed_header(header):
    result={}
    for key,value in header.items():
        name=key
        for old,new in [('time_embedder.mlp.0.','time_embedder.fc1.'),('time_embedder.mlp.2.','time_embedder.fc2.')]:
            if key.startswith(old): name=new+key[len(old):]; break
        if name in result: raise ValueError('Duplicate converted tensor name.')
        result[name]=value
    result['__metadata__']={**header.get('__metadata__',{}),'format':'mlx'}
    return result


def verify_converted(path, receipt, source_sha256):
    """Authenticate converted bytes against the pinned *original* source digest.

    A local manifest cannot authorize changed tensors: reconstruct the source's
    exact header plus current payload and compare to the publisher SHA-256.
    """
    try:
        raw=base64.b64decode(receipt['sourceHeader'],validate=True)
        if len(raw)>1024*1024: raise ValueError('Oversized source header.')
        source_header,_=tensor_header(io.BytesIO(raw),receipt['sourceBytes'])
    except (KeyError,TypeError,ValueError) as exc: raise ValueError('Invalid source conversion receipt.') from exc
    with open_regular(path) as stream:
        header,start=tensor_header(stream,os.fstat(stream.fileno()).st_size)
        if header!=renamed_header(source_header): raise ValueError('Converted tensor layout differs from source.')
        source=hashlib.sha256(raw); converted=hashlib.sha256()
        stream.seek(0);converted.update(stream.read(start))
        count=len(raw)
        for block in iter(lambda:stream.read(8*1024*1024),b''):
            source.update(block);converted.update(block);count+=len(block)
        if count!=receipt['sourceBytes'] or source.hexdigest()!=source_sha256:
            raise ValueError('Converted model failed the pinned source checksum.')
        return converted.hexdigest()


def verify_package(root, expected_repository=None):
    root=Path(root)
    if root.is_symlink(): raise ValueError('Model root must be a real local directory.')
    root=root.resolve()
    lock=read_json_file(root/'.pixel-music-model-lock.json')
    repo=lock.get('repository')
    revision={ORIGINAL:ORIGINAL_REVISION,RUACH:RUACH_REVISION}.get(repo)
    if revision is None or lock.get('revision')!=revision or (expected_repository is not None and repo!=expected_repository):
        raise ValueError('Installed model identity does not match the selected pinned checkpoint.')
    manifest=read_json_file(root/'pixel-yue2-files.json')
    converted_hash=None
    if repo==RUACH:
        receipt=read_json_file(root/'conversion.json',2*1024*1024)
        if (receipt.get('repository')!=RUACH or receipt.get('revision')!=RUACH_REVISION
                or receipt.get('sourceSHA256')!=RUACH_ASSET['sha256']
                or receipt.get('sourceBytes')!=RUACH_ASSET['bytes']
                or lock.get('components',{}).get('YuE2-MLX-source')!=ORIGINAL_REVISION):
            raise ValueError('Ruach conversion identity or source is invalid.')
        converted_hash=verify_converted(root/'bf16/model.safetensors',receipt,RUACH_ASSET['sha256'])
    for name in REQUIRED:
        observed=converted_hash if name=='bf16/model.safetensors' and converted_hash else digest(root/name)
        if observed!=manifest.get(name): raise ValueError('Installed YuE2 file changed or is incomplete: '+name)
        if repo==RUACH and name!='bf16/model.safetensors' and observed!=ORIGINAL_HASHES[name]:
            raise ValueError('Ruach requires the pinned MLX source and decoder: '+name)
    config=read_json_file(root/'bf16/config.json')
    if config.get('quantization') or config.get('quantization_config'):
        raise ValueError('This installation requires BF16, not quantized weights.')
    return lock,manifest
