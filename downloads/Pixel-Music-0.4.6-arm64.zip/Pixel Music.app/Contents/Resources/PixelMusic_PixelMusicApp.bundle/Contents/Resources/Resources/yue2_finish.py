"""App-owned semantic ending gate for the pinned YuE2 MLX pipeline.

Manual duration caps retain the upstream path. Auto mode only synthesizes a
completed semantic sequence. Two bounded attempts retain exact seeds/tokens.
"""
import json
import time


def generate_finished(pipe, backend, *, style, lyrics, cot, abc, seed,
                      guidance, sampling, steps, on_latents, artifacts, log):
    if cot == "off" and abc is not None:
        raise ValueError("External ABC requires melody or full planning.")
    abc_ids = pipe.tokenizer.encode(abc) if abc is not None else []
    prefix = backend.token_prefix(pipe.tokenizer, style, lyrics, cot, abc_ids)
    negative = backend.negative_prefix(pipe.tokenizer, cot, abc_ids) if guidance != 1 else None
    attempts = []
    log(f"[semantic] prefix {len(prefix)} tokens, cfg {guidance}")
    for number in range(2):
        attempt_seed = (seed + number) % (2**32)
        started = time.monotonic()
        ids, truncated = backend.generate_tokens(pipe.model, prefix, sampling, attempt_seed,
            'semantic', negative, guidance, legacy_off=cot == 'off', on_token=pipe._progress('semantic'))
        attempts.append({'seed': attempt_seed, 'ended': not truncated, 'tokens': ids,
                         'elapsedSeconds': time.monotonic() - started})
        (artifacts/'semantic-attempts.json').write_text(json.dumps(attempts))
        if not truncated and ids:
            break
        if number == 0:
            log('YUE2_ENDING_RETRY No complete ending yet; trying one fresh semantic seed before rendering.')
    else:
        raise ValueError('Auto length could not reach a complete ending after two attempts. '
                         'No audio was rendered. Try a shorter arrangement or another seed. '
                         'The semantic attempts are saved with this output.')
    codec = [token - backend.CODEC_OFFSET for token in ids]
    log(f'[semantic] complete ending after {len(attempts)} attempt(s)')
    started = time.monotonic()
    latents = backend.synthesize(pipe.model, prefix, codec, attempt_seed, steps,
        on_progress=lambda i, n: i % 8 == 0 and log(f'[nar] step {i}/{n}'))
    on_latents(latents)
    synthesis_seconds = time.monotonic() - started
    started = time.monotonic()
    log("[vae] decoding")
    audio = pipe.decode(latents)
    return audio, {'abc': abc, 'codec': codec, 'prefix': prefix,
                  'ending': {'attempts': len(attempts), 'effectiveSeed': attempt_seed,
                             'semanticSeconds': sum(a['elapsedSeconds'] for a in attempts),
                             'synthesisSeconds': synthesis_seconds,
                             'decodeSeconds': time.monotonic() - started}}
