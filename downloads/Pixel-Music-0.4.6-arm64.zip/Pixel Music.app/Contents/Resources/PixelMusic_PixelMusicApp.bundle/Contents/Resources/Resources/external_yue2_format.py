"""Inspect the conventional YuE2 A/B exporter without executing downloaded code.

Inspection establishes file structure and finite tensors, never training provenance,
listening approval, or compatibility with an unverified MLX projection layout.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import struct
from typing import BinaryIO, Iterator

MAX_CONFIG_BYTES = 256 * 1024
MAX_HEADER_BYTES = 16 * 1024 * 1024
MAX_ADAPTER_BYTES = 512 * 1024 * 1024
MAX_TENSOR_ENTRIES = 4096
MAX_DISCOVERY_ENTRIES = 128
CHUNK_BYTES = 1024 * 1024
WIDTHS = {'F16': 2, 'BF16': 2, 'F32': 4}
PROTOCOL = 'monsterovich-yue2-ab-v1'
TARGET = re.compile(r'model\.layers\.(0|[1-9][0-9]*)\.(?:(nar_)?self_attn\.(q_proj|k_proj|v_proj|o_proj)|(nar_)?mlp\.(gate_proj|up_proj|down_proj))\Z')
FACTOR = re.compile(r'(.+)\.(lora_A|lora_B)\Z')
HEADS = {'vae2llm', 'llm2vae'}


class AdapterFormatError(ValueError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


def fail(code: str, message: str) -> None:
    raise AdapterFormatError(code, message)


def absolute_path(path: Path | str) -> Path:
    path = Path(path)
    if '..' in path.parts or '\0' in str(path):
        fail('unsafe_path', f'Parent traversal or NUL in path: {path}')
    return path if path.is_absolute() else Path.cwd() / path


@contextmanager
def open_directory(path: Path | str) -> Iterator[int]:
    """Walk every component with no-follow semantics, including parent directories."""
    path = absolute_path(path)
    if not hasattr(os, 'O_NOFOLLOW') or not hasattr(os, 'O_DIRECTORY'):
        fail('unsupported_platform', 'Import requires POSIX no-follow directory access.')
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:]:
            next_fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                              dir_fd=fd)
            os.close(fd)
            fd = next_fd
        yield fd
    except OSError as exc:
        fail('unsafe_path', f'Cannot safely access directory {path}: {exc.strerror}')
    finally:
        os.close(fd)


def _signature(info: os.stat_result) -> tuple:
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


@contextmanager
def open_regular(path: Path | str, max_bytes: int | None = None) -> Iterator[BinaryIO]:
    """Read a stable regular file. O_NONBLOCK prevents a FIFO from hanging import."""
    path = absolute_path(path)
    with open_directory(path.parent) as parent:
        try:
            fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                         dir_fd=parent)
        except FileNotFoundError:
            fail('missing_file', f'Missing file: {path}')
        except OSError as exc:
            fail('unsafe_path', f'Cannot safely read {path}: {exc.strerror}')
        with os.fdopen(fd, 'rb') as stream:
            before = os.fstat(stream.fileno())
            if not stat.S_ISREG(before.st_mode):
                fail('unsafe_path', f'Not a regular file: {path}')
            if max_bytes is not None and before.st_size > max_bytes:
                fail('size_limit', f'{path.name} exceeds {max_bytes} bytes.')
            yield stream
            after = os.fstat(stream.fileno())
            named = os.stat(path.name, dir_fd=parent, follow_symlinks=False)
            if _signature(before) != _signature(after) or _signature(after) != _signature(named):
                fail('source_changed', f'File changed during inspection: {path}')


def _pairs(items: list[tuple]) -> dict:
    result = {}
    for key, value in items:
        if key in result:
            fail('invalid_json', f'Duplicate JSON key: {key}')
        result[key] = value
    return result


def _number(value: str) -> float:
    number = float(value)
    if not math.isfinite(number):
        fail('invalid_json', 'Non-finite JSON number.')
    return number


def strict_json(raw: bytes) -> dict:
    try:
        value = json.loads(raw.decode('utf-8'), object_pairs_hook=_pairs,
                           parse_float=_number,
                           parse_constant=lambda s: fail('invalid_json', f'Invalid JSON constant: {s}'))
    except (UnicodeError, json.JSONDecodeError, RecursionError, OverflowError, ValueError) as exc:
        if isinstance(exc, AdapterFormatError):
            raise
        fail('invalid_json', f'Invalid UTF-8 JSON: {exc}')
    if not isinstance(value, dict):
        fail('invalid_json', 'Expected a JSON object.')
    return value


def read_json_file(path: Path, limit: int = MAX_CONFIG_BYTES) -> dict:
    with open_regular(path, limit) as stream:
        return strict_json(stream.read(limit + 1))


def digest_stream(stream: BinaryIO) -> str:
    stream.seek(0)
    digest = hashlib.sha256()
    for chunk in iter(lambda: stream.read(CHUNK_BYTES), b''):
        digest.update(chunk)
    return digest.hexdigest()


def digest_file(path: Path, limit: int | None = None) -> str:
    with open_regular(path, limit) as stream:
        return digest_stream(stream)


def tensor_header(stream: BinaryIO, size: int) -> tuple[dict, int]:
    stream.seek(0)
    prefix = stream.read(8)
    if len(prefix) != 8:
        fail('invalid_header', 'Truncated safetensors length prefix.')
    length = struct.unpack('<Q', prefix)[0]
    if length > MAX_HEADER_BYTES:
        fail('size_limit', f'Safetensors header exceeds {MAX_HEADER_BYTES} bytes (possibly a Git LFS pointer).')
    if length < 2 or length > size - 8:
        fail('invalid_header', 'Safetensors header length is outside the file.')
    raw = stream.read(length)
    if len(raw) != length:
        fail('invalid_header', 'Truncated safetensors header.')
    header = strict_json(raw)
    metadata = header.get('__metadata__', {})
    if not isinstance(metadata, dict) or any(not isinstance(v, str) for v in metadata.values()):
        fail('invalid_header', 'Safetensors metadata must contain string values.')
    tensors = {k: v for k, v in header.items() if k != '__metadata__'}
    if len(tensors) > MAX_TENSOR_ENTRIES:
        fail('size_limit', f'More than {MAX_TENSOR_ENTRIES} tensor entries.')
    if not tensors:
        fail('invalid_header', 'Empty adapter tensor inventory.')
    payload_size = size - 8 - length
    ranges = []
    for key, item in tensors.items():
        if not key or len(key) > 512 or not isinstance(item, dict) or set(item) != {'dtype', 'shape', 'data_offsets'}:
            fail('invalid_header', f'Invalid tensor descriptor: {key}')
        dtype, shape, offsets = item['dtype'], item['shape'], item['data_offsets']
        if not isinstance(dtype, str) or dtype not in WIDTHS:
            fail('unsupported_dtype', f'{key}: only F16/F32/BF16 tensors are supported.')
        if not isinstance(shape, list) or len(shape) > 8 or any(type(n) is not int or n <= 0 for n in shape):
            fail('invalid_header', f'{key}: invalid shape.')
        if not isinstance(offsets, list) or len(offsets) != 2 or any(type(n) is not int for n in offsets):
            fail('invalid_header', f'{key}: invalid offsets.')
        start, end = offsets
        count = math.prod(shape)
        if start < 0 or end <= start or end > payload_size or count > payload_size // WIDTHS[dtype] or end - start != count * WIDTHS[dtype]:
            fail('invalid_header', f'{key}: tensor length or range is invalid.')
        ranges.append((start, end))
    expected = 0
    for start, end in sorted(ranges):
        if start != expected:
            fail('invalid_header', 'Overlapping tensor ranges or a gap in the payload.')
        expected = end
    if expected != payload_size:
        fail('invalid_header', 'Trailing or missing bytes in the tensor payload.')
    return header, 8 + length


def read_tensor_header(path: Path) -> dict:
    with open_regular(path, MAX_ADAPTER_BYTES) as stream:
        return tensor_header(stream, os.fstat(stream.fileno()).st_size)[0]


def scan_finite(stream: BinaryIO, header: dict, offset: int) -> None:
    import numpy as np
    for name, entry in header.items():
        if name == '__metadata__':
            continue
        start, end = entry['data_offsets']
        stream.seek(offset + start)
        remaining = end - start
        dtype = entry['dtype']
        while remaining:
            size = min(CHUNK_BYTES, remaining)
            block = stream.read(size)
            if len(block) != size:
                fail('source_changed', f'Truncated tensor during finite scan: {name}')
            if dtype == 'BF16':
                values = np.frombuffer(block, dtype='<u2')
                finite = not bool(np.any((values & 0x7f80) == 0x7f80))
            else:
                finite = bool(np.isfinite(np.frombuffer(block, dtype='<f2' if dtype == 'F16' else '<f4')).all())
            if not finite:
                fail('nonfinite_tensor', f'{name} contains NaN or infinity.')
            remaining -= size


def _branch(target: str) -> str:
    if target in HEADS:
        return 'nar'
    match = TARGET.fullmatch(target)
    if not match:
        fail('unsupported_tensor', f'Unsupported target module: {target}')
    return 'nar' if match.group(2) or match.group(4) else 'ar'


def _config(raw: dict) -> tuple[str, int, float]:
    rank, alpha = raw.get('rank'), raw.get('alpha')
    if type(rank) is not int or rank < 1 or type(alpha) not in (int, float):
        fail('invalid_config', 'Positive integer rank and explicit positive alpha are required.')
    try:
        alpha = float(alpha)
    except OverflowError:
        fail('invalid_config', 'Alpha is too large.')
    if not math.isfinite(alpha) or alpha <= 0:
        fail('invalid_config', 'Alpha must be positive and finite.')
    for flag in ('ar', 'include_heads'):
        if flag in raw and type(raw[flag]) is not bool:
            fail('invalid_config', f'{flag} must be a boolean.')
    dropout = raw.get('dropout', 0)
    if type(dropout) not in (int, float) or not 0 <= dropout < 1:
        fail('invalid_config', 'Dropout must be in [0, 1).')
    if raw.get('use_dora') or raw.get('use_rslora') or raw.get('peft_type', 'LORA') != 'LORA':
        fail('unsupported_algorithm', 'Only the conventional alpha/r A/B exporter is supported.')
    return ('ar' if raw.get('ar', False) else 'nar'), rank, alpha


def inspect_adapter(folder: Path, base_shapes: dict[str, tuple[int, ...]] | None = None) -> dict:
    """Inspect bytes and optional target shapes. Does not register, normalize or approve."""
    folder = absolute_path(folder)
    weights_path, config_path = folder/'lora.safetensors', folder/'adapter_config.json'
    with open_regular(weights_path, MAX_ADAPTER_BYTES) as weights:
        size = os.fstat(weights.fileno()).st_size
        header, offset = tensor_header(weights, size)
        names = [key for key in header if key != '__metadata__']
        if any(any(marker in key.lower() for marker in ('hum_proj', 'yue2_hum', 'stem_proj')) for key in names):
            fail('requires_audio_conditioning', 'This adapter needs a hum/audio-conditioning workflow. It cannot be used as a style-only LoRA.')
        factors = {}
        for key in names:
            match = FACTOR.fullmatch(key)
            if not match:
                fail('unsupported_tensor', f'Unsupported tensor (not discarded): {key}')
            target, factor = match.groups()
            _branch(target)
            factors.setdefault(target, {})[factor] = header[key]
        try:
            with open_regular(config_path, MAX_CONFIG_BYTES) as stream:
                raw = stream.read(MAX_CONFIG_BYTES + 1)
                config = strict_json(raw)
                config_asset = {'path': str(config_path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        except AdapterFormatError as exc:
            if exc.code == 'missing_file':
                fail('missing_config', 'Expected adapter_config.json with explicit rank and alpha.')
            raise
        branch, rank, alpha = _config(config)
        if 'tensors' in config and (type(config['tensors']) is not int or config['tensors'] != len(names)):
            fail('invalid_config', 'Configured tensor count does not match the file.')
        if 'branch' in header.get('__metadata__', {}) and header['__metadata__']['branch'] != branch:
            fail('branch_mismatch', 'Header and config disagree about the adapter branch.')
        targets = []
        for target, pair in sorted(factors.items()):
            if _branch(target) != branch:
                fail('branch_mismatch', f'{target} contradicts the configured branch.')
            if set(pair) != {'lora_A', 'lora_B'}:
                fail('incomplete_pair', f'{target}: missing A or B factor.')
            a, b = pair['lora_A']['shape'], pair['lora_B']['shape']
            if len(a) != 2 or len(b) != 2 or a[0] != rank or b[1] != rank:
                fail('shape_mismatch', f'{target}: factors disagree with rank {rank}.')
            shape = (b[0], a[1])
            key = target + '.weight'
            if base_shapes is not None:
                if key not in base_shapes:
                    fail('unknown_target', f'Target absent in supplied base layout: {key}')
                if tuple(base_shapes[key]) != shape:
                    fail('shape_mismatch', f'{key}: expected {base_shapes[key]}, factors imply {shape}.')
            targets.append({'module': target, 'weightShape': list(shape), 'rank': rank})
        present_heads = set(factors) & HEADS
        if (bool(present_heads) != config.get('include_heads', False)
                or (present_heads and present_heads != HEADS)):
            fail('branch_mismatch', 'Latent heads must agree with include_heads and form a complete pair of modules.')
        for field in ('base_model', 'base_model_name_or_path', 'base_revision'):
            if field in config and (not isinstance(config[field], str)
                    or not config[field] or len(config[field]) > 256
                    or any(ord(character) < 32 for character in config[field])):
                fail('invalid_config', f'{field} must be a short, nonempty text value.')
        for field in ('base_model', 'base_model_name_or_path'):
            if field in config and config[field] != 'm-a-p/YuE2-3B':
                fail('base_mismatch', f'Unsupported declared base in {field}: {config[field]}')
        scan_finite(weights, header, offset)
        weights_asset = {'path': str(weights_path), 'bytes': size, 'sha256': digest_stream(weights)}
    return {'protocol': PROTOCOL, 'status': 'inspected', 'renderReady': False,
            'branch': branch, 'rank': rank, 'alpha': alpha, 'targets': targets,
            'weights': weights_asset, 'config': config_asset,
            'shapeCheck': 'not_checked' if base_shapes is None else 'matched_supplied_shapes',
            'declaredBase': {key: config[key] for key in ('base_model', 'base_model_name_or_path', 'base_revision') if key in config},
            'warnings': ['Training-checkpoint identity is not verified.',
                         'Inspection does not verify the upstream-to-MLX projection layout or musical quality.']}


def discover_adapters(root: Path) -> list[dict]:
    """Root plus one level, <=128 total scanned entries. No filename-based pairing."""
    root = absolute_path(root)
    count = 0
    result = []

    def entries(folder):
        nonlocal count
        items = []
        with open_directory(folder) as fd:
            with os.scandir(fd) as scan:
                for entry in scan:
                    count += 1
                    if count > MAX_DISCOVERY_ENTRIES:
                        fail('size_limit', f'Folder discovery exceeds {MAX_DISCOVERY_ENTRIES} entries.')
                    info = entry.stat(follow_symlinks=False)
                    if stat.S_ISLNK(info.st_mode):
                        fail('unsafe_path', f'Symbolic link in import folder: {folder/entry.name}')
                    items.append((entry.name, stat.S_ISDIR(info.st_mode), stat.S_ISREG(info.st_mode)))
        return sorted(items)

    def consider(folder, items):
        files = {name for name, _, regular in items if regular}
        if 'lora.safetensors' in files:
            result.append({'folder': str(folder), 'hasWeights': True,
                           'hasConfig': 'adapter_config.json' in files})

    top = entries(root)
    consider(root, top)
    for name, directory, _ in top:
        if directory:
            folder = root/name
            consider(folder, entries(folder))
    return result
