"""Shared writing craft over a native host exchange. No credentials or network access."""
import argparse,hashlib,importlib.util,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parent

def load(name):
    spec=importlib.util.spec_from_file_location('pixel_'+name.replace('-','_'),ROOT/(name+'.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def exchange(messages,temperature=None):
    print('PIXEL_WRITING_REQUEST='+json.dumps({'messages':messages},ensure_ascii=False),flush=True)
    line=sys.stdin.readline(2*1024*1024)
    if not line:raise ValueError('Writing request cancelled or connection closed.')
    response=json.loads(line)
    if not isinstance(response.get('text'),str):raise ValueError('The writing assistant returned no text.')
    return response['text']

def run(kind,request,model,output):
    if output.exists() or output.is_symlink():raise FileExistsError('A suggestion already exists; start a new run.')
    if kind not in ('refine','composer'):raise ValueError('Unknown writing task.')
    module=load('music-refine' if kind=='refine' else 'abzu-compose')
    module.validate_request(request)
    system,user=module.build_prompt(request)
    metadata={'provider':'chatgpt','model':model,'runtime':'OpenAI Responses API',
              'guidanceSHA256':hashlib.sha256(system.encode()).hexdigest(),
              'modelConfigSHA256':hashlib.sha256(json.dumps({'provider':'chatgpt','model':model},sort_keys=True).encode()).hexdigest(),
              'seedRequested':str(request.get('seed','not supported'))}
    calls=0
    def ask(messages,temperature=None):
        nonlocal calls
        calls+=1
        if calls>2:raise ValueError('Writing assistance exceeded its two-request limit.')
        raw=exchange(messages,temperature)
        with output.with_name(output.name+f'.raw-{calls}.txt').open('x') as f:f.write(raw)
        return raw
    if kind=='refine':
        image=module.prepare_image(request,output) if request['mode']=='image' else None
        result,evidence=module.develop(request,ask,image)
        result['provenance']={**metadata,'mode':request['mode'],'skillPack':'pixel-music-craft-v2',
                              'writingProfile':request.get('writingProfile','standard'),
                              **{k:str(v) for k,v in evidence.items()}}
        if image:result['provenance']['imageSHA256']=request['imageSHA256']
    else:
        messages=[{'role':'system','content':system},{'role':'user','content':user}]
        for attempt in (1,2):
            raw=ask(messages)
            try:result=module.validate_result(raw,request);break
            except ValueError as error:
                if attempt==2:raise
                messages=messages+[{'role':'user','content':f'Correct this validation error: {error}. Return only the required JSON, preserving the original request.'}]
        # Keep the historical field readable; runtime/provider identify the real source.
        result['qwen']=metadata
    with output.open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--task',choices=('refine','composer'),required=True)
    p.add_argument('--request',type=pathlib.Path,required=True);p.add_argument('--model',required=True);p.add_argument('--output',type=pathlib.Path,required=True)
    a=p.parse_args()
    try:run(a.task,json.loads(a.request.read_text()),a.model,a.output)
    except Exception as e:print(str(e).replace('Qwen','Writing assistant'),file=sys.stderr);sys.exit(1)
