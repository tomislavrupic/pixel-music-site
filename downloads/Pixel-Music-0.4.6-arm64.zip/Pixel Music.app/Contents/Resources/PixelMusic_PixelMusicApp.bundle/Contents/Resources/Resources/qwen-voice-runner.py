#!/usr/bin/env python3
"""Pinned local Qwen Base voice cloning. A unique request folder owns every take."""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import time

MODEL_ID = 'mlx-community/Qwen3-TTS-12Hz-1.7B-Base-bf16'
REVISION = 'a6eb4f68e4b056f1215157bb696209bc82a6db48'
LANGUAGES = {'English','Chinese','Japanese','Korean','German','French','Russian','Portuguese','Spanish','Italian'}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8*1024*1024), b''): h.update(b)
    return h.hexdigest()


def validate(request):
    text = request.get('text', '')
    transcript = request.get('referenceTranscript', '')
    if not isinstance(text, str) or not text.strip() or len(text) > 2000:
        raise ValueError('Enter up to 2,000 characters to speak.')
    if not isinstance(transcript, str) or not transcript.strip() or len(transcript) > 4000:
        raise ValueError('The exact reference transcript is required.')
    if request.get('language') not in LANGUAGES:
        raise ValueError('Unsupported speech language.')
    if not isinstance(request.get('seed'), int) or not 0 <= request['seed'] <= 2**32-1:
        raise ValueError('Invalid seed.')


def segments(text):
    """Bound synthesis chunks without dropping punctuation or non-Latin text."""
    pieces = re.split(r'(?<=[.!?。！？])\s*|\n+', text.strip())
    out = []
    for piece in pieces:
        piece = piece.strip()
        while len(piece) > 280:
            cut = piece.rfind(' ', 0, 280)
            if cut < 80: cut = 280
            out.append(piece[:cut].strip()); piece = piece[cut:].strip()
        if piece: out.append(piece)
    return out


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--request', required=True)
    args = parser.parse_args(); request_file = Path(args.request).resolve(); folder = request_file.parent
    request = json.loads(request_file.read_text()); validate(request)
    output = folder/'speech.wav'
    if output.exists() or (folder/'result.json').exists(): raise ValueError('This take already exists. Create a new take.')
    root = Path(request['runtimeRoot']).resolve(); model = (root/'model').resolve()
    installed = json.loads((root/'installed.json').read_text())
    if installed.get('modelID') != MODEL_ID or installed.get('revision') != REVISION or installed.get('runtimeVersion') != '0.5.3':
        raise ValueError('Voice installation does not match the supported model. Run setup again.')
    print('Checking model and reference…', flush=True)
    required = {'model.safetensors','config.json','speech_tokenizer/model.safetensors','speech_tokenizer/config.json'}
    if not required.issubset(installed.get('files',{})): raise ValueError('Incomplete model manifest.')
    for name, digest in installed['files'].items():
        p = (model/name).resolve()
        if not p.is_relative_to(model) or sha(p) != digest: raise ValueError('Model file verification failed: '+name)
    reference = folder/'reference.wav'
    if sha(reference) != request['referenceSHA256']: raise ValueError('Reference audio changed.')
    os.environ['HF_HUB_OFFLINE'] = '1'; os.environ['TRANSFORMERS_OFFLINE'] = '1'; os.environ['TOKENIZERS_PARALLELISM']='false'
    import numpy as np
    import soundfile as sf
    import mlx.core as mx
    from mlx_audio.tts.utils import load_model
    if importlib.metadata.version('mlx-audio') != '0.5.3': raise ValueError('Unsupported voice runtime version.')
    info = sf.info(reference)
    if not 3 <= info.duration <= 30: raise ValueError('Use a clean reference WAV between 3 and 30 seconds.')
    ref, _ = sf.read(reference, dtype='float32')
    if not np.all(np.isfinite(ref)) or float(np.max(np.abs(ref))) < .0001: raise ValueError('Reference is silent or invalid.')
    print('Loading Qwen3-TTS BF16…', flush=True)
    start=time.monotonic(); voice=load_model(str(model))
    if voice.config.tts_model_type != 'base' or not voice.speech_tokenizer.has_encoder:
        raise ValueError('Voice cloning requires the Base model with its speech encoder.')
    chunks=[]; text_segments=segments(request['text']); rate=None; warnings=[]
    for i, text in enumerate(text_segments):
        print(f'Generating speech {i+1}/{len(text_segments)}…',flush=True)
        mx.random.seed((request['seed']+i) % 2**32)
        results=voice.generate(text=text,ref_audio=str(reference),ref_text=request['referenceTranscript'],lang_code=request['language'].lower(),temperature=.9,top_k=50,top_p=1.0,repetition_penalty=1.5,max_tokens=2048,stream=False,verbose=False)
        found=False
        for result in results:
            audio=np.asarray(result.audio,dtype=np.float32).reshape(-1)
            if not len(audio) or not np.all(np.isfinite(audio)): raise ValueError('The model returned invalid audio.')
            if rate is not None and rate != result.sample_rate: raise ValueError('Inconsistent sample rates.')
            rate=result.sample_rate; chunks.append(audio); found=True
            if getattr(result,'token_count',0) >= 2048: warnings.append('A speech segment reached its length limit; check the ending.')
        if not found: raise ValueError('No speech was produced.')
        if i < len(text_segments)-1: chunks.append(np.zeros(int(rate*.16),dtype=np.float32))
    audio=np.concatenate(chunks)
    if np.max(np.abs(audio)) < .0001: raise ValueError('The model returned silence.')
    sf.write(folder/'speech.pending.wav',audio,rate,subtype='PCM_24')
    if sha(reference) != request['referenceSHA256']: raise ValueError('Reference changed during synthesis.')
    (folder/'speech.pending.wav').rename(output)
    report={'sampleRate':rate,'duration':len(audio)/rate,'audioSHA256':sha(output),'referenceSHA256':request['referenceSHA256'],'modelID':MODEL_ID,'modelRevision':REVISION,'runtimeVersion':importlib.metadata.version('mlx-audio'),'elapsedSeconds':time.monotonic()-start,'segments':text_segments,'warnings':warnings,'sampling':{'temperature':.9,'topK':50,'topP':1.0,'repetitionPenalty':1.5,'maxTokensPerSegment':2048,'pauseSeconds':.16,'seed':request['seed']}}
    with (folder/'result.json').open('x') as f: json.dump(report,f,indent=2)
    print('Speech saved.',flush=True)

if __name__ == '__main__':
    main()
