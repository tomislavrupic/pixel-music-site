"""Pure selection policy and LoRA arithmetic; no model loading or approval bypass.

These functions return prospective updates. They do not mutate a model, verify
listening approval, or authorize an imported sound for normal generation.
"""
from __future__ import annotations

import math
from pathlib import Path
import re
import uuid

from external_yue2_format import (AdapterFormatError, MAX_ADAPTER_BYTES, _branch,
    digest_file, digest_stream, fail, open_regular, scan_finite, tensor_header)
import os


_UUID = re.compile(r'[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\Z')
_HASH = re.compile(r'[0-9a-fA-F]{64}\Z')


def _numeric(value, lower: float, upper: float, name: str) -> float:
    if type(value) not in (int, float):
        fail('invalid_strength', f'{name} must be a number, not a boolean or string.')
    try:
        number = float(value)
    except OverflowError:
        fail('invalid_strength', f'{name} is too large.')
    if not math.isfinite(number) or not lower <= number <= upper:
        fail('invalid_strength', f'{name} must be finite and in [{lower}, {upper}].')
    return number


def validate_reference(reference: dict) -> None:
    if not isinstance(reference, dict) or set(reference) != {'path', 'sha256'}:
        fail('invalid_reference', 'Expected a path and SHA-256 reference.')
    path, checksum = reference['path'], reference['sha256']
    if (not isinstance(path, str) or not path.startswith('/') or path == '/'
            or '\0' in path or '..' in Path(path).parts
            or not isinstance(checksum, str) or not _HASH.fullmatch(checksum)):
        fail('invalid_reference', 'Reference requires an absolute, non-traversing path and SHA-256.')


def validate_selection(value: dict) -> None:
    required = {'packageID', 'versionID', 'descriptor', 'enabled', 'amount'}
    optional = {'approval', 'arScale', 'narScale'}
    if not isinstance(value, dict) or not required <= set(value) or set(value) - required - optional:
        fail('invalid_selection', 'Incomplete or unsupported imported sound selection.')
    for field in ('packageID', 'versionID'):
        if not isinstance(value[field], str) or not _UUID.fullmatch(value[field]):
            fail('invalid_selection', f'{field} must be a UUID.')
        uuid.UUID(value[field])
    validate_reference(value['descriptor'])
    if value.get('approval') is not None:
        validate_reference(value['approval'])
    if type(value['enabled']) is not bool:
        fail('invalid_selection', 'Enabled must be a boolean.')
    _numeric(value['amount'], 0, 1, 'Amount')
    if value.get('arScale') is None and value.get('narScale') is None:
        fail('invalid_strength', 'At least one branch must be declared.')
    for field in ('arScale', 'narScale'):
        if value.get(field) is not None:
            _numeric(value[field], 0, 2, field)


def effective_scales(selection: dict) -> dict[str, float]:
    """Swift ImportedSoundSelection parity. No file IO, even for a missing pack."""
    validate_selection(selection)
    if not selection['enabled'] or selection['amount'] == 0:
        return {}
    return {branch: selection['amount'] * selection[field]
            for branch, field in (('ar', 'arScale'), ('nar', 'narScale'))
            if selection.get(field) is not None and selection[field] > 0}


def render_policy(options: dict, plan_only: bool = False) -> dict:
    """Report required routing. This never authorizes or applies adapter weights."""
    if not isinstance(options, dict) or type(plan_only) is not bool:
        fail('invalid_selection', 'Invalid render policy input.')
    selection = options.get('importedSound')
    if selection is None:
        return {'status': 'not_selected', 'scales': {}}
    scales = effective_scales(selection)
    planning, abc = options.get('planning', 'full'), options.get('abc', '')
    latent_path = options.get('decodeLatentsPath')
    if (not isinstance(planning, str) or planning not in ('full', 'melody', 'off')
            or not isinstance(abc, str)
            or (latent_path is not None and not isinstance(latent_path, str))):
        fail('invalid_selection', 'Malformed planning, score, or latent reference.')
    if any(options.get(key) is not None for key in ('trainedStylePath', 'trainedStyleSHA256', 'styleInfluence')):
        fail('conflicting_sounds', 'Choose either a locally trained style or an imported sound, not both.')
    if plan_only:
        return {'status': 'base_planning', 'scales': {}}
    if options.get('decodeLatentsPath'):
        return {'status': 'latent_decode', 'scales': {}}
    if not scales:
        return {'status': 'inactive', 'scales': {}}
    if planning != 'off' and not abc.strip():
        return {'status': 'requires_base_score', 'scales': scales}
    return {'status': 'requires_verified_binding', 'scales': scales}


def effective_updates(weights: dict, adapter_pairs: dict, amount: float,
                      branch_scale: float, alpha: float) -> dict:
    """Return W + amount*branch_scale*(alpha/r)*(B@A), leaving inputs untouched.

    CPU reference/conversion arithmetic uses NumPy, already in the normal runtime.
    The actual MLX model commit and activation gate must wrap this contract.
    """
    import numpy as np
    amount = _numeric(amount, 0, 1, 'Amount')
    branch_scale = _numeric(branch_scale, 0, 2, 'Branch scale')
    alpha = _numeric(alpha, 0, float('inf'), 'Alpha')
    if alpha == 0:
        fail('invalid_strength', 'Alpha must be positive.')
    if amount == 0 or branch_scale == 0:
        return {}
    if not isinstance(weights, dict) or not isinstance(adapter_pairs, dict) or not adapter_pairs:
        fail('invalid_tensor', 'Expected nonempty factor pairs and destination weights.')
    updates = {}
    for key, pair in adapter_pairs.items():
        if not isinstance(pair, (tuple, list)) or len(pair) != 2 or key not in weights:
            fail('incomplete_pair', f'Missing factor or destination: {key}')
        a, b = pair
        w = weights[key]
        if any(not isinstance(x, np.ndarray) or x.dtype.kind != 'f' for x in (a,b,w)):
            fail('unsupported_dtype', f'{key}: floating-point arrays are required.')
        if (a.ndim != 2 or b.ndim != 2 or w.ndim != 2 or a.shape[0] < 1
                or a.shape[0] != b.shape[1] or (b.shape[0], a.shape[1]) != w.shape):
            fail('shape_mismatch', f'{key}: factors and destination have incompatible shapes.')
        if any(not bool(np.isfinite(x).all()) for x in (a,b,w)):
            fail('nonfinite_tensor', f'{key}: non-finite factors or destination.')
        with np.errstate(over='ignore', invalid='ignore'):
            af, bf, wf = (x.astype(np.float32, copy=False) for x in (a,b,w))
            scale = np.float32(amount * branch_scale * (alpha / a.shape[0]))
            result = wf + scale * (bf @ af)
            cast = result.astype(w.dtype)
        if not bool(np.isfinite(result).all()) or not bool(np.isfinite(cast).all()):
            fail('nonfinite_update', f'{key}: LoRA update overflows float32 or the destination dtype.')
        updates[key] = cast
    return updates


def prepare_updates(weights: dict, adapters: list[dict], amount: float) -> dict:
    """Validate both branches before returning any updates; never mutate the model."""
    amount = _numeric(amount, 0, 1, 'Amount')
    if not isinstance(adapters, list) or not 1 <= len(adapters) <= 2:
        fail('invalid_selection', 'Expected one AR, one NAR, or one of each.')
    seen, updates = set(), {}
    for packet in adapters:
        if not isinstance(packet, dict) or set(packet) != {'branch', 'scale', 'alpha', 'pairs'}:
            fail('invalid_selection', 'Invalid adapter packet.')
        branch = packet['branch']
        if not isinstance(branch, str) or branch not in ('ar','nar') or branch in seen:
            fail('conflicting_sounds', 'Duplicate or unknown adapter branch.')
        seen.add(branch)
        _numeric(packet['scale'], 0, 2, 'Branch scale')
        if not isinstance(packet['pairs'], dict):
            fail('invalid_tensor', 'Factor pairs must be a mapping.')
        for name in packet['pairs']:
            if not isinstance(name, str) or not name.endswith('.weight') or _branch(name[:-7]) != branch:
                fail('branch_mismatch', f'{name}: target does not belong to {branch}.')
        current = effective_updates(weights, packet['pairs'], amount, packet['scale'], packet['alpha'])
        if set(updates) & set(current):
            fail('conflicting_sounds', 'Multiple adapter updates target one weight.')
        updates.update(current)
    return updates


def effective_mlx_updates(weights: dict, adapter_pairs: dict, amount: float,
                          branch_scale: float, alpha: float) -> dict:
    """Prepare and evaluate finite MLX tensors without mutating the model."""
    import mlx.core as mx
    amount = _numeric(amount, 0, 1, 'Amount')
    branch_scale = _numeric(branch_scale, 0, 2, 'Branch scale')
    alpha = _numeric(alpha, 0, float('inf'), 'Alpha')
    if alpha == 0:
        fail('invalid_strength', 'Alpha must be positive.')
    if amount == 0 or branch_scale == 0:
        return {}
    if not isinstance(weights, dict) or not isinstance(adapter_pairs, dict) or not adapter_pairs:
        fail('invalid_tensor', 'Expected nonempty factor pairs and destination weights.')
    accepted = (mx.float16, mx.bfloat16, mx.float32)
    updates = {}
    for key, pair in adapter_pairs.items():
        if not isinstance(pair, (tuple, list)) or len(pair) != 2 or key not in weights:
            fail('incomplete_pair', f'Missing factor or destination: {key}')
        a, b = pair
        w = weights[key]
        if any(not isinstance(x, mx.array) or x.dtype not in accepted for x in (a,b,w)):
            fail('unsupported_dtype', f'{key}: floating-point MLX arrays are required.')
        if (a.ndim != 2 or b.ndim != 2 or w.ndim != 2 or a.shape[0] < 1
                or a.shape[0] != b.shape[1] or (b.shape[0], a.shape[1]) != w.shape):
            fail('shape_mismatch', f'{key}: factors and destination have incompatible shapes.')
        scale = amount * branch_scale * alpha / a.shape[0]
        if not math.isfinite(scale) or scale > 3.4028234663852886e38:
            fail('nonfinite_update', f'{key}: effective strength overflows float32.')
        if any(not bool(mx.all(mx.isfinite(x)).item()) for x in (a,b,w)):
            fail('nonfinite_tensor', f'{key}: non-finite factors or destination.')
        result = w.astype(mx.float32) + mx.array(scale, dtype=mx.float32) * (b.astype(mx.float32) @ a.astype(mx.float32))
        cast = result.astype(w.dtype)
        mx.eval(result, cast)
        if not bool(mx.all(mx.isfinite(result)).item()) or not bool(mx.all(mx.isfinite(cast)).item()):
            fail('nonfinite_update', f'{key}: update overflows float32 or destination dtype.')
        updates[key] = cast
    return updates


def apply_mlx_packets(model, packets: list[dict], amount: float) -> dict:
    """Validate all selected branches, then make one in-memory MLX weight update."""
    import mlx.core as mx
    from mlx.utils import tree_flatten
    amount = _numeric(amount, 0, 1, 'Amount')
    if not isinstance(packets, list) or not 1 <= len(packets) <= 2:
        fail('invalid_selection', 'Expected one AR, one NAR, or one of each.')
    state = dict(tree_flatten(model.parameters())) if amount > 0 else {}
    seen, updates = set(), {}
    for packet in packets:
        if not isinstance(packet, dict) or set(packet) != {'branch', 'scale', 'alpha', 'pairs'}:
            fail('invalid_selection', 'Invalid adapter packet.')
        branch = packet['branch']
        if branch not in ('ar', 'nar') or branch in seen:
            fail('conflicting_sounds', 'Duplicate or unknown adapter branch.')
        seen.add(branch)
        _numeric(packet['scale'], 0, 2, 'Branch scale')
        if not isinstance(packet['pairs'], dict):
            fail('invalid_tensor', 'Factor pairs must be a mapping.')
        for name in packet['pairs']:
            if not isinstance(name, str) or not name.endswith('.weight') or _branch(name[:-7]) != branch:
                fail('branch_mismatch', f'{name}: target does not belong to {branch}.')
        current = effective_mlx_updates(state, packet['pairs'], amount, packet['scale'], packet['alpha'])
        if set(updates) & set(current):
            fail('conflicting_sounds', 'Multiple adapter updates target one weight.')
        updates.update(current)
    if updates:
        mx.eval(*updates.values())
        model.load_weights(list(updates.items()), strict=False)
        mx.eval(model.parameters())
    return updates


def _load_bound_packet(reference: dict, base: dict) -> dict:
    """Read one normalized file only after validating its bytes and binding."""
    import mlx.core as mx
    path = Path(reference['path'])
    with open_regular(path, MAX_ADAPTER_BYTES) as stream:
        header, offset = tensor_header(stream, os.fstat(stream.fileno()).st_size)
        meta = header.get('__metadata__', {})
        if (meta.get('format') != 'pixel-music-external-yue2-tensors-v1'
                or meta.get('layout') != base['layoutID']
                or meta.get('base_model_sha256') != base['modelSHA256']
                or meta.get('base_revision') != base['revision']
                or meta.get('branch') != reference['branch']):
            fail('base_mismatch', 'Normalized adapter is not bound to this verified base and branch.')
        factors = {}
        for name, entry in header.items():
            if name == '__metadata__':
                continue
            suffix = next((s for s in ('.lora_down.weight','.lora_up.weight','.alpha') if name.endswith(s)),None)
            if suffix is None:
                fail('unsupported_tensor', f'Unexpected normalized tensor: {name}.')
            target = name[:-len(suffix)]
            if _branch(target) != reference['branch']:
                fail('branch_mismatch', f'Normalized tensor is in the wrong branch: {name}.')
            factors.setdefault(target,{})[suffix] = entry
        if not factors:
            fail('invalid_tensor', 'Normalized adapter has no targets.')
        alpha = None
        for target, members in factors.items():
            if set(members) != {'.lora_down.weight','.lora_up.weight','.alpha'}:
                fail('incomplete_pair', f'Normalized adapter has an incomplete pair: {target}.')
            a,b,s = (members[k] for k in ('.lora_down.weight','.lora_up.weight','.alpha'))
            ashape,bshape = a['shape'],b['shape']
            if (len(ashape)!=2 or len(bshape)!=2 or ashape[0]!=bshape[1]
                    or base['weightShapes'].get(target+'.weight') != [bshape[0],ashape[1]]):
                fail('shape_mismatch', f'Normalized factors disagree with verified base: {target}.')
            if s['dtype']!='F32' or s['shape']!=[]:
                fail('invalid_tensor', f'Alpha must be float32 scalar: {target}.')
        scan_finite(stream,header,offset)
        if digest_stream(stream) != reference['sha256']:
            fail('source_changed', 'Normalized adapter checksum changed.')
    values = mx.load(str(path))
    if set(values) != set(header)-{'__metadata__'} or digest_file(path,MAX_ADAPTER_BYTES)!=reference['sha256']:
        fail('source_changed', 'Normalized adapter changed while loading.')
    pairs = {}
    for target in factors:
        current = float(values[target+'.alpha'].item())
        if not math.isfinite(current) or current<=0 or (alpha is not None and alpha!=current):
            fail('invalid_tensor', f'Invalid or conflicting alpha: {target}.')
        alpha = current
        pairs[target+'.weight'] = (values[target+'.lora_down.weight'],values[target+'.lora_up.weight'])
    return {'branch':reference['branch'],'scale':reference['scale'],'alpha':alpha,'pairs':pairs}


def apply_bound_adapters(model, base: dict, references: list[dict], amount: float) -> dict:
    """Reverify the installed base, load selected files, then commit both branches."""
    amount = _numeric(amount,0,1,'Amount')
    if not isinstance(references,list) or not 1<=len(references)<=2:
        fail('invalid_selection','Expected one or two normalized adapter references.')
    seen = set()
    for reference in references:
        if not isinstance(reference,dict) or set(reference)!={'branch','scale','path','sha256'}:
            fail('invalid_selection','Malformed normalized adapter reference.')
        if reference['branch'] not in ('ar','nar') or reference['branch'] in seen:
            fail('conflicting_sounds','Duplicate or unknown normalized adapter branch.')
        seen.add(reference['branch'])
        _numeric(reference['scale'],0,2,'Branch scale')
        if (not isinstance(reference['path'],str) or not Path(reference['path']).is_absolute()
                or '..' in Path(reference['path']).parts or not isinstance(reference['sha256'],str)
                or not _HASH.fullmatch(reference['sha256'])):
            fail('invalid_reference','Normalized adapter requires an absolute path and SHA-256.')
    if amount==0 or not any(reference['scale']>0 for reference in references):
        return {'updates':[],'base':None}
    from external_yue2_import import validate_local_base
    if not isinstance(base,dict) or not isinstance(base.get('modelRoot'),str):
        fail('unverified_base_layout','Missing verified base binding.')
    observed = validate_local_base(Path(base['modelRoot']))
    if observed != base:
        fail('base_mismatch','Installed base differs from the adapter binding.')
    packets=[_load_bound_packet(reference,base) for reference in references if reference['scale']>0]
    updates=apply_mlx_packets(model,packets,amount)
    return {'updates':list(updates),'base':observed}
