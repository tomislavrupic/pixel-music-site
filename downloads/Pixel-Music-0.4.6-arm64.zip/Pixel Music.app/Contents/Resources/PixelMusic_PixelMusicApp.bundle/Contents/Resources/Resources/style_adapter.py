"""Fail-closed approved-style validation. No ML runtime imported during validation."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import struct


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def checked(asset):
    path = Path(asset['path'])
    if not path.is_absolute() or path.is_symlink() or not path.is_file() or digest(path) != asset['sha256']:
        raise ValueError('Trained style artifact is missing or changed: ' + str(path))
    return path


def metadata(path):
    with Path(path).open('rb') as f:
        size = f.read(8)
        if len(size) != 8:
            raise ValueError('Invalid adapter header')
        length = struct.unpack('<Q', size)[0]
        if not 2 <= length <= 16 * 1024 * 1024:
            raise ValueError('Invalid adapter header size')
        return json.loads(f.read(length))['__metadata__']


def validate_options(options):
    if not any(options.get(k) is not None for k in ('trainedStylePath', 'trainedStyleSHA256', 'styleInfluence')):
        return False
    path, checksum, strength = (options.get(k) for k in ('trainedStylePath', 'trainedStyleSHA256', 'styleInfluence'))
    planning = options.get('planning', 'full')
    abc = options.get('abc', '')
    has_explicit_score = isinstance(abc, str) and bool(abc.strip())
    if (not isinstance(path, str) or not path.startswith('/') or '\0' in path
        or not isinstance(checksum, str) or len(checksum) != 64
        or any(c not in '0123456789abcdefABCDEF' for c in checksum)
        or isinstance(strength, bool) or not isinstance(strength, (int, float))
        or not math.isfinite(strength) or not 0 <= strength <= 2
        or (planning != 'off' and not has_explicit_score)):
        raise ValueError('Trained style requires an approved descriptor, checksum, influence 0–2 and either Direct generation or an explicit ABC score.')
    return True


def verify(options, model_root):
    if not validate_options(options):
        return None
    descriptor = checked({'path': options['trainedStylePath'], 'sha256': options['trainedStyleSHA256']})
    data = json.loads(descriptor.read_text())
    if (data.get('schema_version') != 1 or data.get('status') != 'approved'
        or data.get('protocol') not in ('yue2-ar-style-v1', 'yue2-joint-style-v1') or data.get('runtime') != 'mlx'
        or data.get('planning') != 'off'):
        raise ValueError('Unsupported or unapproved trained style')
    adapter = checked(data['adapter'])
    dataset = checked(data['dataset'])
    companion = checked(data['acoustic_companion'])
    checked(data['base'])
    checked({'path': str(Path(data['preview']['path'])/'preview.json'), 'sha256': data['preview']['sha256']})
    base_hash = digest(Path(model_root)/'bf16/model.safetensors')
    if base_hash != data['base']['sha256'] or base_hash != data['acoustic_companion']['base_sha256']:
        raise ValueError('Trained style base model mismatch')
    if json.loads(dataset.read_text()).get('acoustic_companion') != data['acoustic_companion']:
        raise ValueError('Trained style dataset companion mismatch')
    ar, nar = metadata(adapter), metadata(companion)
    expected = 'joint' if data['protocol'] == 'yue2-joint-style-v1' else 'ar'
    for meta, branch in ((ar, expected), (nar, 'nar')):
        if meta.get('format') != 'fl-yue2-lora-v1' or meta.get('branch') != branch or meta.get('base_sha256') != base_hash:
            raise ValueError('Trained style adapter metadata mismatch')
    if ar.get('dataset_sha256') != data['dataset']['sha256'] or json.loads(ar.get('acoustic_companion', '{}')) != data['acoustic_companion']:
        raise ValueError('Trained style adapter dataset mismatch')
    return {'descriptor': data, 'descriptorPath': str(descriptor),
            'descriptorSHA256': options['trainedStyleSHA256'], 'influence': options['styleInfluence']}


def apply(model, verified):
    """Recheck at application time, then apply NAR companion before scaled AR style."""
    data = verified['descriptor']
    checked({'path': verified['descriptorPath'], 'sha256': verified['descriptorSHA256']})
    checked(data['dataset'])
    checked({'path': str(Path(data['preview']['path'])/'preview.json'), 'sha256': data['preview']['sha256']})
    companion, adapter = checked(data['acoustic_companion']), checked(data['adapter'])
    core = Path(__file__).parent/'YuE2Training/core.py'
    spec = importlib.util.spec_from_file_location('pixel_music_trained_style_core', core)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.apply_adapter(model, companion)
    module.apply_adapter(model, adapter, verified['influence'])
    verified['implementationSHA256'] = digest(core)
    verified['validatorSHA256'] = digest(__file__)
