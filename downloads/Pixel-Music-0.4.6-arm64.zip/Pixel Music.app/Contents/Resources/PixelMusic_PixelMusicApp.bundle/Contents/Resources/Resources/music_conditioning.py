"""Bounded semantic preset guidance shared by the local Qwen and YuE2 runners."""
import json
import math


TEXT_LIMITS = {'description': 2000, 'prompt': 4000, 'negativePrompt': 1000,
               'harmonyPreference': 2000, 'rhythmPreference': 2000,
               'arrangementPreference': 2000, 'productionPreference': 2000,
               'vocalsPreference': 2000, 'lyricsPreference': 2000,
               'genderPresentation': 2000, 'register': 2000, 'tone': 2000,
               'delivery': 2000, 'articulation': 2000, 'accentGuidance': 2000,
               'harmonyBehaviour': 2000, 'doublingBehaviour': 2000, 'processing': 2000}
LIST_FIELDS = {'preferredGenres', 'avoidedGenres', 'preferredAesthetics',
               'avoidedAesthetics', 'avoid', 'instrumentation', 'tags', 'languages'}
NUMERIC_FIELDS = {'harmonyComplexity', 'harmonyTension', 'harmonyModalColour',
                  'harmonyConsonance', 'rhythmDensity', 'rhythmSyncopation',
                  'rhythmSwing', 'rhythmFourOnFloorBias', 'productionWarmth',
                  'productionBrightness', 'productionWidth', 'productionDensity',
                  'productionPunch', 'productionOrganic', 'productionSaturation',
                  'arrangementDevelopment', 'arrangementRepetition',
                  'arrangementContrast', 'arrangementMutation', 'arrangementMinimalism',
                  'breathiness', 'intensity', 'vibrato', 'intimacy'}
TEMPO_FIELDS = {'tempoMin', 'tempoMax', 'tempoPreferred'}


def _graphemes(value):
    if value.isascii():
        return list(value)
    try:
        import regex
    except ImportError as error:
        raise ValueError('The YuE2 runtime is missing regex for Unicode grapheme validation.') from error
    return regex.findall(r'\X', value)


def _text_length(value):
    return len(value) if value.isascii() else len(_graphemes(value))


def _semantic(value):
    if not isinstance(value, dict):
        raise ValueError('Preset conditioning must be an object.')
    result = {}
    for key, item in value.items():
        if key in TEXT_LIMITS:
            if not isinstance(item, str) or _text_length(item) > TEXT_LIMITS[key]:
                raise ValueError('Invalid preset conditioning field: ' + key)
            if item.strip():
                result[key] = item.strip()
        elif key in LIST_FIELDS:
            if (not isinstance(item, list) or len(item) > 100 or
                    any(not isinstance(x, str) or _text_length(x) > 200 for x in item)):
                raise ValueError('Invalid preset conditioning field: ' + key)
            cleaned = [x.strip() for x in item if x.strip()]
            if cleaned:
                result[key] = cleaned
        elif key in NUMERIC_FIELDS:
            if (type(item) not in (int, float) or not math.isfinite(item)
                    or not 0 <= item <= 1):
                raise ValueError('Invalid preset conditioning field: ' + key)
            result[key] = item
        elif key in TEMPO_FIELDS:
            if type(item) is not int or not 40 <= item <= 240:
                raise ValueError('Invalid preset conditioning field: ' + key)
            result[key] = item
    return result


def build_conditioning_context(request):
    """Return ordered source sections, or None for an absent/empty preset snapshot."""
    if not isinstance(request, dict):
        raise ValueError('Conditioning request must be an object.')
    song = request.get('song') if isinstance(request.get('song'), dict) else request
    raw = song.get('presetContext')
    if raw is None:
        return None
    if not isinstance(raw, dict) or set(raw) - {'style', 'voice', 'taste'}:
        raise ValueError('Invalid preset conditioning context.')
    presets = {}
    for source in ('style', 'voice', 'taste'):
        if raw.get(source) is not None:
            values = _semantic(raw[source])
            if values:
                presets[source] = values
    if not presets:
        return None
    sections = []
    for source, priority, values in (
        ('explicitIntention', 1, {'text': request.get('emotionalIntention', '')}),
        ('trajectory', 2, request.get('trajectory', {})),
        ('project', 3, {key: song[key] for key in ('caption', 'negativePrompt', 'lyrics',
                     'instrumental', 'vocalChoice', 'tempo', 'key', 'planning') if key in song}),
    ):
        if values:
            sections.append({'source': source, 'priority': priority,
                             'strength': 'authoritative', 'values': values})
    for source, priority in (('style', 4), ('voice', 5), ('taste', 6)):
        if source in presets:
            sections.append({'source': source, 'priority': priority,
                             'strength': 'conditional' if source == 'taste' else 'preference',
                             'values': presets[source]})
    return {'sections': sections}


def render_conditioning(context, max_chars):
    """Compact prompt summary; full snapshots remain in request provenance."""
    if context is None:
        return ''
    if type(max_chars) is not int or max_chars < 0 or max_chars > 10000:
        raise ValueError('Invalid conditioning summary budget.')
    sources = [s for s in context['sections'] if s['source'] in ('style', 'voice', 'taste')]
    if not sources:
        return ''
    prepared = []
    for section in sources:
        fields = []
        for key, value in sorted(section['values'].items()):
            if isinstance(value, list):
                value = ', '.join(value)
            elif isinstance(value, float):
                value = f'{value:.2f}'
            else:
                value = str(value)
            if value:
                clusters = _graphemes(value)
                exact = key in NUMERIC_FIELDS or key in TEMPO_FIELDS
                fields.append({'key': key, 'clusters': clusters,
                               'shown': len(clusters) if exact else 1})
        if fields:
            prepared.append((f'{section["source"].upper()} CONDITIONING ({section["strength"]}): ', fields))

    # Reserve headers, every populated key, exact numbers, one prose grapheme,
    # and an omission marker for any field that may be shortened.
    used = max(0, len(prepared) - 1)
    for label, fields in prepared:
        used += len(label) + sum(len(f['key']) + 2 +
                                 sum(len(cluster) for cluster in f['clusters'][:f['shown']]) +
                                 (1 if f['shown'] < len(f['clusters']) else 0)
                                 for f in fields)
        used += 2 * (len(fields) - 1)
    if used > max_chars:
        raise ValueError('The conditioning summary budget cannot fit every populated field label.')

    # Distribute remaining space across fields before any long profile can consume it.
    fields = [field for _, group in prepared for field in group]
    for cap in (64, 180, None):
        while True:
            advanced = False
            for field in fields:
                if field['shown'] >= min(len(field['clusters']), cap or len(field['clusters'])):
                    continue
                cluster = field['clusters'][field['shown']]
                completes = field['shown'] + 1 == len(field['clusters'])
                cost = len(cluster) - (1 if completes else 0)
                if used + cost > max_chars:
                    continue
                field['shown'] += 1
                used += cost
                advanced = True
            if not advanced:
                break
    return '\n'.join(label + '; '.join(
        f"{field['key']}: {''.join(field['clusters'][:field['shown']])}"
        + ('…' if field['shown'] < len(field['clusters']) else '') for field in group)
        for label, group in prepared)
